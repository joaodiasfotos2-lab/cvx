// ============================= 08zo-selecionadores.js =============================
// Ecossistema de staff — fase 2c (0.4.31): o selecionador nacional, no topo da pirâmide.
// Antes desta fase nenhuma seleção tinha selecionador de IA (o cargo só existia para o utilizador,
// 08c-staff-treinadores.js). Agora cada uma das 12 nações cobertas por 07h-selecoes.js tem um:
//
// - Quem: escolhido entre os melhores treinadores principais de clubes de IA da mesma nacionalidade
//   (ficam no clube, em acumulação — tal como o utilizador), lendas/ex-jogadores e treinadores livres
//   do pool. Quando ninguém da nacionalidade chega ao patamar da nação, a federação contrata um
//   selecionador "de carreira" gerado (nome do país, só os NOMES são inventados). Argentina, Chile,
//   Angola e Colômbia não têm treinadores no universo do jogo: sempre gerados.
// - Efeitos: (1) convocatória — a qualidade do selecionador reduz o "ruído" na escolha (um mau
//   selecionador deixa de fora/chama jogadores a mais), o perfil juventude↔experiência desloca a
//   escolha para novos/veteranos e há preferência por manter o grupo anterior; (2) estilo — a cultura
//   táctica da seleção (ofensividade/agressividade/liberdade criativa) é a do selecionador, como já
//   acontece com o utilizador; (3) força — pequeno fator (−2% a +3%) no ataque e na defesa, a par
//   do fator de vaga de treinador (treinadorVacanciaPenaltyFactor).
// - Carreira: contrato de 3 épocas; no fim de cada edição a confiança da federação sobe/desce consoante
//   o resultado face à expectativa da cabeça de série (campeão vale sempre muito); duas participações
//   seguidas abaixo de 35 (ou uma abaixo de 20) custam o cargo; aos 60–72 anos reforma-se (mesma curva
//   do resto do staff). A vaga é preenchida no defeso seguinte, com notícia. Saída do cargo → volta ao
//   pool (se estava só na seleção) e fica no currículo (historicoSelecao).
// - Utilizador: se aceitar um convite, o selecionador de IA da nação sai; quando o utilizador sai
//   (demissão/despedimento) a vaga é preenchida de imediato.
// Estado (gravado): state.selecionadores[code] = {code, coach|coachId+clubeId, desde, contratoAte, confianca,
//   participacoes[], titulos, origem}; state.selecionadoresHistorico (máx. 80); state.selecionadoresAnnualSeason.
// =================================================================================
var SELECIONADOR_CODES = ["pt","es","it","fr","en","de","ch","at","ar","cl","ao","co"];
// Patamar de experiência (0–20) de um selecionador gerado, por nação.
var SELECIONADOR_BANDA = {
  pt: [13,17], es: [13,17], it: [12,16], fr: [10,13], ar: [10,13],
  en: [7,11], de: [7,11], ch: [7,11], at: [6,10], cl: [7,10], ao: [6,10], co: [6,10],
};
var SELECIONADOR_NAC = { pt:"Portuguesa", es:"Espanhola", it:"Italiana", fr:"Francesa", en:"Inglesa", de:"Alemã", ch:"Suíça", at:"Austríaca", ar:"Argentina", cl:"Chilena", ao:"Angolana", co:"Colombiana" };
var SELECIONADOR_CONTRATO_EPOCAS = 3;
var SELECIONADOR_CONFIANCA_INICIAL = 60;
var SELECIONADOR_CONFIANCA_LIMIAR = 35;
var SELECIONADOR_CONFIANCA_DEMISSAO = 20;
// Posição final esperada (0 = campeão … 7) por cabeça de série (índice 0–7 do sorteio da edição).
var SELECIONADOR_ESPERADO = [1, 2, 3, 3, 5, 5, 6, 6];

function selecionadoresState(){ if(!state.selecionadores || typeof state.selecionadores !== "object") state.selecionadores = {}; return state.selecionadores; }
function selecionadoresHist(){ if(!Array.isArray(state.selecionadoresHistorico)) state.selecionadoresHistorico = []; return state.selecionadoresHistorico; }
function selecionadorBase(code){ return typeof selecaoBaseCode === "function" ? selecaoBaseCode(code) : code; }
function selecionadorNomeNacao(code){ const n = typeof selecaoNationOf === "function" ? selecaoNationOf(code) : null; return n ? n.nome : code; }
function selecionadorUserHolds(code){ const g = ensureManagerCareer(); return !!(g.selecaoAtual && g.selecaoAtual.code === selecionadorBase(code)); }
function selecionadorEntry(code){ return selecionadoresState()[selecionadorBase(code)] || null; }

// Procura uma pessoa de staff por id: pool, lugares de clube (principal incluído).
function selecionadorLocate(id){
  const p = staffPool().find(x => x.id === id);
  if(p) return { c: p, clube: null, onde: "pool" };
  for(const t of Object.values(state.teams)){
    if(t.treinador && t.treinador.id === id) return { c: t.treinador, clube: t, onde: "clube" };
  }
  return null;
}
function selecionadorCoach(code){
  const e = selecionadorEntry(code);
  if(!e) return null;
  if(e.coach) return e.coach;
  if(e.coachId){ const r = selecionadorLocate(e.coachId); if(r && r.onde === "clube") return r.c; }
  return null;
}
function selecionadorFindById(id){
  const es = selecionadoresState();
  for(const code of Object.keys(es)){
    const e = es[code];
    if(e.coach && e.coach.id === id) return { c: e.coach, clube: null, code };
    if(e.coachId === id){ const r = selecionadorLocate(id); if(r && r.onde === "clube") return { c: r.c, clube: r.clube, code }; }
  }
  return null;
}

// Valida a entrada: o treinador em acumulação pode ter mudado de clube, ido para o pool (passa a ser
// só da seleção) ou ter desaparecido (reforma).
function selecionadorValidar(code){
  const base = selecionadorBase(code), e = selecionadoresState()[base];
  if(!e) return false;
  if(e.coach) return true;
  const r = e.coachId ? selecionadorLocate(e.coachId) : null;
  if(!r){ delete state.selecionadores[base]; return false; }
  if(r.onde === "clube"){ e.clubeId = r.clube.id; return true; }
  staffRemoveFromPool(r.c);
  e.coach = r.c; e.coachId = null; e.clubeId = null;
  return true;
}

// ---------- qualidade, estilo, efeitos ----------
function selecionadorQ(c){
  const s = (c && c.stats) || {};
  return (staffExp(c) * 2 + (s.faroScouting != null ? s.faroScouting : 10) + (s.adaptabilidade != null ? s.adaptabilidade : 10) + (s.motivacaoCarisma != null ? s.motivacaoCarisma : 10)) / 5;
}
function selecionadorFator(c){ return 1 + clamp((selecionadorQ(c) - 10) * 0.004, -0.02, 0.03); }
function selecionadorEstilo(c){
  const s = (c && c.stats) || {};
  const of = s.ofensividade != null ? s.ofensividade : 10, jv = s.prefJuventude != null ? s.prefJuventude : 10;
  return `${of >= 13 ? "ofensivo" : of <= 7 ? "prudente" : "equilibrado"} · ${jv >= 13 ? "aposta nos jovens" : jv <= 7 ? "aposta na experiência" : "mistura idades"}`;
}
// Devolve a função de pontuação da convocatória, com o "olho" do selecionador. A função base é a do
// módulo das seleções (forma + overall + regularidade). Determinística por (nação, época, jogador).
function selecionadorScoreFn(code, baseFn){
  const base = selecionadorBase(code);
  if(selecionadorUserHolds(base) && !(typeof selecaoIsS19Code === "function" && selecaoIsS19Code(code))) return baseFn;
  selecionadorEnsure(base, true);
  const c = selecionadorCoach(base);
  if(!c) return baseFn;
  const isS19 = typeof selecaoIsS19Code === "function" && selecaoIsS19Code(code);
  const s = c.stats || {};
  const q = isS19 ? ((s.desenvolvimentoJovens != null ? s.desenvolvimentoJovens : 10) * 2 + (s.faroScouting != null ? s.faroScouting : 10)) / 3 : selecionadorQ(c);
  const amp = clamp((12 - q) * 1.8, 0, 16);
  const juv = (s.prefJuventude != null ? s.prefJuventude : 10) - 10;
  const prevConv = (state.selecoesUltimaConvocatoria || {})[code];
  const prev = new Set(prevConv && Array.isArray(prevConv.jogadores) ? prevConv.jogadores.map(j => j.id) : []);
  const cache = new Map();
  return p => {
    if(cache.has(p.id)) return cache.get(p.id);
    let v = baseFn(p);
    if(!p.__selecaoFiller){
      const rng = makeSeededRng(`selecionador-conv:${code}:${c.id}:${state.season}:${p.id}`);
      v += seededRndFloat(rng, -1, 1) * amp;
      if(!isS19){
        const age = p.age != null ? p.age : 27;
        v += juv * 0.15 * (27 - age);
        if(prev.has(p.id)) v += 4;
      }
    }
    cache.set(p.id, v);
    return v;
  };
}
// Aplica o estilo e o fator de força do selecionador à equipa virtual da seleção.
function selecionadorAplicarEquipa(code, team){
  if(!team) return;
  const c = selecionadorCoach(selecionadorBase(code));
  if(!c) return;
  const s = c.stats || {};
  team.treinadorCultura = { ofensividade: s.ofensividade != null ? s.ofensividade : 10, agressividade: s.agressividade != null ? s.agressividade : 10, liberdadeCriativa: s.liberdadeCriativa != null ? s.liberdadeCriativa : 10, lastMonthKey: null };
  team.selecionadorFator = selecionadorFator(c);
}

// ---------- nomeação ----------
function selecionadorLenda(c){
  const cj = c && c.carreiraJogador;
  return !!(c && c.origem === "ex-jogador" && cj && ((cj.jogos || 0) >= 250 || (cj.ovr || 0) >= 80));
}
function selecionadorScore(c){
  const t = staffHistTotals(c);
  const pct = t.j >= 20 ? (t.v / t.j) * 100 : 50;
  let s = staffExp(c) + (pct - 50) * 0.04;
  if(selecionadorLenda(c)) s += clamp(((c.carreiraJogador.jogos || 0) / 300), 0, 1.5) + 0.5;
  if(staffEtapa(c) < 2) s -= 1.5;
  return s;
}
function selecionadorCandidatos(code){
  const base = selecionadorBase(code);
  if(!["pt","es","it","fr","de","ch","en","at"].includes(base)) return [];
  const ocupados = new Set();
  Object.values(selecionadoresState()).forEach(e => { const id = e.coachId || (e.coach && e.coach.id); if(id) ocupados.add(id); });
  const out = [];
  const consider = (c, onde, clube) => {
    if(!c || ocupados.has(c.id) || c.selecao) return;
    // quem acabou de sair desta seleção (despedido, fim de contrato…) não volta logo
    if(Array.isArray(c.historicoSelecao) && c.historicoSelecao.some(h => h.code === base && (state.season - (h.epoca != null ? h.epoca : -99)) < 3)) return;
    if((c.paisOrigem || "pt") !== base) return;
    const idade = staffIdade(c);
    if(idade < 34 || idade > 66) return;
    out.push({ c, onde, clube, score: selecionadorScore(c) });
  };
  Object.values(state.teams).forEach(t => {
    if(t.id === state.userTeamId || t.selecaoNacional || t.nuvemEuropeia || t.equipaPrincipalId) return;
    if(t.treinador && !t.treinadorVacancia) consider(t.treinador, "clube", t);
  });
  staffPool().forEach(c => { if(staffEtapa(c) >= 2 || selecionadorLenda(c)) consider(c, "pool", null); });
  return out.sort((a, b) => b.score - a.score);
}
function selecionadorGerar(code){
  const base = selecionadorBase(code);
  const rng = makeSeededRng(`selecionador-gen:${base}:${state.season}:${uid()}`);
  const banda = SELECIONADOR_BANDA[base] || [7, 11];
  const b = seededRnd(rng, banda[0], banda[1]);
  const stats = {};
  TREINADOR_STATS_COMPETENCIA.forEach(k => { stats[k] = clampAttr(b + seededRnd(rng, -2, 2)); });
  stats.reputacaoExperiencia = clampAttr(b);
  TREINADOR_STATS_PERFIL.forEach(k => { stats[k] = clampAttr(treinadorPerfilRoll(rng)); });
  const idade = seededRnd(rng, 44, 62);
  const nameCountry = typeof selecaoFillerNameCountry === "function" ? selecaoFillerNameCountry(base) : "pt";
  return {
    id: `selecionador-${base}-${uid()}`, nome: randomNameForCountry(nameCountry, rng),
    dataNascimento: makeBirthDate(rng, idade, state.currentDate ? new Date(state.currentDate) : undefined),
    nacionalidade: SELECIONADOR_NAC[base] || "Portuguesa", paisOrigem: normalizeCountryCode(base), stats, clubeActualId: null,
    mandatoAtual: null, historico: [], etapa: 2, funcao: "selecionador", origem: "gerado",
  };
}
function selecionadorNews(date, texto, titulo){
  try { pushNews(date || state.currentDate, texto, "staff", titulo); } catch(e){ console.warn("[HM2027] selecionador news", e); }
}
function selecionadorFichaBtn(c){ return `<button class="news-open-staff" data-staff-act="ficha" data-id="${escapeHtml(c.id)}">Ficha →</button>`; }
function selecionadorNomear(code, date, opts){
  const base = selecionadorBase(code), silent = !!(opts && opts.silent);
  if(selecionadorUserHolds(base)) return null;
  const banda = SELECIONADOR_BANDA[base] || [7, 11];
  const rng = makeSeededRng(`selecionador-nomear:${base}:${state.season}:${state.currentDate ? new Date(state.currentDate).getTime() : 0}`);
  const cands = selecionadorCandidatos(base);
  let pick = null;
  if(cands.length && cands[0].score >= banda[0] - 0.5){
    const top = cands.filter(x => x.score >= cands[0].score - 1.2).slice(0, 4);
    pick = top[seededRnd(rng, 0, top.length - 1)];
  }
  let c, origem, clube = null;
  const e = { code: base, coach: null, coachId: null, clubeId: null, desde: state.season, contratoAte: state.season + SELECIONADOR_CONTRATO_EPOCAS, confianca: SELECIONADOR_CONFIANCA_INICIAL, participacoes: [], titulos: 0, origem: "federacao" };
  if(pick){
    c = pick.c;
    if(pick.onde === "pool"){ staffRemoveFromPool(c); e.coach = c; e.origem = c.origem === "ex-jogador" ? "ex-jogador" : "livre"; c.clubeActualId = null; }
    else { e.coachId = c.id; e.clubeId = pick.clube.id; clube = pick.clube; e.origem = "clube"; }
  } else {
    c = selecionadorGerar(base); e.coach = c;
  }
  c.selecao = { code: base, desde: state.season };
  selecionadoresState()[base] = e;
  if(!silent){
    const nome = selecionadorNomeNacao(base);
    const via = clube ? `, que continua no banco do ${teamLinkHtml(clube.id)} em acumulação` : (e.origem === "ex-jogador" ? `, antigo jogador (${(c.carreiraJogador && c.carreiraJogador.jogos) || "—"} jogos)` : "");
    const user = state.teams[state.userTeamId];
    const lenda = c.origem === "ex-jogador" && c.carreiraJogador && user && c.carreiraJogador.clube === user.name ? ` Foi jogador do ${teamLinkHtml(user.id)}.` : "";
    selecionadorNews(date, `A federação de ${nome} nomeou ${escapeHtml(c.nome)} (${staffIdade(c)} anos) novo selecionador nacional${via}.${lenda} ${selecionadorFichaBtn(c)}`, `Novo selecionador: ${nome}`);
  }
  return e;
}
function selecionadorEnsure(code, silent){
  const base = selecionadorBase(code);
  if(selecionadorUserHolds(base)){ if(state.selecionadores && state.selecionadores[base]) selecionadorLiberar(base, "utilizador", state.currentDate, true); return null; }
  selecionadorValidar(base);
  if(!selecionadoresState()[base]) selecionadorNomear(base, state.currentDate, { silent });
  return selecionadoresState()[base] || null;
}
function selecionadoresEnsureAll(silent){ SELECIONADOR_CODES.forEach(code => { try { selecionadorEnsure(code, silent); } catch(err){ console.warn("[HM2027] selecionadorEnsure", code, err); } }); }

// ---------- saída ----------
function selecionadorLiberar(code, motivo, date, silent){
  const base = selecionadorBase(code), e = selecionadoresState()[base];
  if(!e) return null;
  const c = selecionadorCoach(base);
  const d = date || state.currentDate || new Date();
  if(c){
    delete c.selecao;
    c.historicoSelecao = Array.isArray(c.historicoSelecao) ? c.historicoSelecao : [];
    c.historicoSelecao.unshift({ code: base, nome: selecionadorNomeNacao(base), epoca: state.season, desde: seasonLabel(e.desde), ate: seasonLabel(state.season), titulos: e.titulos || 0, participacoes: (e.participacoes || []).length, motivo });
    if(e.coach){
      if(motivo === "reforma"){ staffArquivar(c, "reforma", null); }
      else { c.semClubeDesde = isoDate(d); c.clubeActualId = null; staffAddToPool(c); }
    }
  }
  selecionadoresHist().unshift({ code: base, nome: selecionadorNomeNacao(base), coach: c ? c.nome : null, desde: seasonLabel(e.desde), ate: seasonLabel(state.season), titulos: e.titulos || 0, motivo });
  if(selecionadoresHist().length > 80) selecionadoresHist().length = 80;
  delete state.selecionadores[base];
  return c;
}

// ---------- carreira: resultados ----------
function selecionadorResultadoEdicao(code, season, prova, placement, seedIdx){
  const base = selecionadorBase(code);
  if(selecionadorUserHolds(base)) return;
  selecionadorEnsure(base, true);   // gravações anteriores à 0.4.31 não têm selecionadores nomeados
  const e = selecionadoresState()[base];
  if(!e) return;
  const c = selecionadorCoach(base);
  const esperado = SELECIONADOR_ESPERADO[clamp(seedIdx >= 0 ? seedIdx : 5, 0, 7)];
  const diff = esperado - placement;
  const delta = clamp(diff * 4, -12, 12) + (placement === 0 ? 6 : 0);
  e.confianca = clamp((Number.isFinite(e.confianca) ? e.confianca : SELECIONADOR_CONFIANCA_INICIAL) + delta, 0, 100);
  const resultado = placement === 0 ? "campeao" : placement === 1 ? "finalista" : placement <= 3 ? "meias" : "quartos";
  e.participacoes.push({ season, prova, resultado, placement, confiancaApos: Math.round(e.confianca) });
  if(e.participacoes.length > 12) e.participacoes = e.participacoes.slice(-12);
  if(placement === 0) e.titulos = (e.titulos || 0) + 1;
  if(c && c.stats){
    const d = placement === 0 ? 0.8 : placement === 1 ? 0.4 : diff > 0 ? 0.2 : diff < -1 ? -0.3 : 0;
    if(d) c.stats.reputacaoExperiencia = clamp(staffExp(c) + d, 0, 20);
  }
  const ult = e.participacoes.slice(-2);
  const crise = e.confianca < SELECIONADOR_CONFIANCA_DEMISSAO || (ult.length === 2 && ult.every(p => p.confiancaApos < SELECIONADOR_CONFIANCA_LIMIAR));
  if(crise && c){
    const nome = selecionadorNomeNacao(base);
    selecionadorLiberar(base, "despedido", state.currentDate);
    selecionadorNews(state.currentDate, `A federação de ${nome} despediu ${escapeHtml(c.nome)}: resultados abaixo do exigido em participações sucessivas. O substituto será conhecido no defeso.`, `Selecionador despedido: ${nome}`);
  }
}
function selecionadoresFimDeEdicao(ed, finalRanking){
  if(!ed || ed.s19 || !Array.isArray(finalRanking)) return;
  finalRanking.forEach((code, placement) => {
    try { selecionadorResultadoEdicao(code, ed.season, ed.prova, placement, ed.allCodes ? ed.allCodes.indexOf(code) : -1); }
    catch(err){ console.warn("[HM2027] selecionadorResultadoEdicao", code, err); }
  });
}

// ---------- manutenção anual (antes de preparar a edição do defeso) ----------
function selecionadoresAnnual(){
  if(state.selecionadoresAnnualSeason === state.season) return;
  state.selecionadoresAnnualSeason = state.season;
  const date = new Date(state.currentDate || new Date());
  SELECIONADOR_CODES.forEach(code => {
    try {
      if(selecionadorUserHolds(code)){ if(selecionadoresState()[code]) selecionadorLiberar(code, "utilizador", date, true); return; }
      selecionadorValidar(code);
      const e = selecionadoresState()[code], c = e ? selecionadorCoach(code) : null;
      const nome = selecionadorNomeNacao(code);
      if(e && c){
        const idade = staffIdade(c, date);
        if(seededRndFloat(makeSeededRng(`sel-ret:${c.id}:${state.season}`), 0, 1) < staffRetireProb(idade)){
          selecionadorLiberar(code, e.coach ? "reforma" : "idade", date);
          selecionadorNews(date, `${escapeHtml(c.nome)} deixa o cargo de selecionador de ${nome}, aos ${idade} anos.`, `Selecionador deixa o cargo: ${nome}`);
        } else if(state.season >= e.contratoAte){
          // renovação: confiança alta renova quase sempre; confiança média, uma vez em duas; e a federação não renova
          // se tiver à vista um candidato claramente melhor (2+ pontos de experiência/currículo).
          const melhor = selecionadorCandidatos(code)[0];
          const pRen = clamp((e.confianca - 30) / 60, 0, 1);
          const renova = e.confianca >= 50 && !(melhor && melhor.score >= selecionadorScore(c) + 2) && seededRndFloat(makeSeededRng(`sel-ren:${c.id}:${state.season}`), 0, 1) < pRen;
          if(renova){ e.contratoAte = state.season + SELECIONADOR_CONTRATO_EPOCAS; }
          else {
            selecionadorLiberar(code, "fim-contrato", date);
            selecionadorNews(date, `A federação de ${nome} não renovou o contrato de ${escapeHtml(c.nome)}.`, `Selecionador sai: ${nome}`);
          }
        }
      }
      selecionadorEnsure(code, false);
    } catch(err){ console.warn("[HM2027] selecionadoresAnnual", code, err); }
  });
}

// ---------- interface ----------
function selecionadorLinhaHtml(code){
  const base = selecionadorBase(code);
  const nome = selecionadorNomeNacao(base);
  const flag = typeof selecaoLogoHtml === "function" ? selecaoLogoHtml(base, "nat-flag") : "";
  if(selecionadorUserHolds(base)){
    const s = ensureManagerCareer().selecaoAtual;
    return `<tr><td style="text-align:left;">${flag} ${escapeHtml(nome)}</td><td style="text-align:left;">${escapeHtml(state.managerName || "Tu")} <span class="helptext">(tu)</span></td><td>—</td><td>—</td><td style="text-align:left;" class="helptext">acumulas com o teu clube</td><td>${escapeHtml(String(s.desde || "—"))}</td><td>${Math.round(s.confiancaFederacao != null ? s.confiancaFederacao : 60)}</td><td>${(s.participacoes || []).filter(p => p.resultado === "campeao").length}</td><td></td></tr>`;
  }
  const e = selecionadorEntry(base), c = selecionadorCoach(base);
  if(!e || !c) return `<tr><td style="text-align:left;">${flag} ${escapeHtml(nome)}</td><td style="text-align:left;" class="helptext">vaga por preencher</td><td>—</td><td>—</td><td></td><td>—</td><td>—</td><td>—</td><td></td></tr>`;
  const clube = e.clubeId && state.teams[e.clubeId] ? state.teams[e.clubeId] : null;
  return `<tr><td style="text-align:left;">${flag} ${escapeHtml(nome)}</td><td style="text-align:left;">${escapeHtml(c.nome)}${clube ? ` <span class="helptext">(${escapeHtml(clube.name)}, acumula)</span>` : (e.origem === "ex-jogador" ? ' <span class="helptext">ex-jogador</span>' : "")}</td><td>${staffIdade(c)}</td><td>${staffStatCell(selecionadorQ(c))}</td><td style="text-align:left;" class="helptext">${escapeHtml(selecionadorEstilo(c))}</td><td>${escapeHtml(seasonLabel(e.desde))}</td><td>${Math.round(e.confianca)}</td><td>${e.titulos || 0}</td><td><button class="btn btn-ghost" data-staff-act="ficha" data-id="${escapeHtml(c.id)}">Ficha</button></td></tr>`;
}
function selecionadoresPanelHtml(){
  selecionadoresEnsureAll(true);
  const rows = SELECIONADOR_CODES.map(selecionadorLinhaHtml).join("");
  return `<div class="eyebrow" style="margin:18px 0 8px;">Selecionadores nacionais</div>
    <p class="helptext" style="margin:0 0 8px;">Topo da pirâmide: os melhores treinadores (e algumas lendas) são chamados pelas federações. O selecionador decide a convocatória e o estilo da seleção; a confiança da federação sobe e desce com os resultados face à expectativa.</p>
    <div style="overflow:auto;"><table class="pm-retro-stat-table" style="text-align:center;"><thead><tr><th style="text-align:left;">Seleção</th><th style="text-align:left;">Selecionador</th><th>Idade</th><th>Nível</th><th style="text-align:left;">Estilo</th><th>Desde</th><th>Confiança</th><th>Títulos</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
// Bloco para o modal da seleção (05-ui-navegacao.js).
function selecionadorBlocoHtml(code){
  const base = selecionadorBase(code);
  selecionadorEnsure(base, true);
  if(selecionadorUserHolds(base)) return `<div class="pm-retro-subline">Selecionador: <b>${escapeHtml(state.managerName || "Tu")}</b> (tu)</div>`;
  const e = selecionadorEntry(base), c = selecionadorCoach(base);
  if(!e || !c) return `<div class="pm-retro-subline">Selecionador: <span class="helptext">vaga por preencher</span></div>`;
  const clube = e.clubeId && state.teams[e.clubeId] ? state.teams[e.clubeId] : null;
  return `<div class="pm-retro-subline">Selecionador: <b>${escapeHtml(c.nome)}</b> <span class="helptext">${staffIdade(c)} anos · nível ${Math.round(selecionadorQ(c))} · ${escapeHtml(selecionadorEstilo(c))}${clube ? ` · acumula com o ${escapeHtml(clube.name)}` : ""} · desde ${escapeHtml(seasonLabel(e.desde))} · confiança ${Math.round(e.confianca)}${e.titulos ? ` · ${e.titulos} título(s)` : ""}</span> <button class="btn btn-ghost" data-staff-act="ficha" data-id="${escapeHtml(c.id)}">Ficha</button></div>`;
}
// Completa a ficha (staffFichaData, 08zn) de quem é — ou foi — selecionador.
function selecionadorDecorarFicha(c, data, clube){
  if(!c || !data) return data;
  const hist = Array.isArray(c.historicoSelecao) ? c.historicoSelecao : [];
  if(c.selecao){
    const e = selecionadoresState()[c.selecao.code];
    const nome = selecionadorNomeNacao(c.selecao.code);
    data.funcaoLabel = `Selecionador de ${nome}${clube ? ` (em acumulação com o ${clube.name})` : ""}`;
    if(!clube) data.clubeNome = `Seleção de ${nome}`;
    const tit = e && e.titulos ? ` · ${e.titulos} título(s)` : "";
    data.origem = `${data.origem || ""} · selecionador desde ${seasonLabel(c.selecao.desde)}${tit}`;
  } else if(hist.length){
    const h = hist[0];
    data.origem = `${data.origem || ""} · ex-selecionador de ${h.nome} (${h.desde}–${h.ate}${h.titulos ? `, ${h.titulos} título(s)` : ""})`;
  }
  return data;
}
