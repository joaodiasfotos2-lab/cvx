// ============================= 07i-competicoes-mundo.js =============================
// Competições do Mundo (0.4.33): Taça Continental, Campeonato Pan-Americano de Clubes e Mundial de
// Clubes. Pedido do João (2026-11-14): "Avança com as novas competições" — as três em cadeia, o
// Mundial de Clubes todos os anos, e um bloco "Competições do Mundo" no Resumo.
//
// Arquitetura: tal como as provas europeias, vivem DENTRO da edição da época (state.europa.edicao)
// e reaproveitam o seu motor — o jogo do utilizador (state.pendingEuropaSlot), finanças, prémios,
// notícias, colisões de calendário, gravação e as vistas de competição. Cada prova é um "bracket"
// guardado em ed.continental / ed.panamericano / ed.mundialclubes (id = chave, por isso a vista é
// "europa-<chave>") e ed.mundo guarda os dados do sorteio.
//
//  - Mundial de Clubes (1–5 Out): 8 clubes — os 4 europeus da Taça Continental (campeão e finalista
//    da Champions League + campeão e finalista da WSE Cup da época anterior), os 2 finalistas do
//    Pan-Americano anterior, o representante da Oceânia (jogo único Melbourne–Mordialloc, decidido
//    no arranque da edição) e o anfitrião (o clube americano mais forte ainda de fora). 2 grupos de
//    4 (uma mão, campo neutro: 1º-4º-5º-8º / 2º-3º-6º-7º por força), meias (1A-2B, 1B-2A) e final.
//  - Pan-Americano de Clubes (2–8 Nov): só nuvem americana (AR 4, CL 2, CO 1 + 1 por força, com
//    sorte própria da época), mesmo formato. Os dois finalistas vão ao Mundial do ano seguinte.
//  - Taça Continental (14–15 Nov): final a quatro com os 4 europeus; meias campeão CL-finalista
//    WSE Cup e finalista CL-campeão WSE Cup, final no dia seguinte, tudo em campo neutro.
//  Época 1 (sem época anterior): campo europeu real da Taça Continental 2026 (Porto, FC Barcelona,
//  CP Calafell — o Pons Lleida não existe no jogo, o 4.º lugar vai para o clube europeu mais forte)
//  e finalistas reais do Pan-Americano 2025 (Andes Talleres, Banco Hispano).
// =====================================================================================
const MUNDO_KEYS = ["mundialclubes", "panamericano", "continental"];
const MUNDO_LABEL = { continental: "Taça Continental", panamericano: "Campeonato Pan-Americano de Clubes", mundialclubes: "Mundial de Clubes" };
const MUNDO_LABEL_CURTO = { continental: "Taça Continental", panamericano: "Pan-Americano", mundialclubes: "Mundial de Clubes" };
const MUNDO_REP_BONUS = { mundialclubes: { campeao: 1.6, final: 0.9, meias: 0.4 }, continental: { campeao: 1.0, final: 0.5, meias: 0.2 } };

function mundoDatasEpoca(season) {
  const y = europaBaseYear(season);
  const cont = nextWeekday(new Date(y, 10, 14), 6);
  return {
    mundialclubes: { grupos: [new Date(y, 9, 1), new Date(y, 9, 2), new Date(y, 9, 3)], meias: new Date(y, 9, 4), final: new Date(y, 9, 5) },
    panamericano: { grupos: [new Date(y, 10, 2), new Date(y, 10, 3), new Date(y, 10, 4)], meias: new Date(y, 10, 6), final: new Date(y, 10, 8) },
    continental: { meias: cont, final: addDays(cont, 1) },
  };
}

// Data de uma fase (usada por europaAdvanceBracketPhase). A final nunca antecede o dia seguinte à
// última meia-final, mesmo que uma colisão de calendário tenha empurrado as meias.
function mundoPhaseDate(compKey, fase) {
  const ed = state.europa && state.europa.edicao, b = ed && ed[compKey];
  if (!b || !b.datas || !b.datas[fase]) return null;
  let d = new Date(b.datas[fase]);
  if (fase === "final") (b.jogos.meias || []).forEach(t => (t.legs || []).forEach(l => { if (l.date && addDays(new Date(l.date), 1) > d) d = addDays(new Date(l.date), 1); }));
  return d;
}

function mundoEuropeusStrongest(ed, excluir, n) {
  const ids = Object.keys(ed.participantes || {}).filter(id => ed.participantes[id] === "champions" && !excluir.includes(id) && state.teams[id]);
  return ids.sort((a, b) => europaClubStrength(b) - europaClubStrength(a)).slice(0, n);
}
// Os 4 europeus: campeão e finalista da Champions, campeão e finalista da WSE Cup da época anterior.
function mundoEuropeus(ed, prev, real2026) {
  let lista = [];
  if (prev && prev.champions && prev.cup) lista = [prev.champions.campeao, prev.champions.runnerUp, prev.cup.campeao, prev.cup.runnerUp];
  else if (real2026) lista = ["porto", "fc-barcelona", "cp-calafell"];
  else {
    const h = (state.europa.historico || []).slice(-1)[0];
    if (h) lista = [h.campeaoChampions, null, h.campeaoCup, null];
  }
  const out = [];
  lista.forEach(id => { if (id && state.teams[id] && !out.includes(id)) out.push(id); });
  // Posições em branco (clube repetido nas duas provas, finalista desconhecido): o clube europeu mais forte ainda de fora.
  const fill = mundoEuropeusStrongest(ed, out, 4 - out.length);
  fill.forEach(id => out.push(id));
  while (out.length < 4) { const x = Object.values(state.teams).filter(t => t && !t.nuvemEuropeia && !t.selecaoNacional && !t.equipaPrincipalId && !out.includes(t.id)).sort((a, b) => europaClubStrength(b.id) - europaClubStrength(a.id))[0]; if (!x) break; out.push(x.id); }
  // Mantém a ordem [CL campeão, CL finalista, Cup campeão, Cup finalista] quando os 4 vêm das provas.
  return out.slice(0, 4);
}
function mundoPanFinalistas(prev, real2026) {
  if (prev && prev.panamericano && prev.panamericano.campeao) return [prev.panamericano.campeao, prev.panamericano.runnerUp].filter(id => id && state.teams[id]);
  if (real2026) return ["andes-talleres", "banco-hispano"].map(s => nuvemMundoClubIds("ar").find(id => id.endsWith("-" + s))).filter(Boolean);
  return [];
}
function mundoAmericasPorForca(jitterSeed) {
  const rng = makeSeededRng(jitterSeed);
  return nuvemMundoClubes().filter(t => t.continenteNuvem === "americas")
    .map(t => ({ id: t.id, pais: t.pais, score: europaClubStrength(t.id) + (rng() * 8 - 4) }))
    .sort((a, b) => b.score - a.score);
}
function mundoPanParticipantes(season) {
  const todos = mundoAmericasPorForca("pan|" + season), out = [];
  [["ar", 4], ["cl", 2], ["co", 1]].forEach(([p, n]) => todos.filter(x => x.pais === p).slice(0, n).forEach(x => out.push(x.id)));
  todos.forEach(x => { if (out.length < 8 && !out.includes(x.id)) out.push(x.id); });
  return out.slice(0, 8);
}
function mundoOceania() {
  const ids = nuvemMundoClubIds("au");
  if (ids.length < 2) return { vencedor: ids[0] || null, finalista: null, res: "" };
  const r = simulateMatchToCompletion(ids[0], ids[1], true, true, "oceania-classificacao");
  const a = r.home > r.away || (r.home === r.away && r.soWinner !== "away");
  return { vencedor: a ? ids[0] : ids[1], finalista: a ? ids[1] : ids[0], res: `${r.home}-${r.away}${r.soWinner ? " (g.p.)" : ""}` };
}
function mundoDividirGrupos(ids, prefixo, nomeProva) {
  const ord = ids.slice().sort((a, b) => europaClubStrength(b) - europaClubStrength(a));
  const A = [0, 3, 4, 7].map(i => ord[i]).filter(Boolean), B = [1, 2, 5, 6].map(i => ord[i]).filter(Boolean);
  return [["A", A], ["B", B]].map(([l, teamIds]) => ({
    id: prefixo + "-" + l.toLowerCase(), nome: `${nomeProva} — Grupo ${l}`, teamIds, fixtures: europaSingleLegFixtures(teamIds),
    currentRound: 0, status: "regular", neutro: true,
  }));
}
function mundoAtribuirDatasGrupos(b, dias, rotulo) {
  b.grupos.forEach(g => g.fixtures.forEach((round, i) => {
    const d = new Date(dias[Math.min(i, dias.length - 1)]);
    avoidLeagueCollisionsOnDate(d, rotulo, round.flatMap(fx => [fx.home, fx.away]));
    round.date = new Date(d);
  }));
}
function mundoNovoBracket(key, datas, extra) {
  return Object.assign({ id: key, label: MUNDO_LABEL[key], fase: "aguardando", jogos: { meias: [], final: [] }, campeao: null, runnerUp: null, neutro: true,
    datas: { meias: datas.meias.toISOString(), final: datas.final.toISOString() } }, extra || {});
}


// ---- Sede e viagens (0.4.34) ----
// Cada edição sorteia, para cada prova, uma cidade de um país com hóquei em patins: Taça Continental
// na Europa, Pan-Americano nas Américas, Mundial de Clubes em qualquer continente. O custo de
// viagem de cada clube participante (jogável) é proporcional à distância em linha reta entre a
// sua cidade e a sede, e paga-se uma vez (ida e volta) no primeiro jogo, mais o alojamento por noite.
const MUNDO_SEDES = [
  // [cidade, país, continente, peso]
  ["Lisboa", "pt", "europa", 1], ["Porto", "pt", "europa", 1], ["Braga", "pt", "europa", 1], ["Oeiras", "pt", "europa", 1],
  ["Barcelona", "es", "europa", 1], ["Reus", "es", "europa", 1], ["Vigo", "es", "europa", 1], ["A Coruña", "es", "europa", 1], ["Alcoi", "es", "europa", 1], ["Oviedo", "es", "europa", 1],
  ["Follonica", "it", "europa", 1], ["Viareggio", "it", "europa", 1], ["Bassano del Grappa", "it", "europa", 1],
  ["Coutras", "fr", "europa", 1], ["La Roche-sur-Yon", "fr", "europa", 1], ["Nantes", "fr", "europa", 1],
  ["Montreux", "ch", "europa", 1], ["Hamm", "de", "europa", 1],
  ["Buenos Aires", "ar", "americas", 1], ["San Juan", "ar", "americas", 1], ["Mendoza", "ar", "americas", 1],
  ["Santiago", "cl", "americas", 1], ["Concepción", "cl", "americas", 1], ["Bogotá", "co", "americas", 1], ["Cali", "co", "americas", 1],
  ["Luanda", "ao", "africa", 0.7], ["Melbourne", "au", "oceania", 0.5],
];
const MUNDO_VIAGEM = { base: 1500, porKmCurto: 7, limiteCurto: 1500, porKmLongo: 2.5, locBase: 600, locPorKm: 3, locLimite: 150, hotelNoite: 1400 };
function mundoSortearSede(key, seed) {
  const cont = key === "continental" || key === "europa" ? ["europa"] : key === "panamericano" ? ["americas"] : null;
  const lista = MUNDO_SEDES.filter(x => !cont || cont.includes(x[2]));
  const rng = makeSeededRng(seed);
  const tot = lista.reduce((a, x) => a + x[3], 0);
  let r = rng() * tot, esc = lista[lista.length - 1];
  for (const x of lista) { r -= x[3]; if (r <= 0) { esc = x; break; } }
  const c = geoCoordsCidade(esc[0]) || GEO_PAIS_CENTRO[esc[1]];
  return { cidade: esc[0], pais: esc[1], paisNome: GEO_PAIS_NOME[esc[1]] || esc[1], continente: esc[2], lat: c[0], lon: c[1] };
}
function mundoSedeTexto(sede) { return sede ? `${sede.cidade} (${sede.paisNome})` : ""; }
function mundoSedeDe(key, fase) {
  const ed = state.europa && state.europa.edicao;
  if (!MUNDO_KEYS.includes(key)) return fase ? europaSedeFase(key, fase) : null;   // 0.4.35: fases neutras da Champions/Cup/Trophy
  return ed && ed.mundo && ed.mundo.sedes ? ed.mundo.sedes[key] || null : null;
}
// 0.4.35 — Provas europeias com fases em campo neutro (Champions: quartos + Final a Quatro; Cup: Final a
// Quatro; Trophy: preliminar, quartos e Final a Quatro): cada "evento" tem a sua cidade (uma cidade europeia
// com hóquei), sorteada quando é preciso e guardada na prova. As meias e a final partilham a cidade.
function europaSedeFase(key, fase) {
  const ed = state.europa && state.europa.edicao, b = ed && ed[key];
  if (!b || !["champions", "cup", "trophy"].includes(key)) return null;
  const ev = fase === "final" ? "meias" : fase;
  if (!b.sedes) b.sedes = {};
  if (!b.sedes[ev]) b.sedes[ev] = mundoSortearSede("europa", `sede|${key}|${ev}|${ed.epoca}|${Math.random()}`);
  return b.sedes[ev];
}
// Custo de viagem (ida e volta) em função da distância, mais alojamento por noite.
function mundoCustoViagemKm(km) {
  const v = MUNDO_VIAGEM;
  if (km < 10) return 0;   // 0.4.36: a sede é na própria cidade do clube
  if (km <= v.locLimite) return Math.round((v.locBase + km * v.locPorKm) / 10) * 10;
  const voo = km <= v.limiteCurto ? km * v.porKmCurto : v.limiteCurto * v.porKmCurto + (km - v.limiteCurto) * v.porKmLongo;
  return Math.round((v.base + voo) / 10) * 10;
}
function mundoDistanciaClubeSede(teamId, key) {
  const t = state.teams[teamId], sede = mundoSedeDe(key);
  if (!t || !sede) return null;
  return geoDistanciaKm(geoCoordsClube(t), [sede.lat, sede.lon]);
}
// Estimativa para a notícia: viagem + alojamento durante a prova (noites = dias entre a 1.ª e a última data possível).
function mundoEstimativaViagem(teamId, key) {
  const km = mundoDistanciaClubeSede(teamId, key);
  if (km == null) return null;
  const ed = state.europa.edicao, b = ed[key];
  const datas = mundoDatasEpoca(ed.epoca)[key];
  const ini = key === "continental" ? datas.meias : datas.grupos[0], fim = datas.final;
  const noites = Math.max(1, Math.round((fim - ini) / 86400000) + 1);
  const hotel = viagemHotel(state.teams[teamId]), nn = km > VIAGEM_SEM_HOTEL_KM ? noites : 0;
  return { km, viagem: mundoCustoViagemKm(km), noites: nn, alojamento: nn * hotel.noite, hotel: hotel.nome };
}
// Chamado a cada jogo neutro da prova: cada clube jogável paga a viagem no 1.º jogo e as noites seguintes.
// 0.4.35: o hotel depende da dimensão do clube (viagemHotel) e uma pausa de mais de 3 dias entre jogos conta
// como nova viagem (ex.: quartos da Champions em abril e Final a Quatro em maio). "fase" só é preciso nas
// provas europeias com sede por fase.
function mundoCustosViagem(key, ids, date, fase) {
  const ed = state.europa && state.europa.edicao, b = ed && ed[key], sede = mundoSedeDe(key, fase);
  if (!b || !sede) return;
  if (!b.viagens) b.viagens = {};
  const d = new Date(date); d.setHours(0, 0, 0, 0);
  ids.forEach(id => {
    const t = state.teams[id];
    if (!t || t.nuvemEuropeia) return;
    let reg = b.viagens[id];
    const km = geoDistanciaKm(geoCoordsClube(t), [sede.lat, sede.lon]) || 0;
    const mult = t.divisaoAtual === "3div" && typeof DIVISION_OPERATING_COST_MULT === "object" ? DIVISION_OPERATING_COST_MULT["3div"] : 1;
    const local = mundoSedeTexto(sede), hotel = viagemHotel(t);
    const gap = reg ? Math.round((d - new Date(reg.ult)) / 86400000) : 0;
    const dorme = km > VIAGEM_SEM_HOTEL_KM;   // 0.4.36: a menos de 150 km regressa-se a casa (sem hotel)
    if (reg && !dorme) reg.ult = d.toISOString();
    if (!reg || gap > 3) {
      const custo = Math.round(mundoCustoViagemKm(km) * mult / 10) * 10;
      addFinanceMovement(t, "despesa", "Deslocação", `${b.label} em ${local}: deslocação de ida e volta (${km.toLocaleString("pt-PT")} km)`, custo, date);
      if (dorme) addFinanceMovement(t, "despesa", "Deslocação", `${b.label} em ${local}: alojamento em ${hotel.nome} (1 noite)`, Math.round(hotel.noite * mult / 10) * 10, date);
      const antes = reg || { km: 0, custo: 0, noites: 0, viagens: 0 };
      b.viagens[id] = { ult: d.toISOString(), km, custo: antes.custo + custo, noites: antes.noites + (dorme ? 1 : 0), viagens: (antes.viagens || 0) + 1 };
    } else if (gap > 0 && dorme) {
      addFinanceMovement(t, "despesa", "Deslocação", `${b.label} em ${local}: alojamento em ${hotel.nome} (${gap} noite${gap > 1 ? "s" : ""})`, Math.round(hotel.noite * gap * mult / 10) * 10, date);
      reg.ult = d.toISOString(); reg.noites += gap;
    }
  });
}
// 0.4.35 — Notícia da sede (e estimativa de custo) quando o clube do utilizador joga uma fase neutra da
// Champions/Cup/Trophy. Corre uma vez por prova e evento.
function europaAnunciarSede(bracket) {
  if (!bracket || !["champions", "cup", "trophy"].includes(bracket.id)) return;
  const fase = bracket.fase, ties = (bracket.jogos && bracket.jogos[fase]) || [], uid = state.userTeamId;
  if (!ties.some(t => t.neutral && (t.home === uid || t.away === uid))) return;
  const ev = fase === "final" ? "meias" : fase;
  if (!bracket.sedesAnunciadas) bracket.sedesAnunciadas = {};
  if (bracket.sedesAnunciadas[ev]) return;
  bracket.sedesAnunciadas[ev] = true;
  const sede = europaSedeFase(bracket.id, fase), t = state.teams[uid];
  if (!sede || !t) return;
  const km = geoDistanciaKm(geoCoordsClube(t), [sede.lat, sede.lon]), hotel = viagemHotel(t);
  const noites = km <= VIAGEM_SEM_HOTEL_KM ? 0 : ev === "meias" ? 2 : 1;
  const faseTxt = ev === "meias" ? "Final a Quatro" : (typeof EUROPA_FASE_LABEL === "object" && EUROPA_FASE_LABEL[fase]) || fase;
  pushNews(state.currentDate, `${competitionLinkHtml("europa-" + bracket.id, bracket.label)} — ${faseTxt} em ${mundoSedeTexto(sede)}. Viagem estimada: ${km.toLocaleString("pt-PT")} km, ${fmtMoney(mundoCustoViagemKm(km))} de deslocação (ida e volta)${noites > 0 ? ` e ${fmtMoney(noites * hotel.noite)} de alojamento em ${hotel.nome} (${noites} noite${noites > 1 ? "s" : ""})` : ", sem alojamento (regressa-se no próprio dia)"}.`, "sistema", `${bracket.label} — sede`);
}
function mundoKeyFromGroup(g) {
  if (!g) return null;
  if (g.provaKey) return g.provaKey;
  const id = String(g.id || "");
  return id.startsWith("pan-") ? "panamericano" : id.startsWith("mundial-") ? "mundialclubes" : null;
}

function mundoInitEdition(ed, prev, opts) {
  opts = opts || {};
  if (!ed || ed.mundo) return;
  const real2026 = !!opts.real2026;
  const datas = mundoDatasEpoca(ed.epoca), hoje = new Date(state.currentDate); hoje.setHours(0, 0, 0, 0);
  const m = ed.mundo = { epoca: ed.epoca, europeus: [], panParticipantes: [], mundialParticipantes: [], oceania: null, host: null, sedes: {} };
  MUNDO_KEYS.forEach(k => { m.sedes[k] = mundoSortearSede(k, `sede|${k}|${ed.epoca}|${Math.random()}`); });
  m.europeus = mundoEuropeus(ed, prev, real2026);
  // Taça Continental — final a quatro.
  if (datas.continental.meias >= hoje && m.europeus.length === 4) {
    const e = m.europeus;
    const b = ed.continental = mundoNovoBracket("continental", datas.continental, { teamIds: e.slice() });
    b.jogos.meias = [[e[0], e[3]], [e[1], e[2]]].map(([x, y]) => europaMakeTie(x, y, [datas.continental.meias], true));
    b.fase = "meias";
    europaAssignTiesCollisionCheck(b.jogos.meias, "a Taça Continental");
  }
  // Pan-Americano — só clubes da nuvem americana.
  if (datas.panamericano.grupos[0] >= hoje) {
    m.panParticipantes = mundoPanParticipantes(ed.epoca);
    if (m.panParticipantes.length === 8) {
      const b = ed.panamericano = mundoNovoBracket("panamericano", datas.panamericano, { teamIds: m.panParticipantes.slice() });
      b.grupos = mundoDividirGrupos(m.panParticipantes, "pan", MUNDO_LABEL.panamericano);
      b.fase = "grupos";
      mundoAtribuirDatasGrupos(b, datas.panamericano.grupos, "o Pan-Americano de Clubes");
    }
  }
  // Mundial de Clubes — 4 europeus + 2 finalistas pan-americanos + Oceânia + anfitrião.
  if (datas.mundialclubes.grupos[0] >= hoje) {
    const pan = mundoPanFinalistas(prev, real2026), ocea = mundoOceania();
    m.oceania = ocea;
    const sel = m.europeus.concat(pan);
    if (ocea.vencedor) sel.push(ocea.vencedor);
    const americas = mundoAmericasPorForca("mundial|" + ed.epoca);
    // Pan-Americano em falta (edições sem registo): os mais fortes.
    americas.forEach(x => { if (sel.length < 7 && !sel.includes(x.id)) sel.push(x.id); });
    const sedeM = m.sedes.mundialclubes;
    const host = (sedeM && americas.find(x => !sel.includes(x.id) && x.pais === sedeM.pais)) || americas.find(x => !sel.includes(x.id));
    if (host) { sel.push(host.id); m.host = host.id; }
    m.mundialParticipantes = sel.filter((id, i) => sel.indexOf(id) === i).slice(0, 8);
    if (m.mundialParticipantes.length === 8) {
      const b = ed.mundialclubes = mundoNovoBracket("mundialclubes", datas.mundialclubes, { teamIds: m.mundialParticipantes.slice() });
      b.grupos = mundoDividirGrupos(m.mundialParticipantes, "mundial", MUNDO_LABEL.mundialclubes);
      b.fase = "grupos";
      mundoAtribuirDatasGrupos(b, datas.mundialclubes.grupos, "o Mundial de Clubes");
    }
  }
  mundoAnunciar(ed);
}

function mundoAnunciar(ed) {
  const uid = state.userTeamId, m = ed.mundo;
  const nome = id => teamLinkHtml(id);
  const sede = k => m.sedes && m.sedes[k] ? ` em ${mundoSedeTexto(m.sedes[k])}` : "";
  const partes = [];
  if (ed.mundialclubes) partes.push(`${competitionLinkHtml("europa-mundialclubes", "Mundial de Clubes")}${sede("mundialclubes")} (1–5 de outubro): ${ed.mundialclubes.teamIds.map(nome).join(", ")}`);
  if (ed.continental) partes.push(`${competitionLinkHtml("europa-continental", "Taça Continental")}${sede("continental")} (final a quatro, ${fmtDateShort(mundoDatasEpoca(ed.epoca).continental.meias)} e ${fmtDateShort(mundoDatasEpoca(ed.epoca).continental.final)}): ${ed.continental.teamIds.map(nome).join(", ")}`);
  if (partes.length) pushNews(state.currentDate, `Competições do Mundo ${ed.seasonLabel} — ${partes.join(" · ")}.`, "sistema", "Competições do Mundo — Apurados");
  const est = k => {
    const e = mundoEstimativaViagem(uid, k);
    return e ? ` Viagem estimada: ${e.km.toLocaleString("pt-PT")} km, ${fmtMoney(e.viagem)} de deslocação (ida e volta)${e.noites > 0 ? ` e ${fmtMoney(e.alojamento)} de alojamento em ${e.hotel} (até ${e.noites} noite${e.noites > 1 ? "s" : ""})` : ", sem alojamento (regressa-se no próprio dia)"}.` : "";
  };
  if (uid && ed.mundialclubes && ed.mundialclubes.teamIds.includes(uid))
    pushNews(state.currentDate, `${teamLinkHtml(uid)} está apurado para o ${competitionLinkHtml("europa-mundialclubes", "Mundial de Clubes")} ${ed.seasonLabel}${sede("mundialclubes")} (1–5 de outubro).${est("mundialclubes")}`, "sistema", `${myTeam().name} no Mundial de Clubes`, { autoAdvanceStop: true });
  if (uid && ed.continental && ed.continental.teamIds.includes(uid))
    pushNews(state.currentDate, `${teamLinkHtml(uid)} está na ${competitionLinkHtml("europa-continental", "Taça Continental")} ${ed.seasonLabel}${sede("continental")}.${est("continental")}`, "sistema", `${myTeam().name} na Taça Continental`, { autoAdvanceStop: true });
}

function mundoStartKnockout(ed, key) {
  const b = ed[key];
  const tabs = b.grupos.map(g => europaGroupStandings(g));
  if (tabs.length < 2 || tabs[0].length < 2 || tabs[1].length < 2) return;
  const uid = state.userTeamId, label = MUNDO_LABEL[key];
  tabs.forEach(tab => tab.forEach((row, pos) => {
    if (pos >= 2 && row.id === uid)
      pushNews(state.currentDate, `${teamLinkHtml(uid)} foi eliminado do ${competitionLinkHtml("europa-" + key, label)} ${ed.seasonLabel} na fase de grupos (${pos + 1}.º lugar do grupo).`, "sistema", `${myTeam().name} eliminado do ${MUNDO_LABEL_CURTO[key]}`, { autoAdvanceStop: true });
  }));
  (b.teamIds || []).forEach(id => visRegistar(ed, id, key, "grupos"));   // 0.4.36
  const data = mundoPhaseDate(key, "meias");
  b.jogos.meias = [[tabs[0][0].id, tabs[1][1].id], [tabs[1][0].id, tabs[0][1].id]].map(([x, y]) => europaMakeTie(x, y, [data], true));
  b.fase = "meias";
  europaAssignTiesCollisionCheck(b.jogos.meias, "o " + label);
  const seeds = b.jogos.meias.flatMap(t => [t.home, t.away]);
  if (seeds.includes(uid)) pushNews(state.currentDate, `${teamLinkHtml(uid)} termina a fase de grupos do ${competitionLinkHtml("europa-" + key, label)} ${ed.seasonLabel} apurado para as meias-finais.`, "sistema", `${myTeam().name} apurado para as meias-finais`, { autoAdvanceStop: true });
}

// Fecho de uma prova: bónus de reputação (só clubes jogáveis) e registo para o histórico.
function mundoFechar(ed, key) {
  const b = ed[key];
  if (!b || b.__fechado) return;
  b.__fechado = true;
  const bonus = MUNDO_REP_BONUS[key];
  if (!bonus) return;
  const dar = (id, v) => {
    const t = state.teams[id];
    if (!t || t.nuvemEuropeia || !v) return;
    t.reputacaoPontos = clamp((t.reputacaoPontos != null ? t.reputacaoPontos : normalizeClubReputation(t.reputacao, t)) + v, 5, 99);
    t.reputacao = reputationFromPoints(t.reputacaoPontos);
  };
  dar(b.campeao, bonus.campeao); dar(b.runnerUp, bonus.final);
  (b.jogos.meias || []).forEach(t => { if (t.vencedor) dar(t.vencedor === t.home ? t.away : t.home, bonus.meias); });
}
// Campos acrescentados à entrada de histórico no fim da época europeia (europaCheckSeasonConcluded).
function mundoResumoHistorico(ed) {
  const g = k => (ed[k] && ed[k].campeao) || null, r = k => (ed[k] && ed[k].runnerUp) || null;
  return { campeaoContinental: g("continental"), finalistaContinental: r("continental"), campeaoPan: g("panamericano"), finalistaPan: r("panamericano"),
    campeaoMundial: g("mundialclubes"), finalistaMundial: r("mundialclubes"), oceania: ed.mundo && ed.mundo.oceania ? ed.mundo.oceania.vencedor : null };
}

function mundoProcess(ed) {
  if (!ed.mundo) {
    const real = ed.epoca === 1 && !(state.europa.historico || []).length;
    try { mundoInitEdition(ed, null, { real2026: real }); } catch (e) { console.warn("[HM2027] competições do mundo", e); ed.mundo = { epoca: ed.epoca, erro: true }; }
  }
  // Saves da 0.4.33 (sem sedes): sorteia agora as sedes que faltam.
  if (ed.mundo && !ed.mundo.erro && !ed.mundo.sedes) { ed.mundo.sedes = {}; MUNDO_KEYS.forEach(k => { ed.mundo.sedes[k] = mundoSortearSede(k, `sede|${k}|${ed.epoca}|${Math.random()}`); }); }
  let any = false;
  for (const key of MUNDO_KEYS) {
    const b = ed[key];
    if (!b || b.fase === "concluida") { if (b && !b.__fechado) mundoFechar(ed, key); continue; }
    if (b.grupos && b.grupos.length) {
      any = europaProcessGroupSetForCurrentDate(b.grupos) || any;
      if (state.matchDayReady) return any;
      if (b.fase === "grupos" && b.grupos.every(g => g.status === "concluida")) { mundoStartKnockout(ed, key); any = true; }
    }
    any = europaProcessBracketForCurrentDate(b) || any;
    if (state.matchDayReady) return any;
    if (b.fase === "concluida") mundoFechar(ed, key);
  }
  return any;
}

// ---- Apoio às vistas ----
function mundoKeyFromCompetitionId(id) {
  const k = String(id || "").replace(/^europa-/, "");
  return MUNDO_KEYS.includes(k) ? k : null;
}
function mundoBracketsAtivos() {
  const ed = state.europa && state.europa.edicao;
  return ed ? MUNDO_KEYS.map(k => ed[k]).filter(Boolean) : [];
}
function mundoClubeParticipa(teamId) {
  return mundoBracketsAtivos().some(b => (b.teamIds || []).includes(teamId));
}

// Cartão "Competições do Mundo" do resumo de fim de época: campeão e finalista de cada prova
// da edição que acabou (a edição em curso ou, se já arquivada, a última do histórico).
function mundoCartaoFimEpoca() {
  const eu = state.europa; if (!eu) return "";
  const ed = eu.edicao;
  const h = (eu.historico || []).slice(-1)[0];
  const dado = (k, hk, fk) => {
    const b = ed && ed[k];
    if (b && b.campeao) return { c: b.campeao, f: b.runnerUp };
    if (h && h[hk]) return { c: h[hk], f: h[fk] };
    return null;
  };
  const linhas = [["Mundial de Clubes", dado("mundialclubes", "campeaoMundial", "finalistaMundial")],
    ["Pan-Americano de Clubes", dado("panamericano", "campeaoPan", "finalistaPan")],
    ["Taça Continental", dado("continental", "campeaoContinental", "finalistaContinental")]].filter(l => l[1]);
  if (!linhas.length) return "";
  const nome = id => state.teams[id] ? teamLinkHtml(id) : "—";
  return `<div class="season-summary-card"><h4>Competições do Mundo</h4>${linhas.map(([n, d]) =>
    `<div><b>${n}</b>: ${nome(d.c)}${d.f ? ` <span style="opacity:.7">(finalista ${nome(d.f)})</span>` : ""}</div>`).join("")}</div>`;
}
