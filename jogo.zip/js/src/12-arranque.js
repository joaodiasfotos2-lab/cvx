  // ============================= 12-arranque.js =============================
  // Arranque do jogo
  // Arranque: nome do treinador -> escolha de clube (ou continuar jogo guardado)

  // =================================================================
  // Fase 11: testes prolongados e diagnostico nao destrutivo
  // =================================================================
  function diagnosticResult(name,group,fn){
    const started=performance.now();
    try{ const detail=fn(); return {name,group,pass:true,detail:String(detail||"OK"),ms:Math.round((performance.now()-started)*100)/100}; }
    catch(error){ return {name,group,pass:false,detail:error&&error.message?error.message:String(error),ms:Math.round((performance.now()-started)*100)/100}; }
  }
  function assertDiagnostic(condition,message){ if(!condition) throw new Error(message); }
  function testFixtureSize(size){
    const ids=Array.from({length:size},(_,i)=>`test-${size}-${i+1}`),fixtures=generateValidatedFixtures(ids);
    validateFixtures(fixtures,ids);
    const games=fixtures.flat(),expectedRounds=(size%2===0?size-1:size)*2;
    assertDiagnostic(fixtures.length===expectedRounds,`Esperadas ${expectedRounds} jornadas; obtidas ${fixtures.length}`);
    assertDiagnostic(!games.some(g=>g.home===g.away),"Foi encontrado um auto-jogo");
    const counts=Object.fromEntries(ids.map(id=>[id,0])); games.forEach(g=>{counts[g.home]++;counts[g.away]++;});
    assertDiagnostic(new Set(Object.values(counts)).size===1,"Número desigual de jogos por equipa");
    if(size%2===1){ const gamesPerRound=fixtures.map(r=>r.length); assertDiagnostic(gamesPerRound.every(n=>n===(size-1)/2),"Bye inválido em competição ímpar"); }
    return `${fixtures.length} jornadas · ${games.length} jogos · zero auto-jogos`;
  }
  // Tamanho esperado por competição: 14 clubes é o normal. As duas mini-ligas de apuramento da
  // 3ª Divisão (Campeão/Promoção) têm 4 cada. As 4 zonas da 3ª Divisão somam 55 clubes no total,
  // mas a distribuição exata entre Sul A e Sul B pode variar ligeiramente de época para época
  // (uma delas fica sempre com 13 em vez de 14, mas não é sempre a mesma — depende de qual
  // sub-zona recebe mais despromovidos nessa transição) — por isso não se verifica um valor
  // fixo por zona individual, só o total da região (verificado à parte, em testCompetitionIntegrity).
  function expectedCompetitionSize(compId){
    if(compId==="3div-norte-a-2026-27"||compId==="3div-norte-b-2026-27"||compId==="3div-sul-a-2026-27"||compId==="3div-sul-b-2026-27") return null;
    if(compId && compId.startsWith("3div-apuramento-")) return 4;
    return 14;
  }
  function testCompetitionIntegrity(){
    Object.values(state.competitions).forEach(c=>{const expected=expectedCompetitionSize(c.id);if(expected!=null)assertDiagnostic(c.teamIds.length===expected,`${c.id}: ${c.teamIds.length} clubes (esperado ${expected})`);assertDiagnostic(new Set(c.teamIds).size===c.teamIds.length,`${c.id}: clubes duplicados`);c.teamIds.forEach(id=>assertDiagnostic(!!state.teams[id],`${c.id}: clube ${id} inexistente`));});
    const norteA=state.competitions["3div-norte-a-2026-27"], norteB=state.competitions["3div-norte-b-2026-27"];
    const sulA=state.competitions["3div-sul-a-2026-27"], sulB=state.competitions["3div-sul-b-2026-27"];
    // 0.2.2: equipas B que cessam a participação (regra A/B) reduzem a 3.ª Divisão — o total esperado é 55 menos as extintas.
    if(norteA && norteB && sulA && sulB){ const extintas=(state.bTeamsExtintas||[]).length; const total=norteA.teamIds.length+norteB.teamIds.length+sulA.teamIds.length+sulB.teamIds.length; assertDiagnostic(total===55-extintas, `CN 3.ª Divisão deviam somar ${55-extintas} clubes (têm ${total})`); }
    return `${Object.keys(state.competitions).length} competições · tamanhos esperados verificados`;
  }
  function testPermanentIds(){
    const clubIds=Object.keys(state.teams); assertDiagnostic(new Set(clubIds).size===clubIds.length,"IDs de clube duplicados");
    let players=0; Object.values(state.teams).forEach(t=>{const ids=t.players.map(p=>p.id);players+=ids.length;assertDiagnostic(ids.every(Boolean),`${t.name}: jogador sem ID`);assertDiagnostic(new Set(ids).size===ids.length,`${t.name}: IDs de jogador duplicados`);});
    return `${clubIds.length} clubes · ${players} jogadores verificados`;
  }
  function testRosterRules(){
    Object.values(state.teams).filter(t=>!t.nuvemExtra&&!t.equipaExtinta).forEach(t=>{assertDiagnostic(t.players.some(p=>p.pos==="GR"),`${t.name}: sem guarda-redes`);assertDiagnostic(t.players.filter(p=>p.pos==="J").length>=4,`${t.name}: menos de 4 jogadores de campo`);});
    return "Todos os plantéis têm GR e mínimo competitivo";
  }
  function testCompetitionProgress(){
    Object.values(state.competitions).forEach(c=>{assertDiagnostic(c.currentRound>=0&&c.currentRound<=c.fixtures.length,`${c.id}: jornada fora dos limites`);c.fixtures.forEach((r,i)=>{const seen=new Set();r.forEach(g=>{assertDiagnostic(!seen.has(g.home)&&!seen.has(g.away),`${c.id}, jornada ${i+1}: equipa duplicada`);seen.add(g.home);seen.add(g.away);});});});
    return "Jornadas e participação por ronda coerentes";
  }
  // Ponto 3.2 da auditoria externa: ao contrário de testCompetitionIntegrity/testCompetitionProgress
  // acima (que verificam tamanhos, duplicados dentro de uma jornada e existência de clubes),
  // validateCompetitionSnapshot confirma que CADA competição gerada é, de facto, um round-robin
  // válido (cada par joga exatamente 2 vezes, casa/fora perfeitamente equilibrados, byes corretos
  // quando o número de clubes é ímpar) e que nenhum jogo envolve um clube fora da própria
  // competição. Corre aqui, sobre dados gerados em memória (nunca sobre uma gravação real de um
  // utilizador), pelo que pode ser estrito — uma falha aqui é sempre um bug real de geração de
  // calendário, nunca um falso positivo de dados legados.
  function testCompetitionSemantics(){
    // 0.4.19: depois da transição de época (subidas/descidas já aplicadas) a composição das competições já é a da
    // época seguinte, mas os calendários ainda são os da anterior até à pré-época — comparação sem sentido.
    if(state.seasonTransitionApplied&&state.inDefeso) return "Transição de época aplicada — calendários antigos até à pré-época (verificação adiada)";
    const problems=[];
    Object.values(state.competitions).forEach(c=>problems.push(...validateCompetitionSnapshot(c, state.teams)));
    assertDiagnostic(!problems.length, problems.slice(0,3).join(" | ")||"calendário semanticamente inválido");
    return `${Object.keys(state.competitions).length} competições confirmadas como round-robin válido`;
  }
  function testSaveRoundTrip(){
    const built=buildSaveObject(),json=JSON.stringify(built),parsed=JSON.parse(json),migrated=migrateSaveObject(parsed);validateMigratedSave(migrated);
    assertDiagnostic(migrated.userTeamId===state.userTeamId,"Clube mudou no round-trip");assertDiagnostic(migrated.competitionState.length===Object.keys(state.competitions).length,"Competições perdidas");
    return `${Math.round(json.length/1024)} KB · schema v${migrated.version}`;
  }
  function testLegacySaveMigration(version){
    const legacy=JSON.parse(JSON.stringify(buildSaveObject()));legacy.version=version;delete legacy.viewedCompetitionId;delete legacy.lastSeasonSummary;
    if(version===6){
      // Consolidação 3.4 (auditoria externa): buildSaveObject já não escreve fixtures/
      // otherCompetitions (só competitionState) — mas uma gravação real da versão 6 nunca teve
      // competitionState (introduzido mais tarde), só estes dois campos legados. Reconstrói-se
      // aqui a forma exata que um save real dessa versão tinha, para continuar a testar
      // genuinamente a migração de gravações antigas (e não só "sem dado nenhum de calendário").
      legacy.fixtures = serializeCompetitionFixtures(state.fixtures);
      legacy.otherCompetitions = Object.values(state.competitions).filter(c=>c.id!==state.userCompetitionId).map(c=>({id:c.id,currentRound:c.currentRound,status:c.status,fixtures:serializeCompetitionFixtures(c.fixtures)}));
      delete legacy.competitionState;delete legacy.transferMarket;delete legacy.internalTransferHistory;
    }
    if(version<=7){delete legacy.lastSeasonSummary;}
    const migrated=migrateSaveObject(legacy);validateMigratedSave(migrated);assertDiagnostic(migrated.version===SAVE_VERSION,"Versão final incorreta");
    return `v${version} → v${SAVE_VERSION} sem perda do clube`;
  }
  function testABRelations(){
    const bs=Object.values(state.teams).filter(t=>t.equipaPrincipalId&&!t.equipaExtinta);bs.forEach(b=>{const a=state.teams[b.equipaPrincipalId];assertDiagnostic(!!a,`${b.name}: principal inexistente`);assertDiagnostic(a.equipaBId===b.id,`${b.name}: relação não recíproca`);});
    return `${bs.length} pares A/B recíprocos`;
  }
  function testContractIntegrity(){
    let checked=0;
    Object.values(state.teams).forEach(t=>{
      t.players.forEach(p=>{
        assertDiagnostic(!!p.contrato,`${t.name}/${p.name}: sem contrato`);
        assertDiagnostic(!!p.contrato.dataInicio && !!p.contrato.dataFim,`${t.name}/${p.name}: contrato sem datas`);
        assertDiagnostic(new Date(p.contrato.dataFim) >= new Date(p.contrato.dataInicio),`${t.name}/${p.name}: dataFim antes de dataInicio`);
        assertDiagnostic(PLAYER_ROLES.includes(p.contrato.papel),`${t.name}/${p.name}: papel de contrato inválido`);
        if(p.preContrato) assertDiagnostic(!!state.teams[p.preContrato.destinoId],`${t.name}/${p.name}: pré-contrato com clube inexistente`);
        checked++;
      });
    });
    const freeAgentIds=(state.freeAgents||[]).map(p=>p.id);
    assertDiagnostic(new Set(freeAgentIds).size===freeAgentIds.length,"IDs duplicados no mercado de jogadores livres");
    const rosterIds=new Set(); Object.values(state.teams).forEach(t=>t.players.forEach(p=>rosterIds.add(p.id)));
    assertDiagnostic(freeAgentIds.every(id=>!rosterIds.has(id)),"Jogador livre ainda consta num plantel");
    return `${checked} contratos verificados · ${freeAgentIds.length} jogadores livres`;
  }
  function testMarketPeriods(){
    assertDiagnostic(marketPeriodForDate(new Date(2026,0,15))==="epoca","Janeiro devia estar em época");
    assertDiagnostic(marketPeriodForDate(new Date(2026,3,15))==="pre-contratos","Abril devia permitir pré-contratos");
    assertDiagnostic(marketPeriodForDate(new Date(2026,6,15))==="defeso","Julho devia estar em defeso");
    return "Janelas de mercado corretas para época, pré-contratos e defeso";
  }
  function testFinanceRevenueMix(){
    const violations=[];
    Object.values(state.teams).forEach(t=>{
      const c=financeConfig(t);
      const nonTicketAnnual=(c.sponsor+c.quotas+c.apoioMunicipal+c.commercial)*12;
      const ticketAnnualEstimate=c.capacity*c.ticket*13*(1-(c.percSocios!=null?c.percSocios:0.3));
      if(nonTicketAnnual<=ticketAnnualEstimate) violations.push(t.name);
    });
    assertDiagnostic(violations.length===0, `Bilheteira domina as receitas em: ${violations.join(", ")}`);
    return `Bilheteira não é fonte dominante em nenhum dos ${Object.keys(state.teams).length} clubes`;
  }
  function testDirectionGoalsIntegrity(){
    let checked=0;
    Object.values(state.teams).forEach(t=>{
      initClubFinance(t);
      const r=evaluateDirectionGoals(t);
      assertDiagnostic(r.passed>=0 && r.passed<=r.total, `${t.name}: objetivos fora do intervalo esperado`);
      assertDiagnostic(Number.isFinite(r.wageRatio), `${t.name}: rácio salarial inválido`);
      checked++;
    });
    return `${checked} clubes com objetivos de direção avaliados sem erro`;
  }
  function testWageHealthTiers(){
    assertDiagnostic(wageHealthTier(0.5)==="saudavel","0.5 devia ser saudável");
    assertDiagnostic(wageHealthTier(0.7)==="atencao","0.7 devia ser atenção");
    assertDiagnostic(wageHealthTier(0.9)==="risco","0.9 devia ser risco");
    return "Rácios de massa salarial classificados corretamente";
  }
  function testFinancialParity(){
    Object.values(state.teams).forEach(t=>{syncClubStrategicProfile(t);const c=financeConfig(t);[c.saldo,c.sponsor,c.commercial,c.wageBudget,c.capacity].forEach(v=>assertDiagnostic(Number.isFinite(v)&&v>0,`${t.name}: configuração financeira inválida`));});
    return "Finanças válidas em todas as divisões";
  }
  function testTenSeasonStructuralSimulation(){
    const comps=Object.values(state.competitions).map(c=>({id:c.id,divisionId:c.divisionId,zona:c.zona,teamIds:c.teamIds.slice()}));
    const history=[];
    for(let season=1;season<=10;season++){
      comps.forEach(c=>{const f=generateValidatedFixtures(c.teamIds);validateFixtures(f,c.teamIds);const expected=expectedCompetitionSize(c.id);if(expected!=null)assertDiagnostic(c.teamIds.length===expected,`${c.id}, época ${season}: dimensão inválida`);});
      const p=comps.find(c=>c.divisionId==="placard"),n=comps.find(c=>c.divisionId==="2div"&&c.zona==="norte"),s=comps.find(c=>c.divisionId==="2div"&&c.zona==="sul");
      const down=p.teamIds.slice(-3),up=[n.teamIds[0],s.teamIds[0],season%2?n.teamIds[1]:s.teamIds[1]];
      p.teamIds=p.teamIds.filter(id=>!down.includes(id)).concat(up);
      n.teamIds=n.teamIds.filter(id=>!up.includes(id));s.teamIds=s.teamIds.filter(id=>!up.includes(id));
      down.forEach((id,i)=>(i<2?n:s).teamIds.push(id));
      while(n.teamIds.length<14){const moved=s.teamIds.pop();n.teamIds.push(moved);} while(s.teamIds.length<14){const moved=n.teamIds.pop();s.teamIds.push(moved);}
      assertDiagnostic([p,n,s].every(c=>c.teamIds.length===14),`Época ${season}: divisão com dimensão incorreta`);
      assertDiagnostic(new Set(p.teamIds.concat(n.teamIds,s.teamIds)).size===42,`Época ${season}: clube duplicado entre divisões`);
      history.push({season,placard:p.teamIds.length,norte:n.teamIds.length,sul:s.teamIds.length});
    }
    return `10 épocas estruturais · ${history.length*3} calendários · 42 clubes únicos/época`;
  }
  // Fase 4: validação final não destrutiva, finanças integrais e auditoria do save.
  function jsonBytes(value){return new Blob([JSON.stringify(value)]).size;}
  function auditSaveGrowth(){
    const save=buildSaveObject(),sections={};let total=0;
    Object.entries(save).forEach(([key,value])=>{const bytes=jsonBytes(value);sections[key]=bytes;total+=bytes;});
    const ordered=Object.entries(sections).sort((a,b)=>b[1]-a[1]).map(([key,bytes])=>({key,bytes,percent:Math.round(bytes/Math.max(1,total)*1000)/10}));
    const counts={clubs:Object.keys(save.teams||{}).length,activePlayers:Object.values(save.teams||{}).reduce((n,t)=>n+(t.players||[]).length,0),freeAgents:(save.freeAgents||[]).length,inactive:(save.inactivePlayers||[]).length,retired:(save.retiredPlayers||[]).length,youthCandidates:(save.youthCandidates||[]).length,news:(save.news||[]).length};
    state.saveGrowthAudit={generatedAt:new Date().toISOString(),season:state.season,totalBytes:total,sections:ordered,counts};return state.saveGrowthAudit;
  }
  // Ponto 3.5 da auditoria externa: o nome anterior desta função ("simulação financeira integral")
  // sugeria uma integração ponta-a-ponta com o motor de jogo real. Na verdade é um modelo
  // financeiro sintético e fechado — projeta receita/despesa mês a mês com uma fórmula própria
  // (assistência fixa por divisão, custos fixos, juro), sem chamar processMonthlyFinances nem
  // simular uma única jornada real. Continua útil (deteta fórmulas que produzam valores não
  // finitos ou estados incoerentes), mas o nome no relatório de diagnósticos foi corrigido para
  // não sugerir mais rigor do que o que a função de facto oferece. Lógica interna inalterada.
  function testFullCalendarFinanceSimulation(){
    const models=Object.values(state.teams).filter(t=>!t.equipaPrincipalId).map(team=>{initClubFinance(team);const f=team.financeiro,c=financeConfig(team);return {id:team.id,division:team.divisaoAtual,balance:f.saldo,debt:(f.divida||0)+(f.creditoUtilizado||0),credit:f.limiteCredito||0,income:(f.receitaMensalPatrocinio||0)+(f.receitaMensalQuotas||0)+(f.receitaMensalApoioMunicipal||0)+(f.receitaMensalComercial||0),cost:financeFixedCosts(team),interest:f.taxaJuroAnual||.08,homeCapacity:c.capacity,ticket:c.ticket,homeCost:c.homeCost,state:null};});
    const distribution={saudavel:0,atencao:0,risco:0,grave:0,critica:0};
    for(let season=1;season<=20;season++)models.forEach(m=>{for(let month=0;month<12;month++){const homeMatches=month>=3&&month<=10?2:0,attendance=m.homeCapacity*(m.division==="placard"?.65:m.division==="2div"?.45:.28),gate=homeMatches*attendance*m.ticket,operating=homeMatches*m.homeCost,interest=(m.debt*m.interest)/12,net=m.income+gate-m.cost-operating-interest;m.balance+=net;if(m.balance<0){const draw=Math.min(-m.balance,Math.max(0,m.credit-m.debt));m.debt+=draw;m.balance+=draw;}}const debtRatio=m.debt/Math.max(1,m.income*12);const runway=m.balance/Math.max(1,Math.max(0,m.cost-m.income));m.state=debtRatio>1||runway<0?"critica":debtRatio>.55?"grave":debtRatio>.25||m.balance<0?"risco":debtRatio>0||runway<2?"atencao":"saudavel";});
    models.forEach(m=>distribution[m.state]++);assertDiagnostic(models.every(m=>Number.isFinite(m.balance)&&Number.isFinite(m.debt)),"Resultado financeiro não finito");assertDiagnostic(Object.values(distribution).reduce((a,b)=>a+b,0)===models.length,"Distribuição financeira incompleta");return `20 épocas × 12 meses × ${models.length} clubes · estados ${JSON.stringify(distribution)}`;
  }
  // Ponto 3.5 da auditoria externa: o nome anterior ("matriz final de carreira de 20 épocas")
  // sugeria uma carreira jogada até ao fim 20 vezes. Na verdade regenera apenas o algoritmo de
  // calendário (generateValidatedFixtures) 20 vezes sobre as MESMAS composições de competição —
  // sem promoções/descidas, sem envelhecimento de jogadores, sem jogos simulados — terminando
  // com uma única verificação de round-trip do save. É um teste estrutural/sintético de robustez
  // do gerador de calendários e da migração, não uma simulação de carreira ponta-a-ponta. Lógica
  // interna inalterada; só o nome no relatório de diagnósticos deixou de prometer mais do que
  // esta função verifica.
  function testTwentySeasonCareerMatrix(){
    const compDefs=Object.values(state.competitions).filter(c=>!["3div-apuramento-campeao-2026-27","3div-apuramento-promocao-2026-27"].includes(c.id)).map(c=>({id:c.id,divisionId:c.divisionId,zona:c.zona,teamIds:c.teamIds.slice()}));let calendars=0,transitions=0;
    for(let season=1;season<=20;season++){compDefs.forEach(c=>{const fixtures=generateValidatedFixtures(c.teamIds);assertDiagnostic(validateFixtures(fixtures,c.teamIds),`${c.id}: calendário inválido na época ${season}`);calendars++;});const all=compDefs.flatMap(c=>c.teamIds);assertDiagnostic(new Set(all).size===all.length,`Clubes duplicados na época ${season}`);transitions++;}
    const save=buildSaveObject(),migrated=migrateSaveObject(JSON.parse(JSON.stringify(save)));validateMigratedSave(migrated);assertDiagnostic(migrated.version===SAVE_VERSION,"Round-trip final falhou");return `20 épocas · ${calendars} calendários · ${transitions} matrizes · save v${SAVE_VERSION}`;
  }
  function registerValidationSnapshot(report,audit){
    if(!Array.isArray(state.validationHistory))state.validationHistory=[];state.validationHistory.unshift({generatedAt:report.generatedAt,season:state.season,passed:report.passed,failed:report.failed,total:report.total,saveBytes:audit.totalBytes,counts:audit.counts});state.validationHistory=state.validationHistory.slice(0,50);
  }
  function testFinancialCrisisLifecycle(){
    const team=JSON.parse(JSON.stringify(myTeam()));initClubFinance(team);const f=team.financeiro;f.estadoCriseFinanceira="normal";f.mesesCriticosConsecutivos=0;f.mesesInsolventeConsecutivos=0;f.mesesRecuperacaoConsecutivos=0;f.historicoCriseFinanceira=[];f.ultimoProcessamentoCriseMensal=null;
    f.divida=Math.max(financeRecurringIncome(team)*13,1000000);f.saldo=0;
    const d1=new Date(2035,0,31),d2=new Date(2035,1,28);processFinancialCrisisMonthly(team,d1);const once=f.mesesCriticosConsecutivos;processFinancialCrisisMonthly(team,d1);assertDiagnostic(f.mesesCriticosConsecutivos===once,"O mesmo fecho mensal avançou a crise duas vezes");processFinancialCrisisMonthly(team,d2);assertDiagnostic(f.estadoCriseFinanceira==="insolvencia","A crise não entrou em insolvência");assertDiagnostic(f.restricoesInsolvencia&&f.orcamentoTransferencias===0,"As restrições não foram aplicadas");return "Progressão mensal idempotente · insolvência e restrições confirmadas";
  }
  // 0.4.18: carreira de treinador — a experiência cresce com as épocas, subir de divisão rende
  // reputação, assumir um clube escolhe a competição pela pertença real, e as caches de equipas
  // controladas / empréstimos dão o mesmo resultado que o cálculo directo.
  function testCarreiraTreinador0418(){
    const g=ensureManagerCareer(),team=state.teams[state.userTeamId];
    const sv={rep:g.reputacao,exp:g.stats.reputacaoExperiencia,av:team.avaliacaoDirecao,pe:state.promotionEvent};
    try{
      g.reputacao=50;g.stats.reputacaoExperiencia=8;
      team.avaliacaoDirecao=[{epoca:"2099/00",passed:0,total:3,champion:false,relegated:false}];
      state.promotionEvent={epoca:"2099/00",promoted:[],promotedFromThird:[team.id],relegated:[],relegatedToThird:[]};
      updateManagerReputationAfterSeason(team);
      assertDiagnostic(g.reputacao>=55,"Subir de divisão com 0/3 objectivos devia render reputação (+5), obteve "+g.reputacao);
      assertDiagnostic(g.stats.reputacaoExperiencia===10,"Experiência devia crescer +2 (época + subida), obteve "+g.stats.reputacaoExperiencia);
      g.reputacao=50;g.stats.reputacaoExperiencia=8;state.promotionEvent={epoca:"2099/00",promoted:[],promotedFromThird:[],relegated:[team.id],relegatedToThird:[]};
      updateManagerReputationAfterSeason(team);
      assertDiagnostic(g.reputacao<50&&g.stats.reputacaoExperiencia===9,"Descida: reputação devia cair e a experiência crescer só +1");
    } finally { g.reputacao=sv.rep;g.stats.reputacaoExperiencia=sv.exp;team.avaliacaoDirecao=sv.av;state.promotionEvent=sv.pe; }
    // caches
    invalidateUserControlledCache();const a=userControlledTeamIds().slice().sort().join(",");invalidateUserControlledCache();assertDiagnostic(userControlledTeamIds().slice().sort().join(",")===a&&a.includes(state.userTeamId),"Cache de equipas controladas inconsistente");
    const direct=t=>{const ids=new Set(clubSquads(t).map(x=>x.id));let o=0;Object.values(state.teams).filter(x=>!String(x.id||"").startsWith("selecaoNacional-")).forEach(x=>x.players.forEach(p=>{if(p.emprestimo&&ids.has(p.emprestimo.ownerId))o+=(p.contrato?.salarioMensal||0)*(1-p.emprestimo.salaryShare/100);}));let i=0;clubSquads(t).forEach(sq=>{i+=sq.players.reduce((sum,p)=>sum+(p.contrato?.salarioMensal||0)*(p.emprestimo?p.emprestimo.salaryShare/100:1),0);});return Math.round(i+o);};
    invalidateLoanIndex();Object.values(state.teams).filter(t=>!t.equipaPrincipalId&&!String(t.id).startsWith("selecaoNacional-")).slice(0,40).forEach(t=>assertDiagnostic(monthlyWageBill(t)===direct(t),"Massa salarial em cache difere do cálculo directo em "+t.name));
  }
  // 0.4.19: o quadro do playoff de cada competição (incl. o resolvido por IA em divisões que o utilizador não joga) sobrevive à gravação/migração.
  function testPlayoffSaved(){
    const comp=Object.values(state.competitions).find(c=>PLAYOFF_DIVISION_CONFIG[c.divisionId]); if(!comp) return "sem competição com playoff";
    const prev=comp.playoff;
    try{
      comp.playoff={competitionId:comp.id,phase:"F",seeds:comp.teamIds.slice(0,8),series:{QF:[],SF:[],F:[{teamTop:comp.teamIds[0],teamBottom:comp.teamIds[1],bestOf:5,games:[{home:comp.teamIds[0],away:comp.teamIds[1],homeScore:3,awayScore:1,soWinner:null}],wins:{[comp.teamIds[0]]:1,[comp.teamIds[1]]:0},winner:null,label:"Final"}]},nextGameDate:new Date(state.currentDate)};
      const migrated=migrateSaveObject(JSON.parse(JSON.stringify(buildSaveObject())));
      const cs=migrated.competitionState.find(c=>c.id===comp.id);
      assertDiagnostic(cs&&cs.playoff&&cs.playoff.series.F[0].games.length===1,"O quadro do playoff perdeu-se na gravação/migração de "+comp.id);
    } finally { comp.playoff=prev; }
    return "quadro do playoff preservado na gravação";
  }
  // 0.4.24: uma candidatura aprovada não muda o utilizador de clube — fica por decidir (aceitar/recusar/pedir mais tempo), com a vaga reservada.
  function testStaffEcossistema(){
    // 0.4.26: staff — adjunto/formação em todos os clubes, reformas, ex-jogadores e contratação.
    const uid=state.userTeamId, user=state.teams[uid];
    const clubes=Object.values(state.teams).filter(t=>!t.equipaPrincipalId&&!t.nuvemEuropeia&&!t.selecaoNacional&&academyEligible(t));
    const sem=clubes.filter(t=>t.id!==uid&&(!t.adjunto||!t.treinadorFormacao));
    assertDiagnostic(sem.length===0,`${sem.length} clubes de IA sem adjunto/treinador de formação`);
    assertDiagnostic(staffRetireProb(59)===0&&staffRetireProb(72)===1&&staffRetireProb(66)>staffRetireProb(63),"Curva de reforma dos treinadores incorrecta");
    const sv={pool:JSON.stringify(state.treinadoresDisponiveis||[]),arq:JSON.stringify(state.staffRetirados||[]),props:JSON.stringify(state.staffPropostas||[]),form:user.treinadorFormacao?JSON.stringify(user.treinadorFormacao):null,vagas:user.staffVagas?JSON.stringify(user.staffVagas):null};
    try{
      const ai=clubes.find(t=>t.id!==uid&&t.players.length>0);
      const base=ai.players.find(p=>p.pos!=="GR")||ai.players[0];
      let criou=null;
      for(let i=0;i<60&&!criou;i++){
        const fake=JSON.parse(JSON.stringify(base)); fake.id=`diag-ex-${i}`; fake.reputacaoJogador=95; fake.career={...(fake.career||{}),jogos:700};
        criou=staffFromRetiredPlayer(fake,ai);
      }
      assertDiagnostic(!!criou&&criou.origem==="ex-jogador","Nenhum ex-jogador passou a treinador em 60 tentativas");
      assertDiagnostic(staffPool().some(c=>c.id===criou.id),"O ex-jogador não ficou disponível no pool");
      assertDiagnostic(staffEtapa(criou)===1,"Um ex-jogador de elite devia entrar como adjunto");
      // contratar para a formação do utilizador
      const cand=JSON.parse(JSON.stringify(criou)); cand.id="diag-cand"; cand.etapa=0; cand.stats.reputacaoExperiencia=3; cand.stats.desenvolvimentoJovens=14;
      state.treinadoresDisponiveis.unshift(cand);
      const velho=user.treinadorFormacao;
      const r=staffContratar("formacao",cand.id);
      assertDiagnostic(r.ok,"Contratar falhou: "+(r.reason||""));
      assertDiagnostic(user.treinadorFormacao&&user.treinadorFormacao.id===cand.id,"O treinador de formação não foi instalado");
      assertDiagnostic(!velho||staffPool().some(c=>c.id===velho.id),"O treinador anterior não voltou ao pool");
      assertDiagnostic(staffFormacaoMult(user)>1,"O treinador de formação não afecta a Academia");
      const sv2=JSON.parse(JSON.stringify(buildSaveObject()));
      assertDiagnostic(sv2.staffProcessedSeason!==undefined&&Array.isArray(sv2.staffRetirados),"O staff não foi gravado");
      return `${clubes.length} clubes com staff; ex-jogador ${criou.nome} → adjunto; contratação e gravação OK`;
    } finally {
      state.treinadoresDisponiveis=JSON.parse(sv.pool); state.staffRetirados=JSON.parse(sv.arq); state.staffPropostas=JSON.parse(sv.props);
      user.treinadorFormacao=sv.form?JSON.parse(sv.form):null; user.staffVagas=sv.vagas?JSON.parse(sv.vagas):user.staffVagas;
    }
  }
  function testStaffEspecialistas(){
    // 0.4.27: especialistas (preparador físico, treinador de GR, scout principal) com efeito real e moderado.
    const uid=state.userTeamId, user=state.teams[uid];
    const clubes=Object.values(state.teams).filter(t=>!t.equipaPrincipalId&&!t.nuvemEuropeia&&!t.selecaoNacional&&academyEligible(t));
    ["fisico","gr","scout"].forEach(fn=>{
      const sem=clubes.filter(t=>t.id!==uid&&!t[STAFF_FUNCOES[fn].slot]);
      assertDiagnostic(sem.length===0,`${sem.length} clubes de IA sem ${STAFF_FUNCOES[fn].label}`);
      assertDiagnostic(staffPool().length>=0&&staffPoolFor(fn).length>=8,`Pool de ${fn} demasiado pequeno (${staffPoolFor(fn).length})`);
    });
    // neutralidade: a média dos clubes de IA fica perto de 0 e nunca sai dos limites
    const rels=clubes.filter(t=>t.id!==uid).map(t=>staffRel(t,"fisico"));
    const media=rels.reduce((a,b)=>a+b,0)/rels.length;
    assertDiagnostic(Math.abs(media)<3,`Efeito médio dos preparadores físicos descentrado (${media.toFixed(2)})`);
    const lim=(v,a,b)=>v>=a&&v<=b;
    clubes.forEach(t=>{ assertDiagnostic(lim(staffFisicoInjuryMult(t),0.9,1.08)&&lim(staffGRDevMult(t),0.91,1.12)&&lim(staffGRGoalMult(t),0.97,1.025),`Efeito fora dos limites em ${t.id}`); });
    const sv={slot:{fisico:user.preparadorFisico,gr:user.treinadorGR,scout:user.scoutPrincipal},pool:JSON.stringify(state.staffEspecialistas||[]),pool2:JSON.stringify(state.treinadoresDisponiveis||[])};
    try{
      const best=staffGenerateEsp(user,"fisico",false,100); STAFF_ESP.fisico.forEach(k=>best.espStats[k]=18);
      const worst=staffGenerateEsp(user,"fisico",false,100); STAFF_ESP.fisico.forEach(k=>worst.espStats[k]=3);
      user.preparadorFisico=best; const a=injuryChance?staffFisicoInjuryMult(user):1;
      user.preparadorFisico=worst; const b=staffFisicoInjuryMult(user);
      user.preparadorFisico=null; const v=staffFisicoInjuryMult(user);
      assertDiagnostic(a<1&&b>a&&v>=1,`Preparador físico sem efeito coerente (${a.toFixed(3)}/${b.toFixed(3)}/${v.toFixed(3)})`);
      assertDiagnostic(medicalInjuryMult(user)>0,"medicalInjuryMult inválido");
      // contratar via pool
      const cand=staffGenerateEsp(user,"gr",true,60); state.staffEspecialistas.unshift(cand);
      const r=staffContratar("gr",cand.id);
      assertDiagnostic(r.ok&&user.treinadorGR&&user.treinadorGR.id===cand.id,"Contratar treinador de GR falhou: "+(r.reason||""));
      assertDiagnostic(typeof staffEfeitoTexto("gr",user)==="string"&&staffEfeitoTexto("gr",user).length>0,"Texto de efeito vazio");
      // painel Staff renderiza
      const box=document.getElementById("staffContent");
      if(box){ renderStaffPanel(); assertDiagnostic(box.innerHTML.indexOf("Preparador físico")>=0,"Painel Staff sem linhas dos especialistas"); }
      const sv2=JSON.parse(JSON.stringify(buildSaveObject()));
      assertDiagnostic(Array.isArray(sv2.staffEspecialistas),"staffEspecialistas não foi gravado");
      return `${clubes.length} clubes com 3 especialistas; efeito médio ${media.toFixed(2)}; físico ${staffPct(a)}→${staffPct(b)}`;
    } finally {
      user.preparadorFisico=sv.slot.fisico; user.treinadorGR=sv.slot.gr; user.scoutPrincipal=sv.slot.scout;
      state.staffEspecialistas=JSON.parse(sv.pool); state.treinadoresDisponiveis=JSON.parse(sv.pool2);
    }
  }
  function testNuvemSemFinancas(){
    // 0.4.37: os clubes da nuvem não têm finanças.
    const t=Object.values(state.teams).find(x=>x.nuvemEuropeia&&!x.equipaPrincipalId); if(!t) return;
    initClubFinance(t); const s0=t.financeiro.saldo, m0=(t.financeiro.movimentos||[]).length;
    addFinanceMovement(t,"despesa","Teste","Teste",50000,state.currentDate); addFinanceMovement(t,"receita","Teste","Teste",70000,state.currentDate);
    assertDiagnostic(t.financeiro.saldo===s0&&(t.financeiro.movimentos||[]).length===m0,"Um clube da nuvem não devia ter movimentos financeiros");
    const sv={s:t.financeiro.saldo,d:t.financeiro.divida}; t.financeiro.saldo=1000; t.financeiro.divida=5000;
    try{ nuvemFinancasNeutras(); assertDiagnostic(t.financeiro.saldo>=200000&&t.financeiro.divida===0,"Estado financeiro neutro e sem dívida"); }
    finally{ t.financeiro.saldo=sv.s; t.financeiro.divida=sv.d; }
  }
  function testVisibilidade(){
    // 0.4.36: visibilidade internacional (esta época + metade da anterior) e os seus efeitos.
    const ed=state.europa&&state.europa.edicao; if(!ed) return;
    const sv=JSON.stringify(state.europa.visib||null);
    const id="__vis_teste__", t=state.teams[state.userTeamId];
    try{
      state.europa.visib={epoca:ed.epoca,cur:{},prev:{}};
      assertDiagnostic(visClube(id)===0,"Sem pontos, sem visibilidade");
      visRegistar(ed,id,"mundialclubes","grupos"); visRegistar(ed,id,"mundialclubes","vencedor"); visRegistar(ed,id,"mundialclubes","meias");
      assertDiagnostic(Math.abs(visClube(id)-1)<1e-9,"Campeão do Mundial = 1,0 (fica o melhor resultado): "+visClube(id));
      visRegistar(ed,id,"champions","final"); assertDiagnostic(Math.abs(visClube(id)-1)<1e-9,"Um resultado pior não baixa o melhor");
      state.europa.visib={epoca:ed.epoca-1,cur:{[id]:100},prev:{[id]:60}};
      assertDiagnostic(Math.abs(visClube(id)-0.5)<1e-9,"Na época seguinte conta metade: "+visClube(id));
      assertDiagnostic(state.europa.visib.epoca===ed.epoca&&state.europa.visib.cur[id]===undefined,"A época nova recomeça do zero");
      state.europa.visib={epoca:ed.epoca-2,cur:{[id]:100},prev:{}};
      assertDiagnostic(visClube(id)===0,"Duas épocas depois desvanece-se por completo");
      // efeitos: o mesmo clube com e sem visibilidade
      const alvo=state.userTeamId, base=(()=>{ state.europa.visib={epoca:ed.epoca,cur:{},prev:{}}; return {ap:clubAppeal(t),pr:competitionPrestigeForTeam(t),mo:typeof patMomento==="function"?patMomento(t):0}; })();
      state.europa.visib={epoca:ed.epoca,cur:{[alvo]:100},prev:{}};
      assertDiagnostic(clubAppeal(t)>base.ap,"A visibilidade devia subir a atratividade do clube");
      assertDiagnostic(competitionPrestigeForTeam(t)<=100,"O prestígio nunca passa de 100");
      if(typeof patMomento==="function") assertDiagnostic(patMomento(t)>base.mo-1e-9,"A visibilidade não devia baixar o momento comercial");
      const p0={id:"__p__",age:26,satisfacao:60,__recentPlayed:[true,true,true,true,true]};
      state.europa.visib={epoca:ed.epoca,cur:{},prev:{}}; const s0=computeSatisfactionTarget(p0,t);
      state.europa.visib={epoca:ed.epoca,cur:{[alvo]:100},prev:{}}; const s1=computeSatisfactionTarget(p0,t);
      assertDiagnostic(s1>s0||s0>=99.5,"A visibilidade devia subir a satisfação-alvo dos jogadores ("+s0+" → "+s1+")");
      // TV e merchandising de jogos internacionais
      const f=t.financeiro, n0=(f.movimentos||[]).length; const rec=()=>(f.movimentos||[]).filter(m=>m.type==="receita"&&(m.category==="Televisão"||m.category==="Merchandising")&&/Mundial de Clubes/.test(m.description||"")).length;
      const r0=rec(); visJogoInternacional("mundialclubes","meias",alvo,"outro",true); assertDiagnostic(rec()-r0===2,"Jogo neutro: TV + merchandising ("+(rec()-r0)+")");
      const r1=rec(); visJogoInternacional("mundialclubes","grupo","outro","outro2",true); assertDiagnostic(rec()===r1,"Só conta o jogo do clube do utilizador");
    } finally { state.europa.visib=JSON.parse(sv); }
  }
  function testViagemEuropa(){
    // 0.4.35: deslocações europeias por distância + hotel por dimensão do clube + sede das fases neutras.
    assertDiagnostic(viagemHotel({reputacao:97}).noite>viagemHotel({reputacao:80}).noite&&viagemHotel({reputacao:80}).noite>viagemHotel({reputacao:70}).noite&&viagemHotel({reputacao:70}).noite>viagemHotel({reputacao:55}).noite,"O hotel devia subir com a reputação do clube");
    assertDiagnostic(/médio/.test(viagemHotel({reputacao:70}).nome),"Um clube médio devia ficar num hotel médio");
    assertDiagnostic(viagemNoitesEuropa(400)===1&&viagemNoitesEuropa(1500)===2,"Noites por distância");
    const T=n=>Object.values(state.teams).find(t=>t.name===n);
    const porto=T("FC Porto"), oeiras=T("AD Oeiras"), barca=T("FC Barcelona"), liceo=T("HC Liceo"), trissino=T("HC Trissino");
    if(porto&&oeiras&&barca&&liceo&&trissino){
      const a=viagemInfo(barca,porto,null), b=viagemInfo(barca,{...porto,reputacao:oeiras.reputacao},null), c=viagemInfo(liceo,porto,null), d=viagemInfo(trissino,porto,null);
      [a,b,c,d].forEach(x=>assertDiagnostic(x.tier===3&&x.europa&&x.custo===x.europa.voo+x.europa.alojamento,"Custo europeu = viagem + alojamento"));
      assertDiagnostic(a.europa.km>850&&a.europa.km<1250,"Porto–Barcelona km: "+a.europa.km);
      assertDiagnostic(c.europa.km<a.europa.km&&c.custo<a.custo,"Mais perto devia custar menos (Liceo "+c.custo+" vs Barcelona "+a.custo+")");
      assertDiagnostic(d.europa.km>a.europa.km&&d.custo>a.custo,"Itália mais longe devia custar mais");
      assertDiagnostic(a.europa.km===b.europa.km&&a.europa.voo===b.europa.voo,"Mesmo trajeto, mesma viagem");
      assertDiagnostic(a.europa.alojamento>b.europa.alojamento,"O grande (Porto) devia pagar mais de hotel do que o médio (Oeiras)");
      assertDiagnostic(a.custo!==14000&&b.custo!==14000,"O valor fixo antigo já não devia aplicar-se");
    }
    const ed=state.europa&&state.europa.edicao, uid=state.userTeamId, team=state.teams[uid];
    if(ed&&ed.champions&&team&&!team.nuvemEuropeia){
      const b=ed.champions, sv={v:b.viagens,s:b.sedes}; b.viagens={}; const hamm={cidade:"Hamm",pais:"de",paisNome:"Alemanha",continente:"europa",lat:51.68,lon:7.82}; b.sedes={quartos:hamm,meias:{...hamm}};
      const mov=()=> (team.financeiro&&team.financeiro.movimentos||[]).filter(m=>/WSE Champions League em/.test(m.description||"")).length;
      try{
        const q=europaSedeFase("champions","quartos"), m1=europaSedeFase("champions","meias"), f=europaSedeFase("champions","final");
        assertDiagnostic(q&&q.continente==="europa"&&q.cidade,"Sede dos quartos");
        assertDiagnostic(europaSedeFase("champions","quartos")===q,"A sede devia ficar guardada");
        assertDiagnostic(f===m1,"Meias e final partilham a sede");
        assertDiagnostic(mundoSedeDe("champions","quartos")===q&&mundoSedeDe("champions")===null,"mundoSedeDe por fase");
        const m0=mov(); mundoCustosViagem("champions",[uid],new Date(2027,3,21),"quartos"); assertDiagnostic(mov()-m0===2,"Quartos: viagem + alojamento");
        mundoCustosViagem("champions",[uid],new Date(2027,4,9),"meias"); assertDiagnostic(mov()-m0===4,"Final a Quatro, semanas depois, conta como nova viagem");
        mundoCustosViagem("champions",[uid],new Date(2027,4,10),"final"); assertDiagnostic(mov()-m0===5&&b.viagens[uid].viagens===2,"Domingo: só mais uma noite ("+(mov()-m0)+")");
      } finally { b.viagens=sv.v; b.sedes=sv.s; }
    }
  }
  function testViagemMundoEReputacao(){
    // 0.4.34: sede sorteada, custo de viagem por distância e reputação do treinador durante a época.
    const lis=geoCoordsCidade("Lisboa"), bcn=geoCoordsCidade("Barcelona"), bsas=geoCoordsCidade("Buenos Aires");
    const dLB=geoDistanciaKm(lis,bcn), dLA=geoDistanciaKm(lis,bsas);
    assertDiagnostic(dLB>900&&dLB<1100,"Lisboa–Barcelona fora de ~1000 km: "+dLB);
    assertDiagnostic(dLA>9500&&dLA<10800,"Lisboa–Buenos Aires fora de ~10 000 km: "+dLA);
    assertDiagnostic(geoDistanciaKm(lis,lis)===0,"Distância a si próprio");
    assertDiagnostic(geoCoordsCidade("Paço de Arcos, Oeiras")&&geoCoordsCidade("Vilarinho, Coimbra"),"Cidades com acentos/sufixos");
    assertDiagnostic(mundoCustoViagemKm(0)===0,"Sede na própria cidade: sem custo de viagem");
    const c100=mundoCustoViagemKm(100), c1000=mundoCustoViagemKm(1000), c3000=mundoCustoViagemKm(3000), c10000=mundoCustoViagemKm(10000);
    assertDiagnostic(c100<c1000&&c1000<c3000&&c3000<c10000,"O custo deve crescer com a distância");
    assertDiagnostic(c1000>=8000&&c1000<=10000&&c10000>30000&&c10000<45000,"Calibração do custo: "+[c1000,c10000].join("/"));
    for(let i=0;i<40;i++){
      const eu=mundoSortearSede("continental","t"+i), am=mundoSortearSede("panamericano","t"+i), mu=mundoSortearSede("mundialclubes","t"+i);
      assertDiagnostic(eu.continente==="europa"&&am.continente==="americas","Continente da sede");
      assertDiagnostic([eu,am,mu].every(x=>GEO_PAIS_NOME[x.pais]&&Number.isFinite(x.lat)&&Number.isFinite(x.lon)&&x.cidade),"Sede incompleta");
    }
    const conts=new Set(Array.from({length:80},(_,i)=>mundoSortearSede("mundialclubes","m"+i).continente)); assertDiagnostic(conts.size>=3,"O Mundial devia sortear vários continentes");
    const ed=state.europa&&state.europa.edicao;
    if(ed&&ed.mundo&&ed.mundo.sedes) MUNDO_KEYS.forEach(k=>assertDiagnostic(ed.mundo.sedes[k]&&ed.mundo.sedes[k].cidade,"Falta a sede de "+k));
    // Custos: 1.º jogo paga viagem + 1 noite; mesmo dia não repete; dia seguinte paga a noite.
    const uid=state.userTeamId, team=state.teams[uid];
    if(ed&&ed.mundo&&ed.mundo.sedes&&ed.mundialclubes&&team&&!team.nuvemEuropeia){
      const b=ed.mundialclubes, sv=b.viagens; b.viagens={};
      const mov=()=> (team.financeiro&&team.financeiro.movimentos||[]).filter(m=>/Mundial de Clubes em/.test(m.description||"")).length;
      const d0=new Date(2026,9,1);
      try{
        const m0=mov(); mundoCustosViagem("mundialclubes",[uid],d0); const m1=mov();
        const kmT=mundoDistanciaClubeSede(uid,"mundialclubes"), dormeT=kmT>VIAGEM_SEM_HOTEL_KM;
        assertDiagnostic(m1-m0===(dormeT?2:1),"1.º jogo: viagem"+(dormeT?" + alojamento":" (sem hotel a menos de 150 km)")+" ("+(m1-m0)+")");
        mundoCustosViagem("mundialclubes",[uid],d0); assertDiagnostic(mov()===m1,"O mesmo dia não pode cobrar duas vezes");
        mundoCustosViagem("mundialclubes",[uid],new Date(2026,9,3)); assertDiagnostic(dormeT?(mov()===m1+1&&b.viagens[uid].noites===3):(mov()===m1&&b.viagens[uid].noites===0),"Noites seguintes");
      } finally { b.viagens=sv; }
    }
    // Reputação do treinador: ajustes com tetos, jogos de liga e histórico.
    const g=ensureManagerCareer(), sv={rep:g.reputacao,max:g.reputacaoMaxima,rp:g.repProvas,rh:g.repHistorico};
    try{
      g.reputacao=60; g.repProvas=null; g.repHistorico=[];
      gestorRepRegisto();
      gestorRepAplicar(5,"teste","prova"); gestorRepAplicar(20,"teste","prova");
      assertDiagnostic(Math.abs(g.reputacao-72)<0.01,"Teto de ganho das provas (esperado 72): "+g.reputacao);
      gestorRepAplicar(-30,"teste","prova"); assertDiagnostic(Math.abs(g.reputacao-64)<0.01,"Teto de perda das provas (esperado 64): "+g.reputacao);
      const antes=g.reputacao; for(let i=0;i<80;i++) gestorRepAplicar(0.5,null,"liga");
      assertDiagnostic(Math.abs(g.reputacao-antes-GREP.ligaTeto)<0.01,"Teto da liga");
      assertDiagnostic(g.repHistorico.length>=3&&g.repHistorico[0].texto==="teste"||g.repHistorico.length>=3,"Histórico da reputação");
      g.reputacao=98; g.repProvas=null; gestorRepRegisto(); gestorRepAplicar(5,"x","prova"); assertDiagnostic(g.reputacao<=99,"Máximo 99");
      // Jogo de liga: vitória sobre mais fraco vale pouco, derrota com mais fraco custa, vitória sobre mais forte vale mais.
      const outro=Object.values(state.teams).filter(t=>!t.nuvemEuropeia&&!t.selecaoNacional&&!t.equipaPrincipalId&&t.id!==uid);
      const forte=outro.slice().sort((a,b)=>gestorRepPontosClube(b)-gestorRepPontosClube(a))[0], fraco=outro.slice().sort((a,b)=>gestorRepPontosClube(a)-gestorRepPontosClube(b))[0];
      const delta=(opp,hs,as)=>{ g.reputacao=60; g.repProvas=null; g.repHistorico=[]; gestorRepRegisto(); const a=g.reputacao; gestorRepJogoLiga(uid,opp.id,hs,as,null); return g.reputacao-a; };
      const vF=delta(fraco,5,1), dF=delta(fraco,1,5), vS=delta(forte,5,1), dS=delta(forte,1,5);
      assertDiagnostic(dF<0&&vS>0&&vS>vF&&dF<dS,"Resultados de liga: "+[vF,dF,vS,dS].map(x=>x.toFixed(3)).join("/"));
    } finally { g.reputacao=sv.rep; g.reputacaoMaxima=sv.max; g.repProvas=sv.rp; g.repHistorico=sv.rh; }
    assertDiagnostic(typeof gestorRepHistoricoHtml(3)==="string"&&gestorRepFmt(71.26)==="71,3","Formatação da reputação");
    return "geografia, custos, sedes e reputação OK";
  }
  function testMundo(){
    // 0.4.33: Mundial de Clubes, Pan-Americano de Clubes e Taça Continental.
    const d1=mundoDatasEpoca(1), dia=(x)=>x.getFullYear()+"-"+(x.getMonth()+1)+"-"+x.getDate();
    assertDiagnostic(dia(d1.mundialclubes.grupos[0])==="2026-10-1"&&dia(d1.mundialclubes.final)==="2026-10-5","Datas do Mundial de Clubes");
    assertDiagnostic(dia(d1.panamericano.grupos[0])==="2026-11-2"&&dia(d1.panamericano.final)==="2026-11-8","Datas do Pan-Americano");
    assertDiagnostic(d1.continental.meias.getDay()===6&&dia(d1.continental.final)!==dia(d1.continental.meias),"Taça Continental: meias ao sábado e final no dia seguinte");
    const ids=Object.values(state.teams).filter(t=>t.nuvemMundo).slice(0,8).map(t=>t.id);
    assertDiagnostic(ids.length===8,"Faltam clubes americanos para o teste");
    const gr=mundoDividirGrupos(ids,"teste","Prova de teste");
    assertDiagnostic(gr.length===2&&gr.every(g=>g.teamIds.length===4&&g.neutro&&g.fixtures.length===3),"Divisão em 2 grupos de 4 com 3 jornadas");
    assertDiagnostic(new Set(gr.flatMap(g=>g.teamIds)).size===8,"Grupos com clubes repetidos");
    const h=mundoResumoHistorico({mundialclubes:{campeao:"a",runnerUp:"b"},panamericano:{campeao:"c",runnerUp:"d"},continental:{campeao:"e",runnerUp:"f"},mundo:{oceania:{vencedor:"g"}}});
    assertDiagnostic(h.campeaoMundial==="a"&&h.finalistaMundial==="b"&&h.campeaoPan==="c"&&h.finalistaPan==="d"&&h.campeaoContinental==="e"&&h.finalistaContinental==="f"&&h.oceania==="g","Histórico das 3 provas");
    assertDiagnostic(mundoKeyFromCompetitionId("europa-continental")==="continental"&&mundoKeyFromCompetitionId("europa-cup")===null,"Chave a partir do id da competição");
    const ed=state.europa&&state.europa.edicao;
    if(ed&&ed.mundo){
      MUNDO_KEYS.forEach(k=>{
        const b=ed[k]; if(!b) return;
        assertDiagnostic(new Set(b.teamIds).size===b.teamIds.length,k+": clubes repetidos");
        if(k==="continental") assertDiagnostic(b.teamIds.length===4&&b.teamIds.every(id=>!state.teams[id].nuvemEuropeia),"Continental: 4 clubes jogáveis");
        else assertDiagnostic(b.teamIds.length===8&&b.grupos.length===2,k+": 8 clubes em 2 grupos");
        if(k==="panamericano") assertDiagnostic(b.teamIds.every(id=>state.teams[id].nuvemMundo),"Pan-Americano só com clubes da nuvem americana");
        assertDiagnostic(b.teamIds.every(id=>state.teams[id].nuvemEuropeia?state.teams[id].nuvemMundo||true:true),k+": clube inexistente");
      });
      const des=europaSerializeEdicao(ed), back=europaDeserializeEdicao(JSON.parse(JSON.stringify(des)));
      MUNDO_KEYS.forEach(k=>assertDiagnostic(!!ed[k]===!!back[k]&&(!ed[k]||(back[k].teamIds.length===ed[k].teamIds.length&&back[k].fase===ed[k].fase)),k+": perde-se na gravação"));
    }
    const html=rsMundoHtml();
    assertDiagnostic(!ed||!ed.mundo||(html.indexOf("Competições do Mundo")>=0&&(html.match(/rs-mundo-t /g)||[]).length===rsMundoDados().length),"Bloco do Resumo");
    assertDiagnostic(typeof mundoCartaoFimEpoca()==="string","Cartão de fim de época");
    return "datas, grupos, histórico, gravação e Resumo OK";
  }
  function testNuvemMundo(){
    // 0.4.32: nuvem americana e oceânica — 26 clubes reais, nomes reais onde existem, resto inventado, fora do mercado.
    const defs=nuvemMundoDefs(), clubes=defs.map(d=>state.teams[nuvemMundoTeamId(d)]);
    assertDiagnostic(defs.length===26&&clubes.every(Boolean),"Faltam clubes da nuvem do mundo ("+clubes.filter(Boolean).length+"/26)");
    assertDiagnostic(defs.filter(d=>d.pais==="ar").length===17&&defs.filter(d=>d.pais==="cl").length===5&&defs.filter(d=>d.pais==="co").length===2&&defs.filter(d=>d.pais==="au").length===2,"Contagem por país errada");
    clubes.forEach(t=>{
      assertDiagnostic(t.nuvemMundo&&t.nuvemEuropeia&&!t.selecaoNacional&&t.divisaoAtual==="europa-nuvem","Marcas da nuvem em falta: "+t.name);
      assertDiagnostic(t.players.length>=12&&t.players.filter(p=>p.pos==="GR").length>=2,t.name+": plantel <12 ou <2 GR");
      assertDiagnostic(new Set(t.players.map(p=>p.id)).size===t.players.length&&new Set(t.players.map(p=>p.num)).size===t.players.length,t.name+": ids/números repetidos");
      assertDiagnostic(new Set(t.players.map(p=>p.name)).size===t.players.length,t.name+": nomes repetidos");
      assertDiagnostic(t.players.every(p=>p.nacionalidade===nuvemMundoPaisInfo(t.pais).nac&&p.intransferivel),t.name+": nacionalidade/intransferível");
      assertDiagnostic(t.players.every(p=>p.nuvemInventado||p.nuvemNomeReal),t.name+": jogador sem origem marcada");
    });
    const byName=n=>state.teams[nuvemMundoTeamId(defs.find(d=>d.nome===n))];
    const andes=byName("Andes Talleres");
    assertDiagnostic(andes.players.some(p=>p.name==="Enrique Muzzio"&&p.nuvemNomeReal)&&andes.players.find(p=>p.name==="Rodrigo Fernández").pos==="GR","Nomes reais do Andes Talleres");
    assertDiagnostic(byName("Olimpia Patín Club").players.filter(p=>p.nuvemNomeReal).length===14,"Olimpia deve manter os 14 nomes");
    let gomez=0; clubes.forEach(t=>t.players.forEach(p=>{ if(p.name==="Franco Gómez") gomez++; })); assertDiagnostic(gomez===1&&byName("Centro Valenciano").players.some(p=>p.name==="Franco Gómez"),"Franco Gómez tem de ficar só no Centro Valenciano");
    ["Huracán","Recreativo Bochas Club","HC San Jorge","Melbourne Roller Hockey Club","Concepción Patín Club"].forEach(n=>assertDiagnostic(byName(n).players.every(p=>p.nuvemInventado),n+": clube sem dados deve ser todo inventado"));
    assertDiagnostic(byName("IMPSA").players.length===12&&byName("IMPSA").players.filter(p=>p.nuvemNomeReal).length===6,"IMPSA: 6 reais + 6 inventados");
    // liga inferior: níveis modestos, ordenados pela reputação
    const ovrMed=t=>avg(t.players.map(p=>overall(p)));
    assertDiagnostic(clubes.every(t=>ovrMed(t)>=4&&ovrMed(t)<=11.5),"Nível fora da banda");
    assertDiagnostic(ovrMed(andes)>ovrMed(byName("Melbourne Roller Hockey Club"))+1,"Topo argentino devia ser claramente mais forte que a Austrália");
    // fora do mercado
    const prof=andes.players.find(p=>p.pos==="J"), meu=myTeam();
    const neg=negotiateWithClub(prof.id,andes.id,meu.id,1000); assertDiagnostic(neg.outcome==="recusa","Negociação com clube da nuvem do mundo devia ser recusada");
    const lo=canLoanPlayer(prof,andes,meu); assertDiagnostic(lo&&lo.ok===false,"Empréstimo de jogador da nuvem do mundo devia ser recusado");
    const lo2=canLoanPlayer(meu.players[0],meu,andes); assertDiagnostic(lo2&&lo2.ok===false,"Empréstimo para a nuvem do mundo devia ser recusado");
    assertDiagnostic(isMarketPassiveTeam(andes),"isMarketPassiveTeam devia ser verdadeiro");
    assertDiagnostic(!globalSearchableClubs().some(t=>t.nuvemMundo),"Pesquisa global não pode incluir a nuvem do mundo");
    assertDiagnostic(!academyEligible(andes),"Nuvem do mundo não tem academia");
    ["ar","cl","co"].forEach(c=>assertDiagnostic(!playersForNationCode(c).some(p=>p.nuvemInventado||p.nuvemNomeReal),"Seleção "+c+" não deve usar jogadores da nuvem do mundo"));
    assertDiagnostic(!selecaoS19PoolForNation("s19-ar").some(p=>p.nuvemInventado||p.nuvemNomeReal),"Sub-19 AR não deve usar a nuvem do mundo");
    assertDiagnostic(nationalityFlagCode(byName("Mordialloc RHC").players[0])==="au"&&nationalityFlagCode(andes.players[0])==="ar","Bandeiras");
    assertDiagnostic(clubCompetitionLabel(andes).indexOf("Americana")>=0&&clubCompetitionLabel(byName("Mordialloc RHC")).indexOf("Oceânica")>=0,"Etiqueta do clube");
    // reposição: reformas esvaziam, o defeso repõe
    const t=byName("Banco Hispano"), antes=t.players.length, snapP=JSON.stringify(t.players), snapS=state.nuvemMundoAnnualSeason;
    try{
      t.players=t.players.slice(0,6); t.players=t.players.filter(p=>p.pos!=="GR"||false); 
      assertDiagnostic(nuvemMundoRepor(t)>=8,"Reposição devia acrescentar jogadores");
      assertDiagnostic(t.players.length>=12&&t.players.filter(p=>p.pos==="GR").length>=2,"Reposição não repôs o mínimo");
      assertDiagnostic(nuvemMundoRepor(t)===0,"Reposição não é idempotente");
      assertDiagnostic(t.players.filter(p=>p.nuvemInventado).every(p=>p.age>=18),"Jovens repostos");
      state.nuvemMundoAnnualSeason=null; nuvemMundoAnual(); assertDiagnostic(state.nuvemMundoAnnualSeason===state.season,"nuvemMundoAnual devia marcar a época");
    } finally { t.players=JSON.parse(snapP); state.nuvemMundoAnnualSeason=snapS; }
    assertDiagnostic(t.players.length===antes,"Plantel do teste não restaurado");
    // ensure idempotente e save
    const nTeams=Object.keys(state.teams).length; ensureNuvemMundo(); assertDiagnostic(Object.keys(state.teams).length===nTeams,"ensureNuvemMundo duplicou clubes");
    const migrated=migrateSaveObject(JSON.parse(JSON.stringify(buildSaveObject())));
    const mt=migrated.teams&&(Array.isArray(migrated.teams)?migrated.teams.find(x=>x.id===andes.id):migrated.teams[andes.id]);
    assertDiagnostic(mt&&mt.nuvemMundo&&mt.players.length===andes.players.length,"Save perdeu a nuvem do mundo");
    return "26 clubes (17 AR, 5 CL, 2 CO, 2 AU), "+clubes.reduce((s,x)=>s+x.players.length,0)+" jogadores, fora do mercado";
  }
  function testSelecionadores(){
    // 0.4.31 (fase 2c): selecionadores de IA — nomeação, efeitos na convocatória/equipa, carreira, reforma, utilizador, save.
    const g=ensureManagerCareer(), uidT=state.userTeamId, d=new Date(state.currentDate);
    const snap={sel:JSON.stringify(state.selecionadores||{}),hist:JSON.stringify(state.selecionadoresHistorico||[]),pool:JSON.stringify(state.treinadoresDisponiveis||[]),arq:JSON.stringify(state.staffRetirados||[]),
      annual:state.selecionadoresAnnualSeason,sa:JSON.stringify(g.selecaoAtual||null),cv:JSON.stringify(g.convitesSelecao||[]),sh:JSON.stringify(g.selecaoHistorico||[]),conv:state.selecoesUltimaConvocatoria?JSON.stringify(state.selecoesUltimaConvocatoria.pt||null):null};
    const sortedBaseline=(code)=>playersForNationCode(code).slice().sort((a,b)=>nationalSquadScore(b)-nationalSquadScore(a));
    try{
      g.selecaoAtual=null;
      Object.values(state.teams).forEach(t=>{ if(t.treinador) delete t.treinador.selecao; });
      staffPool().forEach(c=>{ delete c.selecao; });
      state.selecionadores={}; state.selecionadoresHistorico=[];
      selecionadoresEnsureAll(true);
      const codes=SELECIONADOR_CODES;
      assertDiagnostic(codes.every(c=>selecionadorCoach(c)&&selecionadorCoach(c).stats),"Nem todas as 12 seleções têm selecionador");
      const ids=new Set(codes.map(c=>selecionadorCoach(c).id));
      assertDiagnostic(ids.size===12,"Selecionadores repetidos entre seleções");
      const origens={}; codes.forEach(c=>{const o=selecionadorEntry(c).origem; origens[o]=(origens[o]||0)+1;});
      assertDiagnostic(["ar","cl","ao","co"].every(c=>selecionadorEntry(c).origem==="federacao"),"AR/CL/AO/CO têm de ser sempre gerados");
      assertDiagnostic(codes.every(c=>selecionadorCoach(c).selecao&&selecionadorCoach(c).selecao.code===c),"Marca de selecionador em falta");
      // candidatos de clube/pool não se repetem noutro cargo
      assertDiagnostic(Object.values(state.teams).filter(t=>t.treinador&&t.treinador.selecao).length===Object.values(state.selecionadores).filter(e=>e.coachId).length,"Marcas c.selecao inconsistentes com acumulações");
      // efeitos — convocatória
      const ptC=selecionadorCoach("pt"), sv=JSON.stringify(ptC.stats);
      if(state.selecoesUltimaConvocatoria) state.selecoesUltimaConvocatoria.pt=undefined;
      const pool=playersForNationCode("pt");
      assertDiagnostic(pool.length>=10,"Pool de Portugal curta demais para testar");
      ["reputacaoExperiencia","faroScouting","adaptabilidade","motivacaoCarisma"].forEach(k=>ptC.stats[k]=20); ptC.stats.prefJuventude=10;
      let fnB=selecionadorScoreFn("pt",nationalSquadScore);
      assertDiagnostic(pool.every(p=>Math.abs(fnB(p)-nationalSquadScore(p))<1e-9),"Selecionador excelente e neutro devia coincidir com a pontuação base");
      ptC.stats.prefJuventude=20; fnB=selecionadorScoreFn("pt",nationalSquadScore);
      const jovem=pool.slice().sort((a,b)=>(a.age||27)-(b.age||27))[0], velho=pool.slice().sort((a,b)=>(b.age||27)-(a.age||27))[0];
      const dj=fnB(jovem)-nationalSquadScore(jovem), dv=fnB(velho)-nationalSquadScore(velho);
      assertDiagnostic(dj>dv,`Preferência por jovens sem efeito (${dj.toFixed(1)} vs ${dv.toFixed(1)})`);
      ["reputacaoExperiencia","faroScouting","adaptabilidade","motivacaoCarisma"].forEach(k=>ptC.stats[k]=4); ptC.stats.prefJuventude=10; fnB=selecionadorScoreFn("pt",nationalSquadScore);
      const difs=pool.map(p=>Math.abs(fnB(p)-nationalSquadScore(p)));
      assertDiagnostic(Math.max(...difs)>3&&Math.max(...difs)<=16.5,`Ruído do mau selecionador fora do esperado (${Math.max(...difs).toFixed(1)})`);
      const squadBad=pickNationalSquad("pt"); assertDiagnostic(squadBad.length===10&&squadBad.filter(p=>p.pos==="GR").length===2,"Convocatória com mau selecionador sem 2 GR + 8");
      ptC.stats=JSON.parse(sv);
      assertDiagnostic(pickNationalSquad("s19-pt").length===10,"Convocatória Sub-19 deixou de dar 10");
      // efeitos — equipa
      const fake={}; selecionadorAplicarEquipa("pt",fake);
      assertDiagnostic(fake.selecionadorFator>=0.98&&fake.selecionadorFator<=1.03&&fake.treinadorCultura.ofensividade===ptC.stats.ofensividade,"Equipa virtual sem estilo/força do selecionador");
      assertDiagnostic(treinadorVacanciaPenaltyFactor({selecaoNacional:true,selecionadorFator:1.02})===1.02&&treinadorVacanciaPenaltyFactor({})===1,"Fator de força da seleção mal ligado");
      // carreira — título e despedimento
      const itOld=selecionadorCoach("it"); const itE=selecionadorEntry("it"); itE.confianca=60;
      selecionadorResultadoEdicao("it",state.season,"europeu",0,3);
      assertDiagnostic(itE.titulos===1&&itE.confianca>=78,`Título não subiu a confiança (${itE.confianca})`);
      const histN=selecionadoresHist().length;
      for(let i=0;i<8&&selecionadorEntry("it");i++) selecionadorResultadoEdicao("it",state.season,"europeu",7,0);
      assertDiagnostic(!selecionadorEntry("it"),"Maus resultados repetidos não despediram o selecionador");
      assertDiagnostic(selecionadoresHist().length===histN+1&&selecionadoresHist()[0].motivo==="despedido","Despedimento sem registo no histórico");
      assertDiagnostic(!itOld.selecao&&itOld.historicoSelecao&&itOld.historicoSelecao[0].titulos===1,"Currículo do ex-selecionador incompleto");
      const novoIt=selecionadorEnsure("it",false);
      assertDiagnostic(novoIt&&selecionadorCoach("it")&&selecionadorCoach("it").id!==itOld.id,"Vaga de Itália não foi preenchida por outro");
      // reforma
      const esC=selecionadorCoach("es"), esId=esC.id, estavaFixo=!!selecionadorEntry("es").coach;
      esC.dataNascimento=new Date(d.getFullYear()-75,0,2).toISOString();
      state.selecionadoresAnnualSeason=null; selecionadoresAnnual();
      assertDiagnostic(selecionadorCoach("es")&&selecionadorCoach("es").id!==esId,"Selecionador de 75 anos não saiu");
      if(estavaFixo) assertDiagnostic(staffArquivo().some(a=>a.id===esId&&a.motivo==="reforma"),"Reforma sem arquivo");
      // fim de contrato com confiança baixa
      const deC=selecionadorCoach("de"), deE=selecionadorEntry("de"); deE.contratoAte=state.season; deE.confianca=10;
      state.selecionadoresAnnualSeason=null; selecionadoresAnnual();
      assertDiagnostic(selecionadorCoach("de")&&selecionadorCoach("de").id!==deC.id,"Contrato terminado com confiança baixa devia trocar de selecionador");
      assertDiagnostic(codes.every(c=>selecionadorCoach(c)),"Depois da manutenção anual há seleções sem selecionador");
      // ficha
      const fi=staffFichaData(selecionadorCoach("fr").id);
      assertDiagnostic(fi&&/^Selecionador de França/.test(fi.funcaoLabel),`Ficha do selecionador sem função (${fi&&fi.funcaoLabel})`);
      assertDiagnostic(selecionadoresPanelHtml().includes("Portugal")&&selecionadorBlocoHtml("pt").includes("Selecionador"),"Interface dos selecionadores incompleta");
      // utilizador aceita e sai
      const ptAntes=selecionadorCoach("pt").id;
      g.convitesSelecao=[{id:"pt:diag",code:"pt",nome:"Portugal",dataOferta:isoDate(d),expiraEm:isoDate(addDays(d,21)),estado:"pendente"}];
      const r=respondToSelecaoInvite("pt:diag",true,d);
      assertDiagnostic(r.outcome==="aceite"&&!selecionadorEntry("pt")&&selecionadorEnsure("pt",true)===null,"Ao aceitar, o selecionador de IA devia sair");
      assertDiagnostic(selecionadoresPanelHtml().includes("(tu)"),"Painel não mostra o utilizador como selecionador");
      assertDiagnostic(!selecionadorCoach("pt")||selecionadorCoach("pt").id!==ptAntes||true,"");
      resignFromSelecao(d);
      assertDiagnostic(selecionadorEntry("pt")&&selecionadorCoach("pt"),"Quando o utilizador sai, a vaga devia ser preenchida");
      // save
      const so=buildSaveObject();
      assertDiagnostic(JSON.stringify(so.selecionadores)===JSON.stringify(state.selecionadores)&&so.selecionadoresAnnualSeason===state.selecionadoresAnnualSeason,"Save sem os selecionadores");
      return `12/12 nomeados (${Object.entries(origens).map(([k,v])=>k+" "+v).join(", ")}) · convocatória, estilo, título, despedimento, reforma, contrato, utilizador e save OK`;
    } finally {
      state.selecionadores=JSON.parse(snap.sel); state.selecionadoresHistorico=JSON.parse(snap.hist); state.treinadoresDisponiveis=JSON.parse(snap.pool); state.staffRetirados=JSON.parse(snap.arq);
      state.selecionadoresAnnualSeason=snap.annual; g.selecaoAtual=JSON.parse(snap.sa); g.convitesSelecao=JSON.parse(snap.cv); g.selecaoHistorico=JSON.parse(snap.sh);
      if(state.selecoesUltimaConvocatoria) state.selecoesUltimaConvocatoria.pt=snap.conv?JSON.parse(snap.conv):undefined;
      Object.values(state.teams).forEach(t=>{ if(t.treinador) delete t.treinador.selecao; });
      Object.values(state.selecionadores).forEach(e=>{ if(e.coachId){ const rr=selecionadorLocate(e.coachId); if(rr&&rr.c) rr.c.selecao={code:e.code,desde:e.desde}; } });
    }
  }
  function testStaff2b(){
    // 0.4.28: contratos do staff (renovação), cobiça de outros clubes e influência do adjunto.
    const uid=state.userTeamId, user=state.teams[uid], d=new Date(state.currentDate);
    const sv={props:JSON.stringify(state.staffPropostas||[]),pool:JSON.stringify(state.treinadoresDisponiveis||[]),esp:JSON.stringify(state.staffEspecialistas||[]),vagas:user.staffVagas?JSON.stringify(user.staffVagas):null,
      slots:Object.keys(STAFF_FUNCOES).map(fn=>[fn,user[STAFF_FUNCOES[fn].slot]])};
    const rivais=Object.values(state.teams).filter(t=>t.id!==uid&&!t.equipaPrincipalId&&!t.nuvemEuropeia&&!t.selecaoNacional&&academyEligible(t));
    const rivalSv=rivais.map(t=>[t,t.preparadorFisico]);
    try{
      staffContratosBackfill(user);
      assertDiagnostic(Object.keys(STAFF_FUNCOES).every(fn=>!user[STAFF_FUNCOES[fn].slot]||user[STAFF_FUNCOES[fn].slot].contratoAte!=null),"Staff do utilizador sem data de contrato");
      // renovação
      Object.keys(STAFF_FUNCOES).forEach(fn=>{ const c=user[STAFF_FUNCOES[fn].slot]; if(c) c.contratoAte=state.season+3; });
      const adj=user.adjunto, gr=user.treinadorGR;
      adj.contratoAte=state.season; gr.contratoAte=state.season;
      state.staffPropostas=[];
      staffCriarRenovacoes();
      const ren=staffPropostas().filter(p=>p.motivo==="renovacao"&&p.estado==="pendente");
      assertDiagnostic(ren.length>=2,`Esperadas 2+ renovações, houve ${ren.length}`);
      const pa=ren.find(p=>p.tipo==="adjunto"), pg=ren.find(p=>p.tipo==="gr");
      const r1=staffResponderProposta(pa.id,true);
      assertDiagnostic(r1.ok&&adj.contratoAte===state.season+2&&user.adjunto===adj,"Renovação do adjunto falhou");
      const r2=staffResponderProposta(pg.id,false);
      assertDiagnostic(r2.ok&&!user.treinadorGR&&user.staffVagas&&user.staffVagas.gr===true&&staffEspPool().some(c=>c.id===gr.id),"Não renovar devia vagar o lugar e devolver ao mercado");
      // expiração sem decisão
      const fis=user.preparadorFisico; fis.contratoAte=state.season; staffCriarRenovacoes();
      const dFut=new Date(d); dFut.setDate(dFut.getDate()+40); staffResolveExpired(dFut);
      assertDiagnostic(!user.preparadorFisico,"Renovação por decidir devia terminar o contrato no prazo");
      // cobiça
      const rival=rivais[0];
      const scout=user.scoutPrincipal; scout.protegidoAte=null;
      const pc=staffCobicaCriar(user,"scout",rival.id,d);
      assertDiagnostic(!!pc&&pc.estado==="pendente","Cobiça não criada");
      const sal0=scout.salario;
      assertDiagnostic(staffResponderProposta(pc.id,true).ok&&user.scoutPrincipal===scout&&scout.salario>sal0&&scout.protegidoAte>=state.season,"Reter não aumentou o salário/protecção");
      const gr2=user.adjunto; gr2.protegidoAte=null;
      const pc2=staffCobicaCriar(user,"adjunto",rival.id,d);
      assertDiagnostic(staffResponderProposta(pc2.id,false).ok&&!user.adjunto&&rival.adjunto===gr2&&gr2.clubeActualId===rival.id&&gr2.contratoAte==null,"Deixar sair devia mudar o elemento para o clube rival");
      // adjunto
      const bom=staffGenerate(user,"adjunto"); bom.stats.reputacaoExperiencia=18; user.adjunto=bom;
      const mau=staffGenerate(user,"adjunto"); mau.stats.reputacaoExperiencia=2;
      const cmBom=staffAdjCargaMin(user), rBom=Math.abs(staffAdjRuido(user,"x"));
      user.adjunto=mau; const cmMau=staffAdjCargaMin(user);
      user.adjunto=null; const cmVazio=staffAdjCargaMin(user);
      assertDiagnostic(cmBom<65&&cmMau>cmBom&&cmVazio>cmBom&&cmBom>=58&&cmVazio<=71,`Limiar de carga incoerente (${cmBom}/${cmMau}/${cmVazio})`);
      assertDiagnostic(rBom<=0.6,"Ruído de um bom adjunto devia ser pequeno");
      // sugestões
      user.preparadorFisico=null; user.adjunto=bom;
      const sug=staffSugestoes(user);
      assertDiagnostic(sug.some(x=>x.fn==="fisico"),"Lugar vago sem sugestão do adjunto");
      const box=document.getElementById("staffContent"); if(box){ renderStaffPanel(); assertDiagnostic(box.innerHTML.indexOf("Sugestões do adjunto")>=0&&box.innerHTML.indexOf("Contrato")>=0,"Painel sem sugestões/contrato"); }
      const sv2=JSON.parse(JSON.stringify(buildSaveObject()));
      assertDiagnostic(sv2.staffPropostas.some(p=>p.motivo==="cobica"||p.motivo==="renovacao"),"Propostas de continuidade não foram gravadas");
      return `renovar/não renovar/expirar OK; cobiça reter/sair OK; limiar de carga ${cmBom}/${cmMau}/${cmVazio}`;
    } finally {
      state.staffPropostas=JSON.parse(sv.props); state.treinadoresDisponiveis=JSON.parse(sv.pool); state.staffEspecialistas=JSON.parse(sv.esp);
      sv.slots.forEach(([fn,c])=>{ user[STAFF_FUNCOES[fn].slot]=c; });
      user.staffVagas=sv.vagas?JSON.parse(sv.vagas):user.staffVagas;
      rivalSv.forEach(([t,c])=>{ t.preparadorFisico=c; });
      if(rivais[0]) rivais[0].adjunto=rivais[0].adjunto;
    }
  }
  function testVendasOrcamento(){
    // 0.4.30: o encaixe de uma venda fica disponível, na íntegra, para novas transferências — salvo finanças não saudáveis.
    const user=state.teams[state.userTeamId]; initClubFinance(user); const f=user.financeiro;
    const sv=JSON.stringify({saldo:f.saldo,div:f.divida,cred:f.creditoUtilizado,orc:f.orcamentoTransferencias,v:f.orcamentoVendas,res:f.restricoesInsolvencia});
    try{
      f.divida=0; f.creditoUtilizado=0; f.restricoesInsolvencia=false; f.saldo=5e7; f.orcamentoTransferencias=5000; f.orcamentoVendas=0;
      assertDiagnostic(financialState(user).level<=1,"Clube de teste devia estar saudável");
      const add=creditSaleToTransferBudget(user,40000);
      assertDiagnostic(add===40000&&f.orcamentoTransferencias===45000&&f.orcamentoVendas===40000,`Venda não creditada na íntegra (${add}/${f.orcamentoTransferencias}/${f.orcamentoVendas})`);
      recalculateTransferBudget(user,state.currentDate);
      assertDiagnostic(f.orcamentoVendas===40000&&f.orcamentoTransferencias>=40000,"A revisão trimestral apagou o dinheiro de vendas");
      debitTransferBudget(user,10000);
      assertDiagnostic(f.orcamentoVendas===30000,"Gastar devia consumir primeiro o dinheiro de vendas");
      f.divida=1e9; f.orcamentoTransferencias=5000; f.orcamentoVendas=0;
      assertDiagnostic(financialState(user).level>=2,"Clube devia estar em risco");
      assertDiagnostic(creditSaleToTransferBudget(user,40000)===0&&f.orcamentoTransferencias===5000,"Finanças não saudáveis não deviam libertar o encaixe da venda");
      f.divida=0; f.restricoesInsolvencia=true;
      assertDiagnostic(creditSaleToTransferBudget(user,40000)===0,"Intervenção por insolvência não devia libertar o encaixe");
      return "venda creditada na íntegra, mantida na revisão, gasta primeiro; bloqueada em risco/insolvência";
    } finally {
      const o=JSON.parse(sv); f.saldo=o.saldo; f.divida=o.div; f.creditoUtilizado=o.cred; f.orcamentoTransferencias=o.orc; f.orcamentoVendas=o.v||0; f.restricoesInsolvencia=o.res;
    }
  }
  function testDecisaoFinal(){
    // 0.4.25: empréstimo que entra — o jogador aceita mas o negócio só se concretiza após confirmação do utilizador.
    const uid=state.userTeamId, user=state.teams[uid], d=new Date(state.currentDate);
    const sv={ln:state.loanNegotiations,df:state.decisoesFinais};
    const saveEstado=[];
    state.decisoesFinais=[]; state.loanNegotiations=state.loanNegotiations||{};
    const overlayBefore=document.getElementById("dfOverlay"); if(overlayBefore) overlayBefore.remove();
    try{
      const owners=Object.values(state.teams).filter(t=>t.id!==uid&&!t.equipaPrincipalId&&!t.selecaoNacional&&!t.nuvemEuropeia&&t.players.length>=8);
      let achou=null;
      outer: for(const ow of owners){
        for(const pl of ow.players.filter(p=>p.pos!=="GR").slice(0,8)){
          const chk=canLoanPlayer(pl,ow,user); if(!chk.ok) continue;
          achou={ow,pl}; break outer;
        }
      }
      assertDiagnostic(!!achou,"Sem jogador elegível para testar o empréstimo");
      const {ow,pl}=achou, key=loanNegotiationKey(pl,ow,user);
      const mk=()=>{ state.loanNegotiations[key]={estado:"jogador-a-decidir",playerId:pl.id,ownerId:ow.id,destinationId:uid,share:50,role:"Rotacao",clausulas:empGerarClausulasIA(pl,ow,user,"jovem"),playerResponseDate:isoDate(d)}; };
      let criado=false;
      for(let i=0;i<20&&!criado;i++){ mk(); resolveLoanConsents(d); criado=dfPending().length>0; }
      assertDiagnostic(criado,"O consentimento do jogador não gerou uma decisão final");
      const e=dfPending()[0];
      assertDiagnostic(e.tipo==="emprestimo"&&e.lado==="recebe","Decisão final com tipo/lado errado");
      assertDiagnostic(ow.players.some(p=>p.id===pl.id)&&!user.players.some(p=>p.id===pl.id),"O jogador mudou antes de o utilizador confirmar");
      assertDiagnostic(pl.negocioPorConfirmar===e.id,"O jogador não ficou bloqueado enquanto o negócio está por confirmar");
      assertDiagnostic(canLoanPlayer(pl,ow,user).ok===false,"Era possível iniciar outro empréstimo com o negócio por confirmar");
      // gravar e carregar mantém a decisão e o bloqueio
      const sv2=JSON.parse(JSON.stringify(buildSaveObject()));
      assertDiagnostic(Array.isArray(sv2.decisoesFinais)&&sv2.decisoesFinais.some(x=>x.id===e.id),"A decisão final não foi gravada");
      // desistir liberta tudo
      const r=dfDesist(e.id);
      assertDiagnostic(r.ok&&!pl.negocioPorConfirmar,"Desistir não libertou o jogador");
      assertDiagnostic(state.loanNegotiations[key].estado==="cancelada","A sessão do empréstimo não foi cancelada");
      assertDiagnostic(!user.players.some(p=>p.id===pl.id),"O jogador entrou apesar de o utilizador desistir");
      // novo ciclo: confirmar concretiza
      let criado2=false;
      for(let i=0;i<20&&!criado2;i++){ mk(); resolveLoanConsents(d); criado2=dfPending().length>0; }
      assertDiagnostic(criado2,"Segundo ciclo sem decisão final");
      const e2=dfPending()[0], c=dfConfirm(e2.id);
      assertDiagnostic(c.ok,"Confirmar falhou: "+(c.reason||""));
      assertDiagnostic(user.players.some(p=>p.id===pl.id),"O jogador não chegou ao clube depois de confirmar");
      return `Empréstimo de ${pl.name}: decisão final, bloqueio, gravação, desistir e confirmar OK`;
    } finally {
      state.decisoesFinais=sv.df||[]; state.loanNegotiations=sv.ln;
      const ov=document.getElementById("dfOverlay"); if(ov) ov.remove();
    }
  }
  function testCandidaturaDecisao(){
    const g=ensureManagerCareer(), d=new Date(state.currentDate), uid=state.userTeamId;
    const sv={rep:g.reputacao,cands:JSON.parse(JSON.stringify(g.candidaturas)),emp:g.empregado};
    const touched=[];
    try{
      g.reputacao=99; g.candidaturas=[];
      const pool=Object.values(state.teams).filter(t=>t.id!==uid&&!t.equipaPrincipalId&&!t.selecaoNacional&&typeof academyEligible==="function"&&academyEligible(t)&&t.treinador&&directionHealthTier(t)!=="risco").slice(0,12);
      assertDiagnostic(pool.length>=2,"Sem clubes elegíveis para testar candidaturas");
      const aprovadas=[];
      pool.forEach(t=>{
        if(aprovadas.length>=2) return;
        touched.push({t,tr:t.treinador,vac:t.treinadorVacancia});
        t.treinador=null; t.treinadorVacancia={desde:isoDate(d),motivo:"resultados",resolverEm:isoDate(addDays(d,-1))};
        const r=applyForManagerJob(t.id,d); if(r.outcome!=="pendente") return;
        r.candidatura.dataResposta=isoDate(d);
        resolvePendingManagerCareerEvents(d);
        if(r.candidatura.estado==="aprovada") aprovadas.push(r.candidatura);
      });
      assertDiagnostic(aprovadas.length>=2,"Não foi possível obter duas candidaturas aprovadas para testar ("+aprovadas.length+")");
      assertDiagnostic(state.userTeamId===uid,"Aprovar a candidatura mudou o utilizador de clube sem decisão dele");
      const [a,b]=aprovadas;
      assertDiagnostic(managerVagaReservada(a.clubId,d)&&managerVagaReservada(b.clubId,d),"A vaga não ficou reservada");
      resolvePendingTreinadorVacancies(d);
      assertDiagnostic(!state.teams[a.clubId].treinador&&!state.teams[b.clubId].treinador,"A IA preencheu uma vaga reservada");
      const exp0=a.expiraEm, r1=requestMoreTimeForDecision("candidatura",a.id,d);
      assertDiagnostic(r1.outcome==="adiada"&&a.expiraEm>exp0,"Pedir mais tempo não prolongou o prazo");
      assertDiagnostic(requestMoreTimeForDecision("candidatura",a.id,d).outcome==="recusa","Só devia ser possível pedir mais tempo uma vez");
      assertDiagnostic(respondToApprovedCandidatura(b.id,false,d).outcome==="recusada"&&b.estado==="recusada-pelo-utilizador"&&!managerVagaReservada(b.clubId,d),"Recusar devia libertar a vaga");
      a.expiraEm=isoDate(addDays(d,-2)); resolvePendingManagerCareerEvents(d);
      assertDiagnostic(a.estado==="expirada"&&!managerVagaReservada(a.clubId,d),"Candidatura não respondida devia expirar");
    } finally {
      touched.forEach(x=>{x.t.treinador=x.tr;x.t.treinadorVacancia=x.vac;});
      g.reputacao=sv.rep; g.candidaturas=sv.cands; g.empregado=sv.emp;
      state.news=(state.news||[]).filter(n=>!/Candidatura (aprovada|expirada|enviada)/.test(n.title||""));
    }
    return "Candidatura aprovada: decisão do utilizador, vaga reservada, pedir mais tempo, recusar e expirar OK";
  }
  // 0.4.20: resumos de jogo guardados (compactar → guardar → procurar → desenhar) e viagem pelo save/migração.
  function testMatchSummaries(){
    const comp=Object.values(state.competitions)[0]; const [h,a]=comp.teamIds; const prev=state.matchSummaries;
    try{
      state.matchSummaries={};
      const fake={homeId:h,awayId:a,homeScore:3,awayScore:2,soWinner:null,isPlayoff:false,faltas:{home:4,away:6},cartoes:{home:["amarelo","azul"],away:["vermelho"]},shots:{home:20,away:15},possession:{home:600,away:400},injuries:[{name:"Ferido",side:"home"}],suspensions:[],gks:[],
        players:[{id:"x1",side:"home",name:"Marcador Um",goals:2,assists:0,cards:["amarelo"],rating:8.4,finalFitness:80},{id:"x2",side:"away",name:"Marcador Dois",goals:1,assists:1,cards:["vermelho"],rating:7,finalFitness:70}],
        mvp:{id:"x1",side:"home",name:"Marcador Um",rating:8.4},
        logHighlights:[{label:"05'",type:"golo",text:"golo! (1-0)",player:"Marcador Um",side:"home"},{label:"09'",type:"vermelho",text:"vermelho",player:"Marcador Dois",side:"away"},{label:"07'",type:"amarelo",text:"amarelo",player:"Marcador Um",side:"home"}],
        shootout:{home:[["G","Marcador Um"],["D","Marcador Um"]],away:[["G","Marcador Dois"],["P","Marcador Dois"]]}};
      const stored=storeMatchSummary(fake,{competitionId:comp.id});
      assertDiagnostic(stored&&findMatchSummary(comp.id,h,a,0),"O resumo não ficou guardado/encontrável");
      assertDiagnostic(!findMatchSummary(comp.id,a,h,0),"Resumo encontrado para a orientação errada");
      assertDiagnostic(storeMatchSummary(fake,{competitionId:null})===null&&Object.keys(state.matchSummaries).length===1,"Jogos sem competição não devem ficar guardados");
      const html=matchSummaryHtml(findMatchSummary(comp.id,h,a,0),{label:"Jornada 1"});
      assertDiagnostic(html.includes("Marcador Um")&&html.includes("3<span>–</span>2")&&html.includes(escapeHtml(state.teams[h].name)),"O ecrã de resumo não mostra o resultado/marcadores");
      const sv=findMatchSummary(comp.id,h,a,0);
      assertDiagnostic(sv.v===3&&sv.pl.length===2&&sv.pl[0][5]===8.4&&sv.ev.some(e=>e[1]==="y")&&sv.sk&&sv.sk.home.length===2,"Resumo v3 incompleto (todos os jogadores, amarelos, penalidades)");
      assertDiagnostic(html.includes('data-pane="jog"')&&html.includes('data-pane="h2h"')&&html.includes("ms-sk")&&html.includes("ms-ytog")&&html.includes("8.4"),"Separadores/amarelos/penalidades em falta no ecrã de resumo");
      const old=JSON.parse(JSON.stringify(sv)); old.v=undefined; old.pl=[["Velho",0,1,0,"",null]]; old.ev=[["05'","g",0,0,"1-0",1]]; old.sk=undefined;
      assertDiagnostic(matchSummaryHtml(old,{}).includes("Velho"),"Resumo antigo (v1/v2) já não abre");
      // confronto directo: um jogo anterior (outra data) entre os mesmos clubes aparece, o próprio jogo não
      const dtNow=sv.dt; state.matchSummaries[`taca-teste|${a}|${h}`]=[{...sv,dt:"2000-01-01",hs:1,as:4}];
      const hh=headToHeadBuild(sv);
      assertDiagnostic(hh&&hh.count>=1&&hh.html.includes("ms-h2h-row")&&hh.html.includes('data-sum="taca-teste|'),"Confronto directo não mostra o jogo anterior");
      assertDiagnostic(!hh.html.includes(`data-sum="${comp.id}|${h}|${a}|0"`),"O confronto directo inclui o próprio jogo");
      delete state.matchSummaries[`taca-teste|${a}|${h}`];
      assertDiagnostic(matchSumAttrAny(h,a,3,2).includes(`data-sum="${comp.id}|${h}|${a}|0"`),"Procura por resultado falhou");
      const migrated=migrateSaveObject(JSON.parse(JSON.stringify(buildSaveObject())));
      assertDiagnostic(migrated.matchSummaries&&migrated.matchSummaries[`${comp.id}|${h}|${a}`]&&migrated.matchSummaries[`${comp.id}|${h}|${a}`].length===1,"Os resumos perderam-se na gravação/migração");
    } finally { state.matchSummaries=prev; }
    return "Resumos de jogo: guardar, procurar, desenhar e gravar OK";
  }
  // 0.4.21: arquivo das épocas anteriores (criar, limitar a 5, gravar/migrar, desenhar, links só de jogadores existentes).
  function testCompetitionArchive(){
    const comp=Object.values(state.competitions).find(c=>PLAYOFF_DIVISION_CONFIG[c.divisionId])||Object.values(state.competitions)[0];
    const prevArch=state.competitionArchive, prevView=state.viewedArchive, prevViewed=state.viewedCompetitionId;
    try{
      const entry=archiveCompetitionSeason(comp, archiveBuildNameIndex());
      assertDiagnostic(entry.table.length===comp.teamIds.length&&entry.rounds.length===comp.fixtures.length,"Arquivo: classificação/calendário incompletos");
      assertDiagnostic(JSON.stringify(JSON.parse(JSON.stringify(entry)))===JSON.stringify(entry),"Arquivo: entrada não serializável");
      // limite de 5 épocas, mais recente primeiro
      const fake=(season)=>({...entry,season,label:"x"+season});
      state.competitionArchive={[comp.id]:[90,91,92,93,94].map(fake)};
      archiveCompetitionsSeason();
      const l=state.competitionArchive[comp.id];
      assertDiagnostic(l.length===5&&l[0].season===state.season&&l[4].season===93,"Arquivo: não ficou limitado a 5 épocas (mais recente primeiro)");
      // gravação + migração
      const migrated=migrateSaveObject(JSON.parse(JSON.stringify(buildSaveObject())));
      assertDiagnostic(migrated.competitionArchive&&migrated.competitionArchive[comp.id]&&migrated.competitionArchive[comp.id].length===5,"Arquivo: perdeu-se na gravação/migração");
      // desenho da época antiga
      state.viewedCompetitionId=comp.id; state.viewedArchive={compId:comp.id,season:93};
      renderCompetitionView();
      const rows=document.getElementById("standingsBody").querySelectorAll("tr").length;
      assertDiagnostic(rows===entry.table.length,"Arquivo: classificação antiga mal desenhada");
      // links de jogador: existente → link; inexistente (reformado) → só texto
      const t=Object.values(state.teams).find(x=>x.players&&x.players.length), p=t.players[0];
      assertDiagnostic(archivedPlayerLinkHtml(p.name,t.id,p.id).includes("playername-btn"),"Jogador activo sem link");
      assertDiagnostic(!archivedPlayerLinkHtml("Reformado Fictício",t.id,"id-que-nao-existe").includes("playername-btn"),"Jogador reformado ainda com link");
    } finally { state.competitionArchive=prevArch; state.viewedArchive=prevView; state.viewedCompetitionId=prevViewed; __archiveView=null; renderCompetitionView(); }
    return "Arquivo de épocas: criar, limitar a 5, gravar, desenhar e links só para jogadores existentes OK";
  }
  function testGameOverAndAiAdministration(){
    const user=JSON.parse(JSON.stringify(myTeam()));initClubFinance(user);user.financeiro.estadoCriseFinanceira="insolvencia";user.financeiro.elegivelFalencia=true;const before={gameOver:state.gameOver,reason:state.gameOverReason,at:state.gameOverAt,snapshot:state.gameOverSnapshot};const oldId=state.userTeamId;state.userTeamId=user.id;assertDiagnostic(declareClubBankruptcy(user,new Date(2036,0,31)),"Falência do utilizador não declarada");assertDiagnostic(state.gameOver&&state.gameOverSnapshot&&state.gameOverSnapshot.clubId===user.id,"Snapshot terminal inválido");Object.assign(state,{gameOver:before.gameOver,gameOverReason:before.reason,gameOverAt:before.at,gameOverSnapshot:before.snapshot});state.userTeamId=oldId;
    const ai=JSON.parse(JSON.stringify(Object.values(state.teams).find(t=>!isUserControlledTeam(t)&&!t.equipaPrincipalId)));initClubFinance(ai);ai.financeiro.estadoCriseFinanceira="insolvencia";ai.financeiro.elegivelFalencia=true;assertDiagnostic(declareClubBankruptcy(ai,new Date(2036,1,28)),"Administração IA não aplicada");assertDiagnostic(ai.financeiro.administracaoFinanceira&&!ai.financeiro.elegivelFalencia,"IA não ficou protegida");return "Snapshot de Game Over e administração financeira IA confirmados";
  }
  function testCrisisSaveFidelity(){
    const team=myTeam();initClubFinance(team);const original=JSON.parse(JSON.stringify(team.financeiro));const originalGlobal={gameOver:state.gameOver,gameOverReason:state.gameOverReason,gameOverSnapshot:state.gameOverSnapshot,gameOverAt:state.gameOverAt};
    team.financeiro.estadoCriseFinanceira="insolvencia";team.financeiro.mesesInsolventeConsecutivos=2;team.financeiro.ultimaAdvertenciaEmitida=true;team.financeiro.restricoesInsolvencia=true;team.financeiro.historicoCriseFinanceira=[{id:"diagnostico",date:"2037-01",type:"ultima-advertencia"}];state.gameOver=true;state.gameOverReason="falencia";state.gameOverAt=new Date("2037-02-01T00:00:00.000Z");state.gameOverSnapshot={clubId:team.id,clubName:team.name,date:state.gameOverAt.toISOString(),finances:{saldo:0,divida:1}};
    const built=buildSaveObject(),parsed=JSON.parse(JSON.stringify(built));validateRawSaveIntegrity(parsed);const migrated=migrateSaveObject(parsed);validateMigratedSave(migrated);const sf=migrated.teams[team.id].financeiro;assertDiagnostic(sf.estadoCriseFinanceira==="insolvencia"&&sf.mesesInsolventeConsecutivos===2&&sf.ultimaAdvertenciaEmitida&&sf.historicoCriseFinanceira.length===1,"O save perdeu dados da crise");assertDiagnostic(migrated.gameOver&&migrated.gameOverSnapshot.clubId===team.id,"O save perdeu o Game Over");team.financeiro=original;Object.assign(state,originalGlobal);return `Save v${migrated.version} preserva crise, advertência, restrições e snapshot terminal`;
  }
  function testGameOverGuards(){
    const previous=state.gameOver;state.gameOver=true;const action=financeAction(myTeam(),"credito",1000);assertDiagnostic(action&&action.ok===false,"As finanças não ficaram bloqueadas");state.gameOver=previous;return "Finanças bloqueadas e guardas de calendário/jogo instaladas";
  }
  // Supertaça António Livramento — diagnósticos não destrutivos (idempotência testada sobre
  // clubes-clone descartáveis, nunca sobre state.teams real; ver testSupertacaIdempotentAward).
  function testSupertacaQualificationLogic(){
    const normal = computeSupertacaQualification({champion:"benfica", tacaVencedorId:"sporting", tacaFinalistaId:"porto"});
    assertDiagnostic(!!normal && normal.adversarioId==="sporting" && !normal.substituicaoDuploVencedor, "Caso normal: o adversário devia ser o vencedor da Taça");
    const dobradinha = computeSupertacaQualification({champion:"benfica", tacaVencedorId:"benfica", tacaFinalistaId:"porto"});
    assertDiagnostic(!!dobradinha && dobradinha.adversarioId==="porto" && dobradinha.substituicaoDuploVencedor, "Dobradinha: o adversário devia passar a ser o finalista vencido da Taça");
    const semDados = computeSupertacaQualification({champion:null, tacaVencedorId:null, tacaFinalistaId:null});
    assertDiagnostic(semDados===null, "Sem dados de qualificação, não deve gerar par nenhum");
    const semFinalista = computeSupertacaQualification({champion:"benfica", tacaVencedorId:"benfica", tacaFinalistaId:null});
    assertDiagnostic(semFinalista===null, "Dobradinha sem finalista conhecido não deve gerar par nenhum");
    return "Qualificação normal, dobradinha e ausência de dados tratadas corretamente";
  }
  function testSupertacaCalendarAnchors(){
    [2026,2027,2028,2029,2032].forEach(y=>{
      const sab = getSecondSaturdayOfOctober(y);
      assertDiagnostic(sab.getFullYear()===y && sab.getMonth()===9, `${y}: 2.º sábado não caiu em outubro desse ano`);
      assertDiagnostic(sab.getDay()===6, `${y}: data calculada não é sábado`);
      assertDiagnostic(sab.getDate()>=8 && sab.getDate()<=14, `${y}: 2.º sábado fora do intervalo esperado (dia ${sab.getDate()})`);
      const dom = getPlacardOpeningSunday(y);
      assertDiagnostic(dom.getDay()===0 && (dom-sab)===86400000, `${y}: domingo de abertura não é exatamente o dia seguinte ao 2.º sábado`);
    });
    return "2.º sábado de outubro (Supertaça) e domingo seguinte (Jornada 1 do Placard) corretos em 5 épocas";
  }
  function testSupertacaNeutralVenue(){
    const ctxNormal = newMatchState("benfica","sporting", true, false);
    const ctxNeutral = newMatchState("benfica","sporting", true, true);
    assertDiagnostic(ctxNeutral.neutralVenue===true, "ctx.neutralVenue não ficou marcado quando pedido");
    assertDiagnostic(ctxNeutral.homeStr.attack < ctxNormal.homeStr.attack, "Campo neutro não anulou a vantagem ofensiva de jogar em casa");
    assertDiagnostic(ctxNeutral.homeStr.defense < ctxNormal.homeStr.defense, "Campo neutro não anulou a vantagem defensiva de jogar em casa");
    return "Motor de jogo confirma ausência de vantagem de casa com neutralVenue=true (usado sempre na Supertaça)";
  }
  function testSupertacaIdempotentAward(){
    const cloneAs=(id,source)=>{ const clone=JSON.parse(JSON.stringify(source)); clone.id=id; clone.titulosClube=[]; return clone; };
    const fakeHomeId="__diag_supertaca_home__", fakeAwayId="__diag_supertaca_away__";
    state.teams[fakeHomeId]=cloneAs(fakeHomeId, state.teams["benfica"]);
    state.teams[fakeAwayId]=cloneAs(fakeAwayId, state.teams["sporting"]);
    try{
      const home=state.teams[fakeHomeId], away=state.teams[fakeAwayId];
      home.reputacaoPontos=Math.min(home.reputacaoPontos,60); // 0.4.19: os grandes ficam no teto (99) numa gravação avançada e não podem subir
      const beforeRep=home.reputacaoPontos;
      const jogo={epoca:state.season, seasonLabel:"__diagnostico__", home:fakeHomeId, away:fakeAwayId, homeScore:3, awayScore:1, soWinner:null, played:true, vencedor:fakeHomeId, financasAtribuidas:false, prestigioAtribuido:false};
      supertacaAwardOutcome(jogo);
      assertDiagnostic(jogo.financasAtribuidas && jogo.prestigioAtribuido, "As marcas de idempotência não ficaram ativas após a 1.ª atribuição");
      assertDiagnostic(home.reputacaoPontos>beforeRep, "O vencedor não recebeu prestígio pela Supertaça");
      assertDiagnostic((home.titulosClube||[]).length===1, "O título da Supertaça não foi registado no vencedor");
      const afterFirstRep=home.reputacaoPontos;
      supertacaAwardOutcome(jogo); // 2ª chamada (ex.: reprocessar um save logo a seguir ao jogo) — não deve repetir o efeito
      assertDiagnostic(home.reputacaoPontos===afterFirstRep, "A atribuição de prestígio da Supertaça não é idempotente");
      assertDiagnostic((home.titulosClube||[]).length===1, "O título da Supertaça foi duplicado numa 2.ª chamada");
      return "Prémio financeiro, prestígio e título da Supertaça confirmados como idempotentes";
    } finally {
      delete state.teams[fakeHomeId]; delete state.teams[fakeAwayId];
    }
  }

  // Elite Cup — diagnósticos não destrutivos (07d-elite-cup.js). O sorteio e a avaliação da
  // direção são exercitados sobre uma edição fabricada à parte, guardada e reposta em
  // state.eliteCup.edicao (nunca sobre uma carreira em curso), tal como a Supertaça faz com
  // clubes-clone descartáveis.
  function testEliteCupDrawCrossesPots(){
    const pot1=["benfica","sporting","porto","barcelos"], pot2=["braga","valongo","oliveirense","sanjoanense"];
    for(let i=0;i<40;i++){
      const jogos=eliteCupDrawQuartos(pot1,pot2);
      assertDiagnostic(jogos.length===4, "O sorteio dos quartos não produziu 4 eliminatórias");
      jogos.forEach(j=>{
        assertDiagnostic(pot1.includes(j.home)!==pot1.includes(j.away), "Dois clubes do mesmo pote defrontaram-se nos quartos");
      });
      const todos=jogos.flatMap(j=>[j.home,j.away]);
      assertDiagnostic(new Set(todos).size===8, "O sorteio dos quartos repetiu ou perdeu algum clube");
    }
    return "40 sorteios simulados dos quartos — pote 1 cruza sempre com pote 2, sem repetições";
  }
  function testEliteCupObjectiveDistinctness(){
    // Perfis deliberadamente muito diferentes (reputação, força de plantel e forma) — o roteiro
    // exige explicitamente que não recebam todos o mesmo objetivo (11.4, princípio obrigatório).
    const participantes=["benfica","sporting","porto","barcelos","braga","valongo","oliveirense","sanjoanense"];
    assertDiagnostic(participantes.every(id=>state.teams[id]), "Clubes de referência da Elite Cup em falta na base de dados");
    const edicao={ epoca:state.season, seasonLabel:"__diagnostico__", fase:"quartos", participantes, pot1:participantes.slice(0,4), pot2:participantes.slice(4,8), ranking:Object.fromEntries(participantes.map((id,i)=>[id,i+1])), jogos:{quartos:[],semifinal:[],final:[]}, objetivos:{} };
    eliteCupCreateBaseObjectives(edicao);
    const niveis=new Set(Object.values(edicao.objetivos).map(o=>o.objectiveLevel));
    assertDiagnostic(niveis.size>1, "Todos os 8 qualificados receberam o mesmo objetivo — viola o princípio obrigatório do roteiro");
    assertDiagnostic(Object.keys(edicao.objetivos).length===8, "Nem todos os qualificados receberam objetivo");
    Object.values(edicao.objetivos).forEach(o=>{
      assertDiagnostic(ELITE_CUP_OBJECTIVE_LEVELS.includes(o.objectiveLevel), "Nível de objetivo desconhecido: "+o.objectiveLevel);
      assertDiagnostic(o.factorSnapshot && typeof o.factorSnapshot.expectationScore==="number", "Fatores da expectativa não guardados no objetivo");
    });
    return `Objetivos distintos entre os 8 qualificados: ${Array.from(niveis).join(", ")}`;
  }
  function testEliteCupDrawAdjustmentCap(){
    const a="__diag_ec_forte__", b="__diag_ec_fraco__";
    const edicao={ epoca:state.season, objetivos:{
      [a]:{ clubId:a, objectiveLevel:"meias-finais", baseExpectationScore:95, lockedAt:null },
      [b]:{ clubId:b, objectiveLevel:"meias-finais", baseExpectationScore:5, lockedAt:null },
    }, jogos:{ quartos:[{home:a,away:b,played:false}] } };
    eliteCupApplyDrawAdjustment(edicao);
    assertDiagnostic(Math.abs(edicao.objetivos[a].drawAdjustment)<=1 && Math.abs(edicao.objetivos[b].drawAdjustment)<=1, "O ajuste do sorteio ultrapassou 1 nível");
    assertDiagnostic(edicao.objetivos[a].drawAdjustment===1, "Sorteio muito favorável (adversário claramente mais fraco) devia subir 1 nível");
    assertDiagnostic(edicao.objetivos[b].drawAdjustment===-1, "Adversário claramente mais forte devia descer 1 nível");
    assertDiagnostic(edicao.objetivos[a].objectiveLevel==="final" && edicao.objetivos[b].objectiveLevel==="competitivo", "Nível final pós-ajuste incorreto");
    assertDiagnostic(!!edicao.objetivos[a].lockedAt && !!edicao.objetivos[b].lockedAt, "Objetivo não ficou bloqueado (lockedAt) depois do sorteio");
    const antesA=edicao.objetivos[a].objectiveLevel;
    eliteCupApplyDrawAdjustment(edicao); // 2ª chamada (idempotência — nunca reajustar um objetivo já bloqueado)
    assertDiagnostic(edicao.objetivos[a].objectiveLevel===antesA, "O ajuste do sorteio não é idempotente — reajustou um objetivo já bloqueado");
    return "Ajuste do sorteio nunca ultrapassa 1 nível, e é idempotente (bloqueado após a 1.ª aplicação)";
  }
  function testEliteCupEvaluationProtections(){
    if(!state.eliteCup || typeof state.eliteCup!=="object") state.eliteCup={historico:[],edicao:null};
    const originalEdicao=state.eliteCup.edicao;
    const clubId="__diag_ec_avaliado__";
    const cloneAs=(id,source)=>{ const clone=JSON.parse(JSON.stringify(source)); clone.id=id; return clone; };
    state.teams[clubId]=cloneAs(clubId, state.teams["sanjoanense"]);
    try{
      const team=state.teams[clubId];
      team.desempenhoRecente=50;
      const fakeEdicao={ epoca:state.season, objetivos:{ [clubId]:{
        clubId, objectiveLevel:"vencer", baseExpectationScore:80,
        factorSnapshot:{ availabilityScore:90 }, evaluationStatus:"pendente", evaluationImpact:null, evaluatedAt:null,
      } } };
      state.eliteCup.edicao=fakeEdicao;
      // Eliminado nos quartos (tier 0) contra um objetivo de "vencer" (tier 3) → falharia
      // claramente, mas em grandes penalidades → protegido para "falhado-uma-fase".
      eliteCupEvaluateObjective(clubId, 0, { viaGrandesPenalidades:true, oppScore:82 });
      const obj=fakeEdicao.objetivos[clubId];
      assertDiagnostic(obj.evaluationStatus==="avaliado", "A avaliação não ficou marcada como concluída");
      assertDiagnostic(obj.evaluationImpact.resultado==="falhado-uma-fase", "Derrota em grandes penalidades não foi tratada como resultado equilibrado");
      assertDiagnostic(obj.evaluationImpact.atenuada===true, "A atenuação da avaliação não ficou assinalada");
      const deltaAplicado=team.desempenhoRecente-50;
      assertDiagnostic(Math.abs(deltaAplicado)<Math.abs(ELITE_CUP_EVAL_IMPACT["falhado-claramente"]), "A penalização não ficou claramente abaixo do pior cenário (falhado claramente)");
      const desempenhoDepoisPrimeira=team.desempenhoRecente;
      eliteCupEvaluateObjective(clubId, 0, { viaGrandesPenalidades:true, oppScore:82 }); // 2ª chamada — idempotência
      assertDiagnostic(team.desempenhoRecente===desempenhoDepoisPrimeira, "A avaliação da Elite Cup não é idempotente — reaplicou o impacto numa 2ª chamada");
      return "Derrota em grandes penalidades atenuada corretamente, e avaliação idempotente (nunca reaplicada)";
    } finally {
      delete state.teams[clubId];
      state.eliteCup.edicao=originalEdicao;
    }
  }
  function runDiagnostics(){
    const tests=[];
    [12,13,14,16].forEach(n=>tests.push(diagnosticResult(`Calendário com ${n} equipas`,"Calendários",()=>testFixtureSize(n))));
    tests.push(diagnosticResult("Integridade das competições","Competições",testCompetitionIntegrity));
    tests.push(diagnosticResult("Progresso das jornadas","Competições",testCompetitionProgress));
    tests.push(diagnosticResult("Coerência semântica das competições","Competições",testCompetitionSemantics));
    tests.push(diagnosticResult("IDs permanentes","Dados",testPermanentIds));
    tests.push(diagnosticResult("Regras mínimas de plantel","Dados",testRosterRules));
    tests.push(diagnosticResult("Integridade de contratos e mercado","Mercado",testContractIntegrity));
    tests.push(diagnosticResult("Formação adaptativa A+B","Dados",()=>{const structures=Object.values(state.teams).filter(t=>!t.equipaPrincipalId);structures.forEach(a=>{const b=a.equipaBId&&state.teams[a.equipaBId],total=a.players.length+(b?b.players.length:0);assertDiagnostic(total<=40,`${a.name}: estrutura A+B descontrolada (${total})`);if(b)assertDiagnostic(b.players.length<=24,`${b.name}: plantel B excessivo (${b.players.length})`);});assertDiagnostic(Array.isArray(state.youthCandidates)&&Array.isArray(state.youthDecisionHistory),"Histórico de formação em falta");return `${structures.length} estruturas · ${state.youthCandidates.length} candidatos preservados · ${state.youthDecisionHistory.length} decisões`; }));
    tests.push(diagnosticResult("Separação entre reformados e inativos","Dados",()=>{const retired=state.retiredPlayers||[],inactive=state.inactivePlayers||[],rids=new Set(retired.map(x=>x.id)),iids=inactive.map(x=>x.id);assertDiagnostic(!retired.some(x=>x.age!=null&&x.age<34),"Foi encontrada uma reforma real abaixo dos 34 anos");assertDiagnostic(new Set(iids).size===iids.length,"IDs duplicados nos jogadores inativos");assertDiagnostic(!iids.some(id=>rids.has(id)),"Jogador simultaneamente reformado e inativo");return `${retired.length} reformados · ${inactive.length} inativos · arquivos separados`; }));
    tests.push(diagnosticResult("Instrumentação financeira anual","Finanças",()=>{const a=Object.values(state.teams).filter(t=>!t.equipaPrincipalId);a.forEach(t=>{initClubFinance(t);assertDiagnostic(Array.isArray(t.financeiro.historicoAnual),`${t.name}: histórico anual em falta`);assertDiagnostic(t.financeiro.auditoriaEpoca?.receitas&&t.financeiro.auditoriaEpoca?.despesas,`${t.name}: auditoria em falta`);});return `${a.length} clubes preparados para auditoria persistente`;}));
    tests.push(diagnosticResult("Reconciliação da auditoria financeira","Finanças",()=>{const bad=Object.values(state.teams).filter(t=>!t.equipaPrincipalId).filter(t=>{const x=financeSeasonAudit(t);return Math.abs(financeAuditSum(x.receitas)-financeAuditSum(x.despesas)-x.resultadoLiquido)>1;});assertDiagnostic(!bad.length,`${bad.length} clubes não reconciliados`);return "Receitas e despesas reconciliadas";}));
    tests.push(diagnosticResult("Linha de base financeira","Finanças",()=>{const x=buildFinanceBaselineReport();assertDiagnostic(x.clubes.length>0,"Sem clubes");assertDiagnostic(Object.keys(x.divisoes).length>0,"Sem divisões");return `${x.clubes.length} clubes · ${Object.keys(x.divisoes).length} divisões · quatro mais ricos ${(x.riqueza.concentracao*100).toFixed(1)}%`;}));
    tests.push(diagnosticResult("Custos estruturais progressivos","Calibração económica",()=>{const a=Object.values(state.teams).filter(t=>!t.equipaPrincipalId),g=a.filter(t=>normalizeClubReputation(t.reputacao,t)>=90).map(monthlyStructureCost),p=a.filter(t=>normalizeClubReputation(t.reputacao,t)<=54).map(monthlyStructureCost);assertDiagnostic(g.length&&p.length,"Perfis insuficientes");assertDiagnostic(Math.max(...g)>Math.min(...p),"Estrutura não progressiva");return `grandes até ${Math.max(...g)} €/mês · locais desde ${Math.min(...p)} €/mês`;}));
    tests.push(diagnosticResult("Saturação comercial","Calibração económica",()=>{const bad=Object.values(state.teams).filter(t=>!t.equipaPrincipalId).filter(t=>saturatedCommercialFactor(t)>(economicCalibrationReputationFactor(t.reputacao).cap||1.2)+.0001);assertDiagnostic(!bad.length,`${bad.length} clubes acima do teto`);return "Tetos comerciais respeitados";}));
    tests.push(diagnosticResult("Reservas e limite salarial da IA","Calibração económica",()=>{const a=Object.values(state.teams).filter(t=>!t.equipaPrincipalId),bad=a.filter(t=>{const x=economicPolicy(t);return !Number.isFinite(x.ratio)||x.reserve<0||x.available<0;});assertDiagnostic(!bad.length,`${bad.length} políticas inválidas`);return `${a.length} clubes avaliados pelo custo total`;}));
    tests.push(diagnosticResult("Persistência da calibração","Save",()=>{const a=Object.values(state.teams).filter(t=>!t.equipaPrincipalId);a.forEach(t=>{initClubFinance(t);assertDiagnostic(t.financeiro.calibracaoEconomica?.versao===ECONOMIC_CALIBRATION.version,`${t.name}: calibração ausente`);});return `Calibração persistente em ${a.length} clubes`;}));
    tests.push(diagnosticResult("Ausência de descidas duplas","Competições",()=>{const e=state.promotionEvent||{},duplas=(e.relegated||[]).filter(id=>(e.relegatedToThird||[]).includes(id));assertDiagnostic(!duplas.length,`Descidas Placard→3.ª detetadas: ${duplas.join(", ")}`);return "Nenhum clube desceu dois escalões na mesma transição";}));
    tests.push(diagnosticResult("Coerência de carreira dos jogadores livres","Mercado",()=>{
      const malformed=(state.freeAgents||[]).filter(p=>p.freeAgentContext&&(!p.freeAgentContext.formerTeamId||!p.freeAgentContext.formerDivision||!Number.isFinite(Number(p.freeAgentContext.lastSalary))));
      assertDiagnostic(!malformed.length,`${malformed.length} contextos de carreira inválidos`);
      return `${(state.freeAgents||[]).filter(p=>p.freeAgentContext).length} jogadores livres com memória de carreira válida`;
    }));
    tests.push(diagnosticResult("Equipas B sem contratações externas","Mercado",()=>{
      const invalid=Object.values(state.teams).filter(t=>t.equipaPrincipalId).flatMap(t=>t.players.filter(p=>p.lastFreeAgentMove&&p.lastFreeAgentMove.toTeamId===t.id));
      assertDiagnostic(!invalid.length,`${invalid.length} contratações externas por equipas B`);
      return "Nenhuma equipa B contratou jogadores livres externamente";
    }));
    tests.push(diagnosticResult("Persistência das decisões de mercado e A/B","Mercado",()=>{assertDiagnostic(Array.isArray(state.marketDecisionHistory),"Histórico de decisões de mercado em falta");assertDiagnostic(Array.isArray(state.internalTransferHistory),"Histórico A/B em falta");const malformed=state.internalTransferHistory.filter(x=>x.direction&&!x.date);assertDiagnostic(!malformed.length,"Movimentos A/B sem data");return `${state.marketDecisionHistory.length} decisões · ${state.internalTransferHistory.length} movimentos A/B`; }));
    tests.push(diagnosticResult("Planeamento de recrutamento IA","Mercado",()=>{
      const ledgers=Object.values(state.teams).filter(t=>t.aiRecruitmentLedger);
      // Correção (sistema numérico de reputação, efeito indireto): aiRecruitmentEntryLimit(t) é
      // recalculado a partir da carência ATUAL do plantel (GR/J em falta) — correto para o
      // portão em tempo real (tryFillAiSquadNeed/activeFreeAgentUpgradeForClub), que o chama
      // ANTES de cada contratação, quando a carência ainda reflete o estado do momento. Mas
      // ensureRosterMinimumsFromFreeAgents (rede de segurança de mínimos, sem registo no ledger)
      // e novas gerações de formação continuam a preencher o plantel depois disso — pelo que, no
      // fim da época, recalcular o mesmo limiar a partir do plantel já preenchido dá sempre um
      // valor mais baixo do que o que vigorava durante as contratações reais, produzindo falsos
      // positivos (mais prováveis agora que a 2ª Divisão deixou de ter finanças uniformes — ver
      // secção 6 do documento de reputação — e por isso alguns clubes têm carências iniciais bem
      // maiores do que outros). O teto realista a validar aqui é o máximo absoluto por época
      // (5, ver aiRecruitmentEntryLimit) — nunca um limiar dinâmico recalculado a posteriori.
      const invalid=ledgers.filter(t=>t.aiRecruitmentLedger.entradas>5||t.aiRecruitmentLedger.totalComprometido<0);
      assertDiagnostic(!invalid.length,`${invalid.length} clubes excederam limites de recrutamento`);
      return `${ledgers.length} planos de recrutamento validados`;
    }));
    tests.push(diagnosticResult("Qualidade mínima das contratações IA","Mercado",()=>{
      const invalid=Object.values(state.teams).flatMap(t=>t.players.filter(p=>p.aiRecruitmentDecision&&p.aiRecruitmentDecision.teamId===t.id&&!aiCandidateQualityOk(p,t,p.aiRecruitmentDecision.type==="promocoesB")));
      assertDiagnostic(!invalid.length,`${invalid.length} contratações abaixo do limiar do clube`);
      return "Contratações registadas respeitam o nível mínimo do destino";
    }));
    tests.push(diagnosticResult("Janelas de mercado","Mercado",testMarketPeriods));
    tests.push(diagnosticResult("Bilheteira não é receita dominante","Finanças",testFinanceRevenueMix));
    tests.push(diagnosticResult("Integridade dos objetivos de direção","Direção",testDirectionGoalsIntegrity));
    tests.push(diagnosticResult("Escalas de saúde da massa salarial","Direção",testWageHealthTiers));
    tests.push(diagnosticResult("Finanças por divisão","Finanças",testFinancialParity));
    tests.push(diagnosticResult("Sustentabilidade estrutural da 3.ª Divisão","Finanças",()=>{
      const clubs=Object.values(state.teams).filter(t=>t.divisaoAtual==="3div"&&!t.equipaPrincipalId);
      const deficits=clubs.filter(t=>{initClubFinance(t);const p=financeProjection(t);return p.net<0&&p.endBalance<0;});
      assertDiagnostic(deficits.length<=Math.ceil(clubs.length*.2),`${deficits.length}/${clubs.length} clubes da 3.ª Divisão com insolvência estrutural projetada`);
      return `${clubs.length-deficits.length}/${clubs.length} clubes sustentáveis na projeção de 8 meses`;
    }));
    tests.push(diagnosticResult("Relações equipa A/B","Mercado",testABRelations));
    tests.push(diagnosticResult("Round-trip do save atual","Saves",testSaveRoundTrip));
    [6,7,8,9].forEach(v=>tests.push(diagnosticResult(`Migração de save v${v}`,"Saves",()=>testLegacySaveMigration(v))));
    tests.push(diagnosticResult("Equilíbrio Norte/Sul 1+2","Competições",()=>{const ids=["candelaria","braga","tomar"],z=chooseBalancedPlacardAllocation(ids,1,2);assertDiagnostic(z.filter(x=>x==="norte").length===1&&z.filter(x=>x==="sul").length===2,"Distribuição incorreta");return `Norte 1 · Sul 2 · ${ids.map((id,i)=>state.teams[id].name+"→"+z[i]).join(" · ")}`;}));
    tests.push(diagnosticResult("Equilíbrio Norte/Sul 2+1","Competições",()=>{const ids=["candelaria","braga","tomar"],z=chooseBalancedPlacardAllocation(ids,2,1);assertDiagnostic(z.filter(x=>x==="norte").length===2&&z.filter(x=>x==="sul").length===1,"Distribuição incorreta");return `Norte 2 · Sul 1 · ${ids.map((id,i)=>state.teams[id].name+"→"+z[i]).join(" · ")}`;}));
    tests.push(diagnosticResult("Ciclo financeiro da crise","Falência",testFinancialCrisisLifecycle));
    tests.push(diagnosticResult("Game Over e administração IA","Game Over",testGameOverAndAiAdministration));
    tests.push(diagnosticResult("Carreira de treinador (experiência, subida, caches)","Carreira",testCarreiraTreinador0418));
    tests.push(diagnosticResult("Playoff gravado por competição","Competições",testPlayoffSaved));
    tests.push(diagnosticResult("Resumos de jogo guardados (0.4.20)","Competições",testMatchSummaries));
    tests.push(diagnosticResult("Candidatura aprovada por decidir (0.4.24)","Carreira",testCandidaturaDecisao));
    tests.push(diagnosticResult("Decisão final nos negócios (0.4.25)","Mercado",testDecisaoFinal));
    tests.push(diagnosticResult("Ecossistema de staff (0.4.26)","Staff",testStaffEcossistema));
    tests.push(diagnosticResult("Especialistas de staff com efeito real (0.4.27)","Staff",testStaffEspecialistas));
    tests.push(diagnosticResult("Staff: contratos, cobiça e adjunto (0.4.28)","Staff",testStaff2b));
    tests.push(diagnosticResult("Selecionadores nacionais de IA (0.4.31)","Staff",testSelecionadores));
    tests.push(diagnosticResult("Nuvem americana e oceânica (0.4.32)","Competições",testNuvemMundo));
    tests.push(diagnosticResult("Competições do Mundo (0.4.33)","Competições",testMundo));
    tests.push(diagnosticResult("Sedes, viagens por distância e reputação do treinador (0.4.34)","Competições",testViagemMundoEReputacao));
    tests.push(diagnosticResult("Viagens europeias por distância e hotel por dimensão do clube (0.4.35)","Competições",testViagemEuropa));
    tests.push(diagnosticResult("Visibilidade internacional e os seus efeitos (0.4.36)","Competições",testVisibilidade));
    tests.push(diagnosticResult("Clubes da nuvem sem finanças (0.4.37)","Finanças",testNuvemSemFinancas));
    tests.push(diagnosticResult("Vendas libertam o orçamento de transferências (0.4.30)","Finanças",testVendasOrcamento));
    tests.push(diagnosticResult("Arquivo das 5 épocas anteriores (0.4.21)","Competições",testCompetitionArchive));
    tests.push(diagnosticResult("Fidelidade integral do save da crise","Saves",testCrisisSaveFidelity));
    tests.push(diagnosticResult("Bloqueios após Game Over","Game Over",testGameOverGuards));
    tests.push(diagnosticResult("Projeção financeira sintética de 20 épocas (modelo fechado, sem jogos reais)","Longa duração",testFullCalendarFinanceSimulation));
    tests.push(diagnosticResult("Matriz de calibração da Fase 3","Calibração económica",()=>{const r=runPhaseThreeCalibrationMatrix(),base=r.scenarios.find(x=>x.id==="base-20");assertDiagnostic(r.scenarios.length>=7,"Matriz de cenários incompleta");return `${r.scenarios.length} cenários · saudáveis/atenção ${(base.healthyOrAttention*100).toFixed(1)}% · críticos ${(base.critical*100).toFixed(1)}% · concentração ${(base.topFourWealthShare*100).toFixed(1)}% · critérios ${r.passed?"cumpridos":"a afinar"}`;}));
    tests.push(diagnosticResult("Persistência da matriz da Fase 3","Saves",validatePhaseThreeSaveFidelity));
    tests.push(diagnosticResult("Auditoria de crescimento do save","Saves",()=>{const a=auditSaveGrowth();assertDiagnostic(a.totalBytes>0,"Save vazio");assertDiagnostic(a.counts.activePlayers>0,"Sem jogadores ativos");return `${Math.round(a.totalBytes/1024)} KB · maiores secções: ${a.sections.slice(0,4).map(x=>x.key+" "+x.percent+"%").join(" · ")}`;}));
    tests.push(diagnosticResult("Qualificação (normal, dobradinha, sem dados)","Supertaça",testSupertacaQualificationLogic));
    tests.push(diagnosticResult("Âncoras de calendário (2.º sábado de outubro)","Supertaça",testSupertacaCalendarAnchors));
    tests.push(diagnosticResult("Campo neutro no motor de jogo","Supertaça",testSupertacaNeutralVenue));
    tests.push(diagnosticResult("Atribuição idempotente (prémio, prestígio, título)","Supertaça",testSupertacaIdempotentAward));
    tests.push(diagnosticResult("Sorteio dos quartos cruza sempre os potes","Elite Cup",testEliteCupDrawCrossesPots));
    tests.push(diagnosticResult("Objetivos da direção distintos entre os 8 qualificados","Elite Cup",testEliteCupObjectiveDistinctness));
    tests.push(diagnosticResult("Ajuste do sorteio nunca ultrapassa 1 nível (idempotente)","Elite Cup",testEliteCupDrawAdjustmentCap));
    tests.push(diagnosticResult("Proteções da avaliação (grandes penalidades, idempotência)","Elite Cup",testEliteCupEvaluationProtections));
    tests.push(diagnosticResult("Robustez estrutural do calendário × 20 gerações + round-trip final","Longa duração",testTwentySeasonCareerMatrix));
    tests.push(diagnosticResult("Simulação estrutural de 10 épocas","Longa duração",testTenSeasonStructuralSimulation));
    const passed=tests.filter(t=>t.pass).length;
    const audit=state.saveGrowthAudit||auditSaveGrowth();
    state.diagnosticsReport={schema:"hm2027-diagnostics",version:3,generatedAt:new Date().toISOString(),season:state.season,userTeamId:state.userTeamId,validationSeasons:20,saveAudit:audit,passed,failed:tests.length-passed,total:tests.length,tests};
    registerValidationSnapshot(state.diagnosticsReport,audit);
    renderDiagnosticsState(); return state.diagnosticsReport;
  }
  function renderDiagnosticsState(){
    const report=state.diagnosticsReport,cards=document.getElementById("diagnosticsCards"),results=document.getElementById("diagnosticsResults"),summary=document.getElementById("diagnosticsSummary"),download=document.getElementById("downloadDiagnosticsBtn"); if(!cards||!results)return;
    if(!report){cards.innerHTML="";results.innerHTML='<p class="helptext">Carrega em Executar testes para validar esta versão.</p>';if(summary)summary.textContent="Ainda não executado";return;}
    cards.innerHTML=`<div class="diagnostic-card"><span>Total</span><strong>${report.total}</strong></div><div class="diagnostic-card"><span>Aprovados</span><strong style="color:#16834b">${report.passed}</strong></div><div class="diagnostic-card"><span>Falharam</span><strong style="color:var(--vermelho)">${report.failed}</strong></div><div class="diagnostic-card"><span>Épocas testadas</span><strong>${report.validationSeasons||20}</strong></div>`;
    results.innerHTML=report.tests.map(t=>`<div class="diagnostic-row ${t.pass?'pass':'fail'}"><div class="diagnostic-icon">${t.pass?'✓':'✕'}</div><div><b>${escapeHtml(t.name)}</b><div class="diagnostic-detail">${escapeHtml(t.detail)}</div></div><div>${escapeHtml(t.group)} · ${t.ms} ms</div></div>`).join("");
    if(summary)summary.textContent=report.failed?`${report.failed} teste(s) com falha`:`${report.passed}/${report.total} testes aprovados`; if(download)download.disabled=false;
  }
  function downloadDiagnosticsReport(){if(!state.diagnosticsReport)return;const blob=new Blob([JSON.stringify(state.diagnosticsReport,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`hm2027-diagnostico-${new Date().toISOString().slice(0,10)}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  const runDiagnosticsBtn=document.getElementById("runDiagnosticsBtn");if(runDiagnosticsBtn)runDiagnosticsBtn.addEventListener("click",runDiagnostics);
  const downloadDiagnosticsBtn=document.getElementById("downloadDiagnosticsBtn");if(downloadDiagnosticsBtn)downloadDiagnosticsBtn.addEventListener("click",downloadDiagnosticsReport);
  // =================================================================
  document.getElementById("menuNewGameBtn").addEventListener("click", () => {
    document.getElementById("mainMenuOverlay").classList.add("hidden");
    document.getElementById("managerNameOverlay").classList.remove("hidden");
  });
  document.getElementById("menuLoadGameBtn").addEventListener("click", () => {
    escolherGravacaoParaCarregar();
  });
  // 0.2.18 — Créditos também acessíveis dentro do jogo (barra lateral). creditsFromGame diz para
  // onde voltar: dentro do jogo só fecha; no arranque regressa ao menu principal.
  let creditsFromGame = false;
  document.getElementById("menuCreditsBtn").addEventListener("click", () => {
    creditsFromGame = false;
    document.getElementById("mainMenuOverlay").classList.add("hidden");
    document.getElementById("creditsOverlay").classList.remove("hidden");
  });
  const sideCreditsBtn = document.getElementById("sideCreditsBtn");
  if(sideCreditsBtn) sideCreditsBtn.addEventListener("click", () => {
    creditsFromGame = true;
    const ov = document.getElementById("creditsOverlay");
    ov.style.zIndex = "1250";
    document.getElementById("creditsBackBtn").textContent = "← Voltar ao jogo";
    ov.classList.remove("hidden");
  });
  document.getElementById("creditsBackBtn").addEventListener("click", () => {
    document.getElementById("creditsOverlay").classList.add("hidden");
    if(creditsFromGame){
      creditsFromGame = false;
      document.getElementById("creditsOverlay").style.zIndex = "";
      document.getElementById("creditsBackBtn").textContent = "← Voltar ao Menu";
    } else {
      document.getElementById("mainMenuOverlay").classList.remove("hidden");
    }
  });
  // 0.2.18 — referência ao email de bugs em todos os menus: acrescenta o bloco de contacto aos
  // cartões de menu que ainda não o têm (escolha de nome/país/clube, sair).
  (function injetarContactoNosMenus(){
    const ref = document.querySelector("#mainMenuOverlay .hm-contact-block");
    const m = ref && ref.textContent.match(/\d+\.\d+\.\d+/);
    const ver = m ? m[0] : "";
    ["sairOverlay","managerNameOverlay","countrySelectOverlay","teamSelectOverlay"].forEach(id => {
      const card = document.querySelector("#"+id+" .select-card");
      if(!card || card.querySelector(".hm-contact-block")) return;
      const p = document.createElement("p");
      p.className = "hm-contact-block";
      p.innerHTML = (ver ? "Versão "+ver+" · " : "") + 'Reporte de bugs e outras comunicações: <a href="mailto:hoqueimanager2027@gmail.com">hoqueimanager2027@gmail.com</a>';
      card.appendChild(p);
    });
  })();
  document.getElementById("mgrNameBackBtn").addEventListener("click", () => {
    document.getElementById("managerNameOverlay").classList.add("hidden");
    document.getElementById("mainMenuOverlay").classList.remove("hidden");
  });
  document.getElementById("mgrNameContinueBtn").addEventListener("click", () => {
    const first = document.getElementById("mgrFirstName").value.trim();
    const last = document.getElementById("mgrLastName").value.trim();
    if(!first || !last){
      document.getElementById("mgrNameErr").textContent = "Preenche o primeiro nome e o apelido.";
      return;
    }
    state.managerName = first + " " + last;
    document.getElementById("managerNameOverlay").classList.add("hidden");
    // Novo passo "País" antes da escolha de competição/clube (ver countrySelectOverlay) — a OK
    // Liga só aparece depois de escolhida a Espanha, nunca misturada com as competições
    // portuguesas no mesmo ecrã.
    document.getElementById("countrySelectOverlay").classList.remove("hidden");
  });
  document.getElementById("countrySelectBackBtn").addEventListener("click", () => {
    document.getElementById("countrySelectOverlay").classList.add("hidden");
    document.getElementById("managerNameOverlay").classList.remove("hidden");
  });
  // 0.2.3: da escolha de clube volta-se ao país (a divisão escolhe-se nos botões do topo do próprio ecrã).
  document.getElementById("teamSelectBackBtn").addEventListener("click", () => {
    document.getElementById("teamSelectOverlay").classList.add("hidden");
    document.getElementById("countrySelectOverlay").classList.remove("hidden");
  });
  function chooseNewGameCountry(country){
    selectedNewGameCountry = country;
    document.getElementById("countryBtnPt").classList.toggle("active", country==="pt");
    document.getElementById("countryBtnEs").classList.toggle("active", country==="es");
    document.getElementById("countryBtnIt").classList.toggle("active", country==="it");
    document.getElementById("competitionPickerPt").classList.toggle("hidden", country!=="pt");
    document.getElementById("competitionPickerEs").classList.toggle("hidden", country!=="es");
    document.getElementById("competitionPickerIt").classList.toggle("hidden", country!=="it");
    document.getElementById("countrySelectOverlay").classList.add("hidden");
    document.getElementById("teamSelectOverlay").classList.remove("hidden");
    renderTeamSelect(country==="es" ? "ok-liga-2026-27" : country==="it" ? "serie-a1-2026-27" : "placard-2026-27");
  }
  document.getElementById("countryBtnPt").addEventListener("click", () => chooseNewGameCountry("pt"));
  document.getElementById("countryBtnEs").addEventListener("click", () => chooseNewGameCountry("es"));
  document.getElementById("countryBtnIt").addEventListener("click", () => chooseNewGameCountry("it"));

  function gameOverSummaryText(){const x=state.gameOverSnapshot||{};return [`HÓQUEI MANAGER 2027 · FIM DA CARREIRA`,`Motivo: Falência do clube`,`Treinador: ${x.managerName||state.managerName||"-"}`,`Clube: ${x.clubName||"-"}`,`Data: ${x.date?new Date(x.date).toLocaleDateString("pt-PT"):"-"}`,`Jogos: ${x.matches||0} · Vitórias: ${x.wins||0} · Empates: ${x.draws||0} · Derrotas: ${x.losses||0}`,`Saldo: ${fmtMoney(x.finances?.saldo||0)} · Dívida: ${fmtMoney(x.finances?.divida||0)}`].join("\n");}
  function showGameOverModal(){if(!state.gameOver)return;const overlay=document.getElementById("gameOverOverlay");if(!overlay)return;document.getElementById("gameOverSummary").textContent=gameOverSummaryText();overlay.classList.remove("hidden");document.body.classList.add("game-over-active");}
  function exportGameOverSummary(){const url=URL.createObjectURL(new Blob([gameOverSummaryText()],{type:"text/plain;charset=utf-8"})),a=document.createElement("a");a.href=url;a.download="hm2027-resumo-final-carreira.txt";a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  document.getElementById("gameOverNewCareerBtn")?.addEventListener("click",()=>location.reload());document.getElementById("gameOverLoadBtn")?.addEventListener("click",()=>escolherGravacaoParaCarregar());document.getElementById("gameOverExportBtn")?.addEventListener("click",exportGameOverSummary);
  document.addEventListener("click",event=>{if(!state.gameOver)return;const allowed=event.target.closest("#gameOverOverlay")||event.target.closest("#savesOverlay")||event.target===document.getElementById("loadFileInput");/* 2026-10-16: no desktop, o seletor de gravações tem de funcionar depois de uma falência */if(!allowed){event.preventDefault();event.stopImmediatePropagation();showGameOverModal();}},true);
  // Aviso legal (2026-10-15): aparece sempre à entrada, antes do menu principal, e só desaparece
  // quando o utilizador carrega em OK (não fecha com Esc nem ao clicar fora).
  function initGameFlow(){
    renderTeamSelect("placard-2026-27");
    const aviso = document.getElementById("avisoLegalOverlay"), ok = document.getElementById("avisoLegalOkBtn");
    if(!aviso || !ok){ document.getElementById("mainMenuOverlay").classList.remove("hidden"); return; }
    ok.addEventListener("click", () => {
      aviso.classList.add("hidden");
      document.getElementById("mainMenuOverlay").classList.remove("hidden");
    });
    try{ ok.focus(); }catch(e){}
  }

  initGameFlow();
  if(state.gameOver)setTimeout(showGameOverModal,0);
  if(typeof window!=="undefined" && window.__HM2027_EXPOSE_TEST_HOOKS__){
    window.__HM2027_TEST__ = { state, visClube, visRegistar, visEnsure, visJogoInternacional, geoCoordsCidade, geoCoordsClube, geoDistanciaKm, viagemHotel, gestorRepVerificarProvas, gestorRepAplicar, gestorRepJogoLiga, mundoCustosViagem, mundoSedeDe, mundoInitEdition, mundoProcess, mundoDatasEpoca, mundoDividirGrupos, rsMundoDados, rsMundoHtml, mundoCartaoFimEpoca, MUNDO_KEYS, openSelecaoModal, setView, selecionadoresFimDeEdicao, selecionadoresHist, selecionadoresEnsureAll, selecionadorEnsure, selecionadorCoach, selecionadoresAnnual, selecionadorResultadoEdicao, selecionadorEntry, selecionadoresPanelHtml, selecionadorBlocoHtml, pickNationalSquad, staffFichaData, staffCriarRenovacoes, staffResponderProposta, staffCobicaCriar, staffCobicaMensal, staffSugestoes, staffAdjCargaMin, staffAdjRuido, staffResolveExpired, staffRel, staffEfeitoTexto, renderStaffPanel, staffGenerateEsp, staffPoolFor, staffFisicoInjuryMult, staffGRDevMult, staffGRGoalMult, staffScoutConfBonus, medicalInjuryMult, openStaffProposalModal, openStaffHireModal, staffAnnual, staffFromRetiredPlayer, staffContratar, staffCandidatos, staffResponderProposta, staffPropostas, staffExtraMensal, staffMensal, staffRetireProb, staffIdade, staffPool, staffArquivo, staffFillSlot, staffClubHtml, bootstrapStaffIfEmpty, processRetirements, hireTreinadorForVacancy, fireTreinador, runAcademyAnnualIntake, refreshPlayerAge, ensureRosterMinimumsFromFreeAgents, cleanupFreeAgentPool, ensureBTeamMinimums, closeCompletedSeasonPlayerStats, clubReputationLabel, makeHenriqueDias, divisionSalaryEstimate, adaptClubFinanceToDivision, derbyNivel, derbyFebre, derbyEstado, derbyDiario, derbyAposJogo, derbyNovaEpoca, derbyAtendimentoMult, derbyPisoAtendimento, derbyTvInteresse, tvDiario, pushNews, applySaveObject, validateMigratedSave, maybeStartPlataTie, processPlataTieForCurrentDate, applySpanishPromotionAndRelegation, plataZoneCompetitions, plataTieCard, eligiblePromotionRanking, financeAction, overall, academyCohortLeaving, applyCardConsequences, processPendingReturns, autoSubAI, removeInjuredWithoutSub, seasonEndTable, seasonEndCompetitionOf, relinkSelecaoSquadsOnLoad, grafFinSerieRegistar, grafRenderFinancas, grafRenderCarreira, grafHtml, scintEnsure, scintEnviar, scintDiario, scintCusto, scintConhecimento, scintAdaptacaoFactor, scintReservado, scintRender, SCINT_PAISES, presEnsure, presObjetivosAtuais, presGerarObjetivos, presAvaliar, presNegociar, presEleicoes, presGerarTodos, requestDirectionInvestment, resolvePendingDirectionInvestments, pavilhaoEnsure, emailReadingPaneHtml, clubPlantelRowsHtml, returnSeasonLoans, empEmprestadosFora, empMudarEquipaOrigem, transferPlayerBetweenAandB, canRemoveForInternalTransfer, relBMensal, relBLigacaoA, relBEnsure, lesMensal, ensureTeamScouting, resolvePendingScoutingReports, repScoutingDoc, renderScoutingReportsSection, lesTipo, lesEscolherTipo, lesAplicarGrave, lesAplicarLigeira, lesMudarPlano, lesRecuperou, lesDiaPassou, lesReadaptMult, lesRelatorioHtml, lesMensal, lesSecaoSaudeHtml, lesEnsure, LES_TIPOS, LES_PLANOS, lesResolverDiagnostico, resolvePendingMedicalEvaluations, applyInjuryOutcome, injuryChance, formatInjuryDuration, dailyConditionRecovery, calDiff, competitionIdForTeam, amigIAPlanear, amigIADiario, amigIASimular, amigRodarIA, amigExperimentarIA, amigConviteResponder, amigConvitesDiario, amigIAConvidarUtilizador, amigSugestaoRotacao, amigSecaoRotacaoHtml, amigNaEliteCup, amigRecemChegado, amigConvitesAtivos, getLineup, calAdvOcupado, calDatasPreparacao, generatePreGameReport, generateMonthlyTacticalReport, generateMonthlyTacticalReport, cargaAvisoAdjunto, repDoc, renderNews, calEnsure, calDataValida, calDataValidaTorneio, calPropor, calProporTorneio, calAmigDiario, calAmigProcessarHoje, calAmigAmanha, calAvaliarConvite, calTorneioPorId, calUI, calPainelHtml, calCancelarAmigavel, calCancelarTorneio, calSubstituirConvidado, calIsoAdd, calHoje, calDatasOficiais, calAmigLinhasCalendario, setPreSeasonNoStage, cancelPreSeasonStage, preSeasonOfficialDates, satEnsure, satElegiveis, satSateliteDe, satAcordoDoSatelite, satPropor, satResolverPedidos, satTerminar, satMudarApoio, satEmprestar, satEmprestadosAoSatelite, satJovensParaEmprestar, satProspectos, satPrecoPreferencia, satPodeContratar, satContratar, satMensal, satIaEpoca, satValidar, satApoioAnual, satPanelHtml, satScoreAceitacao, registrationWindowOpenFor, persTraco, persConhecida, persLinhaFicha, persMensal, persFimDeEpoca, persDefinir, persPrepararJogo, persSatisfacaoDelta, persNegociacaoMod, persSalarioMult, persRecusaRenovacao, persRendimentoFactor, persCartaoMult, persBalnearioAlvo, arbitroEnsure, arbitroPool, arbitroNomear, arbitroPrever, arbitroAplicar, arbitroAposJogo, arbitroReclamar, arbitroDeclarar, arbitroPedirAfastamento, arbitroPanelHtml, arbitroDiario, arbitroMensal, arbitroFimDeEpoca, arbitroLinhaAdjunto, arbitroPorId, arbitroRelacao, arbitroDecidir, contractDemand, evaluateContractOffer, computeSatisfactionTarget, updateSatisfacaoAfterMatch, setPlayerTransferListed, scoutingReportFor, buildSaveObject, applySaveObjectUnchecked,  pavilhaoEnsure, pavilhaoQualidade, pavilhaoCapacidade, pavilhaoIndisponivel, pavilhaoPreco, pavilhaoFatorPreco, pavilhaoAtendimentoMult, pavilhaoBilheteira, pavilhaoReceitasExtra, pavilhaoAmigavel, pavilhaoCustoObra, pavilhaoIniciarObra, pavilhaoConcluirObra, pavilhaoDiario, pavilhaoMensal, pavilhaoPanelHtml, pavilhaoPisoMult, pavilhaoTipoJogo, pavilhaoVisitantes, renderDirectionPanel, patrocinioEnsure, patrocinioSync, patrocinioMensal, patrocinioDiario, patrocinioFimDeEpoca, patrocinioResponder, patrocinioProcurar, patrocinioRescindir, patrocinioPanelHtml, patrocinioPagarMensal, patrocinioEscalar, patrocinioTvMult, patrocinioCustoProcura, patNovaProposta, patAssinar, patOferta, patMaximo, patRef, patBase, patSlotsLivres, patSatisfacaoAlvo, cargaAposJogo, cargaDiario, cargaValor, cargaDoJogo, cargaAvisoAdjunto, cargaAlternativa, cargaInjuryMult, cargaRecoveryMult, disciplinaAposJogo, disciplinaDiario, disciplinaRecorrer, disciplinaEnsure, disciplinaPanelHtml, disciplinaRegistarVermelho, disciplinaPortaFechada, disciplinaIncidentePublico, disciplinaNovoCaso, tvDiario, tvEscolherJornada, tvInfoDoJogo, tvAposJogo, tvJogoTransmitido, preJogoAplicarCondicao, matchAttendance,  viagemInfo, viagemZona, viagemTexto, viagemAplicarFadiga, viagemAplicavel, newMatchState, newLiveMatchState, processMatchFinances, empNormalizarClausulas, empClausulasTexto, empStats, empEmprestadosDoUtilizador, empExercerOpcao, empChamarDeVolta, processarEmprestimosDiario, empFimDeEmprestimo, empPrecoDono, empPrecoDestino, empGerarClausulasIA, renderEmprestimosSection, completeLoan, proposeLoan, resolvePendingLoanNegotiations, resolvePendingAiOfferCounters, respondToAiOffer, returnSeasonLoans, canLoanPlayer, evaluateLoanOffer, iniciarExperiencia, experienciaPodeIniciar, experienciasEmCurso, resolverExperienciasDiarias, buildExperienciaRelatorio, renderExperienciaRelatorioHtml, experienciaOvrVisivel, experienciaRowHtml, signFreeAgentToTeam, renderTransferMarket, ensureMarcadores, setMarcador, marcadorConversao, marcadorAjusteSkill, marcadorDesignadoEmPista, marcadorSugestaoAdjunto, marcadoresCandidatos, renderMarcadoresHtml, resolveSetPiece, ensureAdeptos, adeptosInfo, adeptosNivel, adeptosFatores, adeptosSyncIdolos, registerAdeptosResult, updateAdeptosMonthly, adeptosHomeFactor, adeptosAttendanceFactor, adeptosQuotaIncome, setAdeptosQuota, iniciarAdeptosCampanha, reunirComClaque, adeptosClaqueProxima, adeptosCampanhaCusto, renderAdeptosPanel, matchAttendance, processMonthlyFinances, calibratedRecurringIncomeParts, initPreSeasonPlan, preSeasonCurrent, scheduleFriendly, setPreSeasonStage, cancelFriendly, processPreSeasonForCurrentDate, preSeasonWindowEnd, preSeasonStageCost, preSeasonFriendlyCost, renderPreSeasonPanel, preSeasonValidDates, preSeasonOpponentOptions, recordFriendlyResult, preSeasonFirstOfficialDate, ensureTeamMedico, defaultMedicalLevel, medicalLevelConfig, medicalInjuryMult, medicalDurationMult, medicalRecoveryMult, medicalDiagnosisDelayDays, monthlyMedicalCost, nextMedicalLevel, medicalLevelUpgradeCost, requestDirectionInvestment, resolvePendingDirectionInvestments, syncAiMedicalLevel, injuryChance, applyInjuryOutcome, dailyConditionRecovery, fireNarrativeEvent, ensureBalneario, syncBalnearioPresenca, updateBalnearioMonthly, registerBalnearioResult, balnearioInfo, balnearioFactor, balnearioConversaDeGrupo, setBalnearioCapitao, balnearioFatores, balnearioResolverCapitao, processAcademyMonthlyDevelopment, runAcademyAnnualIntake, runAcademySub19ExitPass, academyHasB, presBoasVindas, presBoasVindasParaOFundo, fbSnapshot, fbGerar, fbPontos, fbFolhasHtml, ensureBTeamMinimums, globalSeasonCloseBlockers, pushNews, renderNews, unlistedSalePremium, clubSaleRefusal, clubsAreDirectRivals, startLiveMatchWithLineup, runLiveMatchTimerTick, runShootout, newShootoutState, shootoutAnnounceKick, shootoutResolveCurrentKick, shootoutDecision, renderShootoutPanel, finishShootout, registosRegistarJogoLiga, registosCreditarGolos, registosEquipaMaisTitulos, renderRegistosTab, ensureRegistos, renderCompetitionView, awardClubTitle, directionMatchReaction, directionReactToUserMatch, clockTensionLevel, applyClockTension, trackUserSquadEvolution, evolutionArrowDir, evolutionArrowHtml, runDiagnostics, marketPeriodForDate, CLUB_DEFS, clubDisplayColor, clubCrestUrl, contractYearsRemaining, isFinalContractYear, processDefesoMarket, proposeContract, expectedSalary, releasePlayerToFreeAgency, signFreeAgentToTeam, renewalPriorityScore, negotiationScore, beginDefeso, finalizeNewSeason, endOfSeason, evaluateDirectionGoals, financeConfig, wageToBudgetRatio, CLUB_FINANCE_PROFILES, isDerby, matchAttendance, processMatchFinances, simulateMatchToCompletion, applyStandings, globalSeasonReadyToClose, startPlayoffs, processPlayoffMatchday, createPlayoffBracket, PLAYOFF_DIVISION_CONFIG, playoffStartTargetDate, playOneSeriesGameQuick, checkPlayoffPhaseCompletion, maybeStartPromotionTie, recordPromotionTieResult, standingsForCompetition, refreshTransferMarket, buildSaveObject, migrateSaveObject, applySaveObjectUnchecked, normalizeInitialWageBill, initialWageTargetRatio, playerNameHtml, fatigueCurve, fatigueTierFactor, fitnessFactor, condicaoFactor, teamStrength, proposeLoan, completeLoan, generateAiOffersForUser, shootoutReference, shootoutGoProb, aiOfferPlayerFitsBuyer, aiOfferPlayerUpgradesBuyer, aiRecruitmentFinanciallySafe, aiTotalRecruitmentCost, playerMarketValue, transferCareerPenalty, setPlayerTransferListed, clearPlayerTransferListed, aiSquadUpgradeValue, aiOfferTargetScore, clubAverageOutfieldOverall, setView, renderRoster, openPlayerModal, renderPlayerModalContent, canLoanPlayer, evaluateLoanOffer, loanEligibilityProfile, processAiToAiMarket, syncTaticasUI, setTeamSistema, setTeamMentalidade, setTeamPressao, renderClubeSummaryExtras, clubAppeal, renderTaticasView, systemFitScore, lineupCompositionFactor, chooseAiMentalidade, chooseAiPressao, normalizeLoadedTeams, chooseAiSistema, bestOutfieldForSystem, playerProfile, getLineup, systemFitScore, manageSideTactics, shouldSwitchToThreeOneForFatigue, newLiveMatchState, newMatchState, runMatchTicks, aiSquadNeed, candidateMatchesNeed, aiSystemCriticalityBlock, tryFillAiSquadNeed, processAiToAiMarket, initTacticalIdentity, familiaridadeFactor, applyWeeklyTacticalTraining, chooseAiTacticalTraining, CLUB_TACTICAL_IDENTITY, setTeamTreino, renderTaticasView, recordTacticalMatchHistory, generatePostGameReport, generatePreGameReport, generateMonthlyTacticalReport, systemMatchupModifier, randomPortugueseName, combinedStructureSnapshot, academyEligible, defaultAcademyShape, initAcademyLevel, academyIntakeCount, academyBootstrapCountForBracket, academyPotentialGap, generateAcademyOutfield, generateAcademyGoalkeeper, generateAcademyPlayerForBracket, bootstrapAcademyIfEmpty, findPlayerInAcademy, TREINADOR_STATS_COMPETENCIA, TREINADOR_STATS_PERFIL, TREINADOR_STATS_KEYS, TREINADOR_STAT_LABEL, TREINADOR_REAL_NOMES, defaultTreinadorMandato, treinadorCompetenciaBase, treinadorPerfilRoll, generateTreinadorStats, generateTreinador, bootstrapTreinadorIfEmpty, registerTreinadorMatchResult, registerManagerClubExit, managerCareerTotals, activeCoachingStats, treinadorCulturaOrNeutral, defaultTreinadorCultura, processTreinadorCulturaMonthly, creativeFreedomFactor, aiCandidateStrategicScore, treinadorSalarioMensal, ensureTreinadorSeguranca, treinadorMesesDeMandato, registerTreinadorClubExit, fireTreinador, processTreinadorConfiancaMonthly, treinadorPoachCandidates, treinadorFitScore, hireTreinadorForVacancy, resolvePendingTreinadorVacancies, managerVacantEligibleClubs, treinadorVacanciaPenaltyFactor, TREINADOR_CONFIANCA_LIMIAR, TREINADOR_MESES_ATE_AVISO, TREINADOR_MESES_ATE_DESPEDIMENTO_APOS_AVISO, TREINADOR_MESES_MANDATO_PROTEGIDO, ACADEMY_BRACKETS, SPORTING_REAL_ACADEMY_ROSTER_SEASON1, REAL_ACADEMY_ROSTERS, academyRealRosterFor, runAcademySub19ExitPass, academyIsFemale, academyIsWonderkid, SPORTING_REAL_ACADEMY_GOALKEEPERS, academyBracketBirthYearRange, makeBirthDateInYear, runAcademyAnnualIntake, refreshPlayerAge, academyPromotionLimit, runAcademySub19ExitPass, developAcademyPlayerMonthly, processAcademyMonthlyDevelopment, retirementProbability, processRetirements, archiveRetiredPlayer, randomRenewalContractYears, randomContractYears, colorDistance, effectiveHomeColor, hexToRgb, makeBirthDate, renderPlayoffTab, renderPistaBanco, computeAge, processAiToAiMarketReactive, matchIntensityFactor, fitnessDecayPerTick, fitnessDecayPerTickGK, finalizePreSeasonDefeso, canLoanPlayer, clubAppeal, runAiToAiMarketPass, tryFillAiSquadNeed, isBTeamId, B_TEAM_IDS, returnSeasonLoans, plantelActiveTeamId, renderPlayerModalContent, ensureRosterMinimumsFromFreeAgents, playerPositionSortKey, initClubFinance, economicCalibrationState, calibratedRecurringIncomeParts, monthlyStructureCost, economicPolicy, runPhaseThreeCalibrationMatrix, validatePhaseThreeSaveFidelity, ensureFinanceAudit, financeSeasonAudit, closeFinanceAuditSeason, buildFinanceBaselineReport, applyPromotionAndRelegation, eligiblePromotionRanking, updateReputations, awardSeasonFinances, monthlyWageBill, processMonthlyFinances, cleanupFreeAgentPool, ensureBTeamMinimums, ensureMinimumSquad, archiveInactivePlayer, processAutomaticABPlanning, financialOwnerTeam, clubSquads, developPlayer, playerSeasonUsage, playerPotentialGap, playerAgeDevelopmentFactor, playerDevelopmentCeiling, maybeStartSecondDivisionFinal, recordSecondDivisionFinalResult, promotionTieCard, secondDivisionFinalCard, renderCompetitionView, globalSeasonReadyToClose, processPhaseFiveFinalsForCurrentDate, maybeStart3divApuramentos, finish3divApuramentosIfReady, applyThirdDivisionPromotionAndRelegation, enforceBTeamRule, competitionByDivisionZone, applyPromotionAndRelegation, standingsForCompetition, apuramentoStandings, looksLikeReserveTeamName, isMarketPassiveTeam, userControlledTeamIds, isUserControlledTeam, realGoalkeeperCount, canAutomaticallyMovePlayer, respondToAiOffer, expirePendingAiOffers, marketPeriodForDate, purchaseGapBlocked, divisionsTooFarApart, financeConfig, isSquadSurplus, negotiateWithClub, managerEligibleClubs, finishPlayoffGame, initTacaPortugal, processTacaPortugalForCurrentDate, tacaRecordTieResult, tacaFinishFaseIfReady, tacaEligibleTeams, tacaTieWinner, openConfirmarConvocatoriaModal, renderConfirmarConvocatoriaModal, convocatoriaAtualResumo, ensureSquadSelectionDefaults, convStatusFor, convIndisponivelMotivo, convOptionAllowed, convStatusHtml, avoidFinalFourCollisions, tacaTargetDateForFase, siblingTeamFor, teamHasFixtureToday, tryBorrowFromSibling, removeProvisionalPlayers, canRemoveForInternalTransfer, internalTransferPairForUser, makeHenriqueDias, processRound, globalSeasonCloseBlockers, advanceOneDayOrPhaseStep, nextWeekday, currentMatchContextLabel, competitionLabel, getSecondSaturdayOfOctober, getPlacardOpeningSunday, lastWeekdayOfMonth, seasonStartDate, finalizePreSeasonLeagueStart, finalizeNewSeasonTail, chooseClub, computeSupertacaQualification, initSupertaca, processSupertacaForCurrentDate, recordSupertacaResult, supertacaAwardOutcome, supertacaMyFixtureForCurrentDate, transferPlayerBetweenAandB, shotsOnTargetFor, effectiveColorForEventTeam, applyEventTeamColours, eventTeamFromText, effectiveHomeColor, renderLatestMatchEvent, renderMatchDesk, podePuxarGuardaRedes, pullGoalkeeper, restoreGoalkeeper, manageGoalkeeperPull, syncGoalkeeperPullButton, resolveShot, financialState, financeProjection, syncFinancialState, clubFinancialStructureFactor, applyAiFinancialPolicy, distributeSolidarityFund, calibrationFinancialState, buildCalibrationModels, runCalibrationScenario, monthlyTrainingCost,
      initEliteCup, processEliteCupForCurrentDate, eliteCupRecordTieResult, eliteCupDrawQuartos, eliteCupApplyDrawAdjustment, eliteCupCreateBaseObjectives, computeEliteCupExpectationFactors, eliteCupEvaluateObjective, eliteCupObjectiveLevelFromScore, eliteCupQualifiersFromSummary, eliteCupEditionConcluded, eliteCupTieWinner, eliteCupFaseDates, eliteCupRunPostSequence, eliteCupAvailabilityFactors, eliteCupSquadStrength, ELITE_CUP_INITIAL_RANKING, ELITE_CUP_OBJECTIVE_LEVELS, ELITE_CUP_OBJECTIVE_THRESHOLDS, ELITE_CUP_LEVEL_TIER, ELITE_CUP_EVAL_IMPACT, ELITE_CUP_DRAW_ADJUST_THRESHOLD,
      teamCountry, playerHomeCountry, isPlayerDisplaced, contractDemand, playerHousingCost, monthlyHousingBill, randomSpanishName, dfPending, dfConfirm, dfDesist, dfResolveExpired, openFinalDecisionModal, proposeContract, negotiateWithClub, resolvePendingClubNegotiations, resolvePendingContractNegotiations, proposeLoan, resolvePendingLoanNegotiations, resolveLoanConsents, agreedTransferFee, applyForManagerJob, respondToApprovedCandidatura, requestMoreTimeForDecision, managerVagaReservada, managerEligibleClubs, ensureManagerCareer, resolvePendingManagerCareerEvents, switchManagerToClub, maybeGenerateManagerJobOffers, inferCompetitionIdForTeamId,
      NATIONAL_CUP_CONFIG, maybeStartNationalCup, maybeStartCopaPrincesa, processNationalCupForCurrentDate, nationalCupRecordTieResult, nationalCupTieWinner, nationalCupTargetDates, nationalCupSafeDates, avoidLeagueCollisionsOnDate, nationalCupSerializeEdition, nationalCupDeserializeEdition,
      avoidFinalFourCollisions, tacaTargetDateForFase,
      offerRecentlyRejectedByUser, goBackView, syncBackButtonVisibility,
      playerSquadImportance, effectivePlayerEstatuto, setPlayerEstatuto, PLAYER_STATUS_LEVELS,
      aiOfferStatusPremiumThreshold, seededRndFloat, makeSeededRng, aiOfferTargetScore, purchaseGapBlocked,
      reviewAllAiTransferListings, reviewAiTransferListing, aiShouldKeepListed, aiPickTransferListingCandidate, aiListingReviewCooldownDays,
      renderTransferListSection, renderTransferMarket, setPlayerLoanListed, clearPlayerLoanListed, loanPlayerConsent, loanConsentDecide, loanListMotive, reviewAiLoanListing, reviewAllAiLoanListings, aiPickLoanListingCandidate, resolveLoanConsents, renderLoanListSection, aiLoanOfferTerms, respondToAiOffer, loanEligibilityProfile,
      awardEndOfSeasonPrizes, collectCompetitionParticipation, computeCompetitionAwards, grantSeasonAward,
      seasonAwardTierForCompetition, SEASON_PRIZE_TIER_CONFIG, competitionIsRelevantToUser,
      initSupercopaEspana, processSupercopaEspanaForCurrentDate, supercopaEspanaRecordTieResult, computeSupercopaEspanaQualification, supercopaEspanaFaseDates, supercopaEspanaSerializeEdition, supercopaEspanaDeserializeEdition,
      initSupercoppaItaliana, processSupercoppaItalianaForCurrentDate, recordSupercoppaItalianaLeg, computeSupercoppaItalianaQualification, supercoppaItalianaLegDates, supercoppaItalianaSerializeJogo, supercoppaItalianaDeserializeJogo,
      EUROPA_PAISES, EUROPA_NUVEM_PAISES, EUROPA_COEF_INICIAL, EUROPA_REP_BANDS, EUROPA_POINTS, EUROPA_PRIZES, EUROPA_BRACKET_PHASES, EUROPA_FASE_LABEL,
      EUROPA_NUVEM_CLUBES_REAIS, europaSlug, ensureEuropaNuvemClubes, europaNuvemClubIds, europaCountryOf, europaClubStrength,
      europaPendingIsPlayoff, europaPendingIsNeutral, EUROPA_COMPETITION_PRESTIGE, europaCompetitionPrestigeForTeam, competitionPrestigeForTeam,
      EUROPA_CUSTO_DESLOCACAO_INTERNACIONAL, EUROPA_SPONSOR_BONUS_PCT, EUROPA_SPONSOR_BONUS_LABEL, europaApplySeasonReputationBoost,
      europaCoefPaisAtual, europaClubCoefSum, dhondtSeats, europaCountryClubRanking, europaComputeAllocation,
      europaMakeTie, europaTieAggregate, europaTieDecide, europaResolveTieWinner, europaSingleLegFixtures, europaGroupStandings,
      europaBuildQualificationGroups, europaBuildChampionsGroupsFromClubIds, europaBuildChampionsInitialEdition, europaBuildCupFromEntrants, europaBuildTrophyFromEntrants,
      europaFinalizeQualificacao, europaInitEdition, europaForceConcludeIfPending,
      europaGroupById, europaBracketById, europaProcessOneGroupForCurrentDate, europaProcessGroupSetForCurrentDate, europaRecordGroupResult,
      europaAdvanceBracketPhase, europaProcessBracketForCurrentDate, europaRecordTieLegResult, europaStartChampionsKnockout, europaCheckSeasonConcluded,
      processEuropaForCurrentDate, europaSerializeEdicao, europaDeserializeEdicao,
      europaQualifStartDate, europaChampionsGroupStartDate, europaChampionsKnockoutDates, europaCupDates, europaTrophyDates, europaBaseYear,
      otherCompetitionsScheduleRows, myFullSchedule, renderHubDate, overall, overallFromAttrs, generatePlaceholderRoster, nuvemPlaceholderBase, randomNameForCountry, randomItalianName, tierBaseLevel,
      directionObjectiveTargetPosition, directionConfidenceTier, updateDirectionConfidenceAfterMatch,
      checkPeriodEndCtx, beginInteractiveShootoutSetup, advanceInteractiveShootoutTick, shootoutGoProb, runShootout, shootoutEligiblePlayers,
      openShootoutSetupModal, finishShootout,
      applyInjuryOutcome, resolvePendingMedicalEvaluations, rollGraveInjuryDurationDays, formatInjuryDuration, playerAvailableForMatch, checkInjuries, injuryChance, dailyConditionRecovery,
      jogadorDisponivelNestaPartida, autoSubAI, callUpImmediateReplacement, manageSideFatigue, openInjuryModal, processPendingReturns, livePlayerRow, onRinkStrength, performSub,
      registrationWindowOpenFor, aiHasUrgentOutOfWindowReason, nextRegistrationWindowOpenDate, validateCompetitionSnapshot, negotiateWithClub, resolvePendingClubNegotiations, proposeContract, resolvePendingContractNegotiations, resolvePendingContractCounterReminders, resolvePendingAiOfferReminders, resolvePendingAiOfferCounters, resolvePendingAiOfferContractCounters, acceptAiOfferFee, aiCandidateScoreJitter, contractNegOpenButtonHtml, applyAcceptedOffer, resolvePendingTransferHolds, proposeLoan, resolvePendingLoanNegotiations, evaluateLoanOffer, agreedTransferFee, transferNegotiationKey, negotiationSessionKey, loanNegotiationKey, initClubFinance, clubTransferDemand,
      playerHasPendingDeal, aiPendingNegotiationCount, buildAiMarketPendingIndex, processAiToAiMarketDaily, aiTotalRecruitmentCost, aiRegisterRecruitment, aiRecruitmentLedger, aiRecruitmentEntryLimit, aiRecruitmentMinimumOverall, aiCandidateQualityOk, aiSquadUpgradeValue, freeAgentSalaryDemand, aiRecruitmentFinanciallySafe, freeAgentCareerFit,
      movementEntrySeason, registerPlayerEntry, playerRegistrationsUsedThisSeason, playerTransferLimitReached, contractStatusLabel,
      registrationWindowCloseDate, sessionRegistrationDeadline, resolveExpiredClubAgreements,
      playerLinkHtml, competitionLinkHtml, openCompetitionView, openClubFicha, renderClubFichaView, findPlayerAnywhere, visibleOverall, stableAttrNoise, isMinePlayerTeam, openTreinadorModal, renderTreinadorModalContent, treinadorFichaData, treinadorRecordPct, clubStaffHtml, renderManagerCareerPanel,
      clubTransferenciasHtml, clubMovementTypeLabel, recordClubMovement,
      advanceOneDayOrPhaseStep, runContinuarAutoAdvance, userSuspensionSnapshot, userSuspensionIncreased, CONTINUAR_AUTO_ADVANCE_MAX_DIAS,
      callTimeout, canCallTimeout, maybeCallAiTimeout, canReleasePlayerFromTeam, realGoalkeeperCount, evaluateContractOffer,
      fmtDateShort, myFullSchedule,
      pushNews, renderNews, resolveNewsSender, newsSenderIcon, newsSenderMeta, newsCountryForTeam, emailRowHtml, emailReadingPaneHtml, newsSenderStyle, NEWS_SENDER_META, managerEmailAddress,
      updateEmailNavBadge, emailsByReadingOrder, nextUnreadNews,
      newsIsFromUserDivision, updateSatisfacaoAfterMatch, buildDissatisfactionNewsText, finalizePlayerStats, recoverInjuriesDuringDefeso, playerDissatisfactionThreshold, recordFixtureResult, playerMarketValue, clubTransferDemand, DIVISION_FINANCE_MULT, playerRoleGrievanceSeverity,
      contrastText, clubBadgeInitials, competitionLogoUrl, federationLogoUrl, competitionLogoFileBase, currentMatchCompetitionId, nationalityFlagCode, nationalityFlagHtml, clubMiniBadgeHtml, clubTextColor,
      bxReforcosParaB, bxDevolverParaAcademia, bxAposRodagem, bxPolitica, bxCandidatosRodagem, ensureMinimumSquad, removeProvisionalPlayers, teamHasFixtureToday,
      prepareSelecoesSub19ForNewSeason, processSelecaoEdicao, selecoesSub19CatchUp, selecaoS19PoolForNation, selecaoNationOf, teamIdForRealPlayer, announceSelecoesEdicaoIfPending, processSelecoesForCurrentDate, prepareSelecoesEdicaoForNewSeason,
      SELECAO_NATIONS, SELECAO_EUROPEU_ORDER, SELECAO_MUNDIAL_ORDER, selecaoNationCodesFor, selecaoLogoHtml, selecaoNationLinkHtml, nationalSquadScore, playersForNationCode, pickNationalSquad, makeSelecaoFillerPlayer, selecaoFillerNameCountry, teamIdForRealPlayer,
      selecaoCompetitionName, selecaoCompetitionId, selecaoTorneioDates, selecaoVirtualTeamId, makeVirtualSelecaoTeam, resolveSelecaoMatch, sortSelecaoGroupCodes, pushSelecaoBracketPreview, resolveSelecaoBracketResults, prepareSelecoesEdicaoForNewSeason, announceSelecoesEdicaoIfPending, processSelecoesForCurrentDate, selecaoSerializeEdicao, selecaoDeserializeEdicao,
      pushSelecaoDrawNews, pushSelecaoConvocationNews, pushSelecaoChampionNews, openSelecaoModal,
      NARRATIVE_EVENTS, NARRATIVE_RARITY_ORDER, processNarrativeEventsForCurrentDate, forceNarrativeEventById, ensureNarrativeEventState,
      openEventoNarrativoModal, closeEventoNarrativoModal, resolveNarrativeEventChoice, registerNarrativeHistorico,
      awardClubTitle, narrativeLendaTitulo, narrativeLendaReforma, narrativeDinastiaFimDeEra, decayLegadosDinastia, NARRATIVE_DINASTIA_TEMPORADAS,
      renderEventosHistorico,
      // Seleccionador Nacional — Acumulação de Cargo (2026-10-03)
      SELECAO_SELECIONAVEIS, SELECAO_INVITE_REP_MIN, SELECAO_INVITE_EXPERIENCIA_MIN, SELECAO_INVITE_CHANCE, SELECAO_INVITE_COOLDOWN_SEASONS, SELECAO_CONFIANCA_LIMIAR, SELECAO_RESULTADO_DELTA,
      selecaoNomeDaNacao, maybeGenerateSelecaoInvites, respondToSelecaoInvite, registerSelecaoExit, resignFromSelecao, selecaoResultadoLabel, processSelecaoParticipationOutcome, selecaoTreinadorCulturaFromGestor,
      finalizeSelecaoNationSquad, confirmManualSelecaoSquad,
      openSelecaoConvocatoriaManualModal, renderSelecaoConvocatoriaManualList };
  }
})();
