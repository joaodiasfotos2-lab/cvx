// ============================= 08zm-visibilidade.js =============================
// Visibilidade internacional (0.4.36, pedido do utilizador: "a vantagem de estar na final, ganhar,
// etc. é a visibilidade: melhores patrocínios, jogadores melhores interessados em vir, jogadores a
// quererem renovar"). Cada clube acumula pontos de visibilidade conforme a fase que atinge nas
// provas europeias e do Mundo (tabela VIS_PONTOS; fica sempre o melhor resultado da época). O valor
// em vigor é ESTA ÉPOCA + METADE DA ANTERIOR (desvanece-se), de 0 a ~1,5 (campeão do Mundial = 1,0).
// Efeitos: patrocínio mensal (+ propostas de novos patrocinadores), atratividade do clube para
// jogadores, satisfação dos jogadores (renovações), humor dos adeptos (sócios) e interesse da TV.
// Os jogos internacionais do clube do utilizador rendem ainda direitos de televisão e merchandising
// (visJogoInternacional), porque a bilheteira sozinha não paga as viagens.
// Estado: state.europa.visib = { epoca, cur:{clubId:pts}, prev:{clubId:pts} } (aditivo, gravado com a Europa).
// ===========================================================================
const VIS_PONTOS = {
  champions: { vencedor: 100, final: 85, meias: 75, quartos: 60, grupo5: 50, grupo6: 40 },
  cup: { vencedor: 60, final: 45, meias: 35, quartos: 25, oitavos: 15 },
  trophy: { vencedor: 45, final: 35, meias: 25, quartos: 18, preliminar: 10 },
  mundialclubes: { vencedor: 100, final: 85, meias: 70, grupos: 45 },
  continental: { vencedor: 70, final: 55, meias: 45 },
  panamericano: { vencedor: 40, final: 30, meias: 22, grupos: 12 },
};
// Efeitos de uma visibilidade de 1,0 (campeão do Mundial / da Champions).
const VIS = {
  anterior: 0.5,        // peso da época anterior
  sponsorMensal: 0.08,  // + % do patrocínio mensal
  momento: 0.12,        // + no multiplicador das propostas de patrocinadores (patMomento)
  apelo: 18,            // + pontos no prestígio da competição (clubAppeal: 30% → ~+5 de atratividade)
  satisfacao: 8,        // + no alvo de satisfação dos jogadores (renovações)
  humor: 6,             // + no alvo de humor dos adeptos (mais sócios, mais bilheteira)
  tv: 10,               // + no interesse da televisão pelos jogos do clube
};
// Direitos de televisão por jogo internacional (Placard = 3 500 € por jogo transmitido na liga; os internacionais são mais baratos por serem muito mais frequentes), por prova e fase.
const VIS_TV_BASE = { champions: 3000, cup: 1800, trophy: 1100, mundialclubes: 3500, continental: 2800, panamericano: 1200, qualificacao: 800 };
const VIS_TV_FASE = { grupo: 1, grupos: 1, preliminar: 1, oitavos: 1, quartos: 1.2, meias: 1.5, final: 2 };

function visEnsure(){
  if(!state.europa) return null;
  const ed = state.europa.edicao;
  let v = state.europa.visib;
  if(!v || typeof v !== "object"){ v = state.europa.visib = { epoca: ed ? ed.epoca : null, cur: {}, prev: {} }; }
  if(ed && v.epoca !== ed.epoca){
    // Nova edição: a época que acabou passa a "anterior" (só se for a imediatamente anterior).
    v.prev = (v.epoca != null && ed.epoca === v.epoca + 1) ? v.cur : {};
    v.cur = {}; v.epoca = ed.epoca;
  }
  return v;
}
function visRegistar(ed, clubId, key, fase){
  const tab = VIS_PONTOS[key], pts = tab ? (tab[fase] || 0) : 0;
  if(!pts || !clubId || !ed) return;
  const v = visEnsure(); if(!v) return;
  if(v.epoca !== ed.epoca) return;
  v.cur[clubId] = Math.max(v.cur[clubId] || 0, pts);
}
// Visibilidade em vigor do clube (0 = nenhuma; 1,0 = campeão do Mundial/da Champions esta época).
function visClube(teamId){
  const v = visEnsure(); if(!v || !teamId) return 0;
  return Math.min(1.5, ((v.cur[teamId] || 0) + VIS.anterior * (v.prev[teamId] || 0)) / 100);
}
// Direitos de TV e merchandising de um jogo internacional do clube do utilizador (casa, fora ou neutro).
function visJogoInternacional(compKey, fase, homeId, awayId, neutral){
  const uid = state.userTeamId, team = state.teams[uid];
  if(!team || (homeId !== uid && awayId !== uid) || team.nuvemEuropeia) return;
  const base = VIS_TV_BASE[compKey];
  if(!base) return;
  const mult3 = team.divisaoAtual === "3div" && typeof DIVISION_OPERATING_COST_MULT === "object" ? DIVISION_OPERATING_COST_MULT["3div"] : 1;
  const f = VIS_TV_FASE[fase] || 1, lado = (neutral || homeId === uid) ? 1 : 0.8;
  const tv = Math.round(base * f * lado * mult3 / 10) * 10;
  const label = compKey === "qualificacao" ? "Ronda de Qualificação Europeia" : ((EUROPA_PRIZES[compKey] && EUROPA_PRIZES[compKey].label) || compKey);
  if(tv > 0) addFinanceMovement(team, "receita", "Televisão", `Direitos de transmissão — ${label}${fase && fase !== "grupo" && fase !== "grupos" ? " (" + ((typeof EUROPA_FASE_LABEL === "object" && EUROPA_FASE_LABEL[fase]) || fase) + ")" : ""}`, tv, state.currentDate);
  // Em campo neutro não há bilheteira nem merchandising no pavilhão: vende-se online e na bancada de adeptos.
  if(neutral){
    const base2 = Math.max(0, (team.financeiro && team.financeiro.receitaMensalComercial) || 0) * 12 * 0.12 / 30;
    const merch = Math.round(base2 * (1 + visClube(uid)) / 10) * 10;
    if(merch > 0) addFinanceMovement(team, "receita", "Merchandising", `Merchandising online e na bancada — ${label}`, merch, state.currentDate);
  }
}
function visTexto(teamId){
  const v = visClube(teamId);
  if(v < 0.03) return "";
  const pct = Math.round(v * 100);
  return `Visibilidade internacional: ${pct}% (esta época e metade da anterior) — patrocínio mensal +${Math.round(VIS.sponsorMensal * Math.min(1.2, v) * 100)}%, atratividade para jogadores +${(VIS.apelo * v * 0.30).toFixed(1)}, satisfação do plantel +${(VIS.satisfacao * v).toFixed(1)}.`;
}
