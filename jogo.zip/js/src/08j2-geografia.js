// ============================= 08j2-geografia.js =============================
// Geografia (0.4.34): coordenadas aproximadas das cidades dos pavilhões e distância em linha reta
// entre duas cidades (haversine). Serve para o custo de viagem das competições do Mundo (sede
// sorteada numa cidade de um país com hóquei em patins, custo proporcional à distância).
// Chaves sem acentos, em minúsculas; a primeira chave contida no nome da cidade ganha (as mais
// longas primeiro). O que não corresponde a nenhuma cidade usa o centro do país do clube.
// ===========================================================================
const GEO_CIDADES = {
  // Portugal
  "lisboa": [38.72, -9.14], "oeiras": [38.69, -9.31], "cascais": [38.70, -9.42], "estoril": [38.71, -9.39], "parede": [38.69, -9.35],
  "murches": [38.73, -9.45], "sintra": [38.80, -9.38], "massama": [38.76, -9.28], "alenquer": [39.06, -9.01], "torres vedras": [39.09, -9.26],
  "loures": [38.83, -9.17], "tojal": [38.84, -9.12], "vila franca de xira": [38.95, -8.99], "seixal": [38.64, -9.10], "amora": [38.62, -9.12],
  "setubal": [38.52, -8.89], "azeitao": [38.52, -9.01], "sesimbra": [38.44, -9.10], "paco de arcos": [38.70, -9.29], "alcobaca": [39.55, -8.98],
  "turquel": [39.49, -9.02], "barcelos": [41.54, -8.62], "boliqueime": [37.14, -8.17], "loule": [37.14, -8.02], "braga": [41.55, -8.43],
  "cacia": [40.69, -8.60], "aveiro": [40.64, -8.65], "caldas das taipas": [41.48, -8.35], "guimaraes": [41.44, -8.30], "carvalhos": [41.08, -8.56],
  "vila nova de gaia": [41.13, -8.61], "gulpilhares": [41.08, -8.63], "candelaria": [37.79, -25.70], "ponta delgada": [37.74, -25.67],
  "colmeias": [39.79, -8.88], "leiria": [39.74, -8.81], "cucujaes": [40.83, -8.50], "oliveira de azeitemis": [40.84, -8.48], "oliveira de azemeis": [40.84, -8.48],
  "camara de lobos": [32.65, -16.98], "funchal": [32.65, -16.91], "madeira": [32.65, -16.95], "entroncamento": [39.46, -8.47], "espinho": [41.01, -8.64],
  "fanzeres": [41.16, -8.55], "gondomar": [41.15, -8.53], "fao": [41.52, -8.78], "esposende": [41.53, -8.78], "grandola": [38.18, -8.57],
  "lavra": [41.21, -8.72], "matosinhos": [41.18, -8.69], "maia": [41.23, -8.62], "marco de canaveses": [41.18, -8.15], "vila boa do bispo": [41.16, -8.17],
  "marinha grande": [39.75, -8.93], "mealhada": [40.38, -8.45], "ourem": [39.66, -8.58], "paredes": [41.21, -8.33], "lordelo do ouro": [41.15, -8.66],
  "paco de rei": [41.14, -8.59], "pacos de ferreira": [41.28, -8.37], "penafiel": [41.21, -8.28], "pessegueiro do vouga": [40.76, -8.39],
  "povoa de varzim": [41.38, -8.76], "riba d'ave": [41.40, -8.37], "vila nova de famalicao": [41.41, -8.52], "santa cita": [39.57, -8.43],
  "tomar": [39.60, -8.41], "vizela": [41.38, -8.30], "santa maria da feira": [40.93, -8.54], "santiago do cacem": [38.02, -8.70],
  "sobreira": [41.19, -8.38], "sao joao da madeira": [40.90, -8.49], "sao pedro do sul": [40.76, -8.07], "vale de cambra": [40.84, -8.40],
  "valenca": [42.03, -8.64], "valongo": [41.19, -8.50], "viana do castelo": [41.69, -8.83], "vila praia de ancora": [41.82, -8.87],
  "coimbra": [40.21, -8.43], "porto": [41.15, -8.61],
  // Espanha
  "a coruna": [43.37, -8.40], "coruna": [43.37, -8.40], "alcobendas": [40.54, -3.64], "alcoi": [38.70, -0.47], "alcoy": [38.70, -0.47],
  "barcelona": [41.39, 2.17], "calafell": [41.20, 1.57], "caldes de montbui": [41.63, 2.17], "cerdanyola": [41.49, 2.14], "el vendrell": [41.22, 1.54],
  "getxo": [43.36, -3.01], "girona": [41.98, 2.82], "igualada": [41.58, 1.62], "lleida": [41.62, 0.62], "lloret de mar": [41.70, 2.85],
  "lubians": [42.90, -8.20], "manlleu": [42.00, 2.28], "mataro": [41.54, 2.44], "macanet de la selva": [41.75, 2.72], "mollerussa": [41.63, 0.89],
  "olot": [42.18, 2.49], "ordes": [43.07, -8.41], "oviedo": [43.36, -5.85], "palafrugell": [41.92, 3.16], "reus": [41.16, 1.11],
  "rivas": [40.35, -3.52], "sant cugat": [41.47, 2.09], "sant hipolit": [42.02, 2.23], "sant just desvern": [41.38, 2.08], "sant sadurni": [41.43, 1.79],
  "tordera": [41.70, 2.72], "vic": [41.93, 2.25], "vila-seca": [41.11, 1.14], "vilafranca": [41.35, 1.70], "vilanova i la geltru": [41.22, 1.73],
  "vigo": [42.24, -8.72], "madrid": [40.42, -3.70], "valencia": [39.47, -0.38],
  // Itália
  "bassano del grappa": [45.77, 11.73], "castiglione della pescaia": [42.76, 10.88], "follonica": [42.92, 10.76], "forte dei marmi": [43.96, 10.17],
  "giovinazzo": [41.18, 16.67], "lodi": [45.31, 9.50], "matera": [40.67, 16.60], "novara": [45.45, 8.62], "sarzana": [44.11, 9.96],
  "seregno": [45.65, 9.20], "torre del lago": [43.83, 10.28], "trissino": [45.55, 11.44], "valdagno": [45.65, 11.30], "viareggio": [43.87, 10.25],
  // França
  "coutras": [45.04, -0.13], "crehen": [48.50, -2.28], "dinan": [48.45, -2.05], "la roche-sur-yon": [46.67, -1.43], "le poire-sur-vie": [46.77, -1.51],
  "merignac": [44.84, -0.65], "nantes": [47.22, -1.55], "noisy-le-grand": [48.85, 2.55], "ploufragan": [48.49, -2.80], "roubaix": [50.69, 3.17],
  "saint-omer": [50.75, 2.25], "villejuif": [48.79, 2.36],
  // Suíça, Áustria, Alemanha, Inglaterra
  "biasca": [46.36, 8.97], "diessbach": [47.07, 7.36], "montreux": [46.43, 6.91], "pully": [46.51, 6.66], "thun": [46.76, 7.63], "uttigen": [46.81, 7.55], "wimmis": [46.68, 7.65],
  "dornbirn": [47.41, 9.74], "feldkirch": [47.24, 9.60], "villach": [46.61, 13.85], "wolfurt": [47.47, 9.75],
  "darmstadt": [49.87, 8.65], "duisburg": [51.43, 6.77], "dusseldorf": [51.23, 6.78], "hamm": [51.68, 7.82], "recklinghausen": [51.61, 7.20], "remscheid": [51.18, 7.19], "wuppertal": [51.26, 7.15],
  "farnham": [51.21, -0.80], "herne bay": [51.37, 1.13], "kent": [51.27, 0.52], "king's lynn": [52.75, 0.40], "letchworth": [51.98, -0.23], "manchester": [53.48, -2.24], "middlesbrough": [54.57, -1.23], "soham": [52.33, 0.34],
  // Américas, Oceânia, África
  "buenos aires": [-34.60, -58.38], "mendoza": [-32.89, -68.84], "san juan": [-31.54, -68.54], "villa krause": [-31.57, -68.50],
  "santiago": [-33.45, -70.67], "concepcion": [-36.83, -73.05], "bogota": [4.71, -74.07], "cali": [3.45, -76.53],
  "melbourne": [-37.81, 144.96], "mordialloc": [-38.00, 145.09], "luanda": [-8.84, 13.23],
};
const GEO_PAIS_CENTRO = {
  pt: [39.6, -8.0], es: [41.4, 1.8], it: [43.5, 11.0], fr: [47.0, 0.0], ch: [46.8, 7.5], at: [47.3, 9.7], de: [51.3, 7.2], en: [52.0, -0.5],
  ar: [-34.6, -58.4], cl: [-33.45, -70.67], co: [4.71, -74.07], au: [-37.8, 145.0], ao: [-8.84, 13.23],
};
const GEO_PAIS_NOME = {
  pt: "Portugal", es: "Espanha", it: "Itália", fr: "França", ch: "Suíça", at: "Áustria", de: "Alemanha", en: "Inglaterra",
  ar: "Argentina", cl: "Chile", co: "Colômbia", au: "Austrália", ao: "Angola",
};
const GEO_CHAVES = Object.keys(GEO_CIDADES).sort((a, b) => b.length - a.length);

function geoNormalizar(s) { return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
// Coordenadas [lat, lon] de um nome de cidade (ou null).
function geoCoordsCidade(cidade) {
  const c = geoNormalizar(cidade);
  if (!c) return null;
  const k = GEO_CHAVES.find(x => c.includes(x));
  return k ? GEO_CIDADES[k] : null;
}
// Coordenadas do pavilhão de um clube: cidade, senão o centro do país.
function geoCoordsClube(team) {
  if (!team) return null;
  const c = geoCoordsCidade(team.cidadePavilhao || team.cidade);
  if (c) return c;
  const pais = typeof viagemPais === "function" ? viagemPais(team) : team.pais;
  return GEO_PAIS_CENTRO[pais] || null;
}
function geoDistanciaKm(a, b) {
  if (!a || !b) return 0;
  const R = 6371, rad = x => x * Math.PI / 180;
  const dLat = rad(b[0] - a[0]), dLon = rad(b[1] - a[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLon / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(h)));
}
