// ============================= 07g2-nuvem-mundo.js =============================
// Nuvem americana e oceânica (0.4.32): os clubes REAIS de Argentina, Chile, Colômbia e Austrália
// que um dia disputam o Pan-Americano / Mundial de Clubes. Pedido do João (2026-11-14): "todos os
// clubes que não têm nomes têm de ser inventados. Não deve ser possível contratar jogadores dessas
// ligas. São ligas inferiores a Portugal, Espanha, Itália, França."
//
// Mesmo mecanismo da nuvem europeia (07g-europa.js): o clube é marcado `nuvemEuropeia` (o nome
// histórico da marca; é ela que o exclui de mercado, empréstimos, academia, treinador, pesquisa,
// amigáveis, etc.) e, além disso, `nuvemMundo` (esta nuvem). Diferenças:
//  - Plantéis: os nomes REAIS publicados (Zerozero 2025/26, ficheiro do João) entram tal e qual
//    (guarda-redes assinalados); tudo o resto — posições, idades, atributos e os clubes sem
//    qualquer lista — é inventado, com nomes de língua espanhola (inglesa na Austrália).
//    Atributos calibrados pela reputação (nuvemPlaceholderBase); o topo argentino fica abaixo do
//    topo francês (liga inferior).
//  - Sem evolução de atributos (congelados) e reposição anual: quem se reforma é substituído por
//    um jovem inventado do mesmo posto, por isso o plantel mantém sempre ≥12 e ≥2 GR.
//  - Não entram na convocatória das seleções (NUVEM_MUNDO_NA_SELECAO): os jogadores gerados
//    ficariam abaixo dos preenchimentos das seleções AR/CL e enfraqueciam-nas sem querer.
// Funções e dados só em funções (nenhum const de módulo): esta nuvem é criada durante a avaliação
// do 07g-europa.js, antes deste módulo inicializar.

function nuvemMundoNaSelecao(){ return false; }

function nuvemMundoPaisInfo(pais){
  return {
    ar: { nome:"Argentina", nac:"Argentina", nomes:"es", pav:"Polideportivo Municipal", cont:"americas" },
    cl: { nome:"Chile", nac:"Chile", nomes:"es", pav:"Gimnasio Municipal", cont:"americas" },
    co: { nome:"Colômbia", nac:"Colômbia", nomes:"es", pav:"Coliseo de Patinaje", cont:"americas" },
    au: { nome:"Austrália", nac:"Austrália", nomes:"en", pav:"Sports Hall", cont:"oceania" },
  }[pais];
}

// Clubes (26). `rep` calibra o nível; `cidade` só onde a fonte a indica. Listas de nomes: ["Nome","GR"]
// para guarda-redes, "Nome" para os restantes (a fonte não indica posição). Franco Gómez aparece em
// dois clubes na fonte — fica só no Centro Valenciano (lista maior). Huracán e Recreativo Bochas
// (1 nome cada, este de 2024/25) contam como clubes sem dados — plantel todo inventado.
function nuvemMundoDefs(){
  const G = n => [n,"GR"];
  return [
    // Argentina
    { nome:"Andes Talleres", pais:"ar", rep:70, cidade:"Mendoza", nomes:[G("Rodrigo Fernández"),G("Pablo Morón"),"Exequiel Tamborindegui","Valentino Rossignoli","Ezequiel Orosito","Matías Fernández","Felipe Lombardi","Enrique Muzzio","Giovani Innella","Nahuel Silvestri","Juan Tamborindegui"] },
    { nome:"Banco Hispano", pais:"ar", rep:68, cidade:"San Juan", nomes:[G("Luca Ramella"),"Ignacio de la Torre","Victor Bertran","Lucas Quevedo","Santiago Balmaceda","Lautaro Mesquida","Ignacio Conte Grand"] },
    { nome:"Olimpia Patín Club", pais:"ar", rep:64, cidade:"San Juan", nomes:[G("Alejo Fernández"),G("Manuel Guillén"),G("Adolfo Harica"),"Juan Soria","Benjamin Bailon","Luis Alaniz","Octavio Ortar","Francisco Más","Bautista Giménez","Mariano de Angelis","Ignacio Lloveras","Gonzalo Acosta","Federico Ortiz","Federico Carrión"] },
    { nome:"Centro Valenciano", pais:"ar", rep:62, cidade:"San Juan", nomes:[G("Matías López"),G("Santiago Migani"),"Jeremías Reinoso","Nicolás Migani","Nahuel Frías","Tomás Soria","Juan Quiroga","Ignacio Prudkin","Luca Garcés","Víctor Carrasco","Rodrigo Ferruccio","Franco Gómez"] },
    { nome:"Concepción Patín Club", pais:"ar", rep:58, nomes:[] },
    { nome:"Leonardo Murialdo", pais:"ar", rep:56, nomes:[G("Ezequiel Lazo"),G("Santiago Javier Solivellas"),"Francisco Nardi","Germán Nacevich","Facundo Lana Fraccaro","Facundo Borini","Francisco Solivellas","Elias Salomon","Donato Martinazzo","Lucas Sottano","Lautaro Herman Gimenez","Laureano Estrada"] },
    { nome:"Lomas de Rivadavia", pais:"ar", rep:54, nomes:[G("Hugo Bueno"),G("Benjamin Tejada"),"Tomás Gaillez","Leandro López","Tomás Merele","Juan Garay","Gaston Sassul","Leandro Rosselot","Adrian Coria"] },
    { nome:"Unión Vecinal de Trinidad", pais:"ar", rep:54, cidade:"San Juan", nomes:[G("Facundo Deguer"),"Javier Amat","Pablo Gallardo","Joaquin Morales","Facundo Peralta","Tomas Rojas","Matías Aciar","Felipe Jurado","Mariano Ortíz"] },
    { nome:"San Martín de Mendoza", pais:"ar", rep:54, cidade:"Mendoza", nomes:[G("Bautista Pascual"),"Boris Cvetnic","Valentin Funes","Juan Ignacio Vilvhez","Juan Guerrero","Stefano Giovanini","Marcos Lombino","Lautaro Koroch","Valentino Croce"] },
    { nome:"IMPSA", pais:"ar", rep:52, cidade:"Mendoza", nomes:[G("Leandro Yacobucci"),"Agustín Lazzaro","Santino Calderone","Joaquin Gonzalez","José Zabala","Enzo Palacios"] },
    { nome:"Casa D'Italia", pais:"ar", rep:50, nomes:[] },
    { nome:"Huracán", pais:"ar", rep:50, nomes:[] },
    { nome:"UD Bancaria", pais:"ar", rep:50, nomes:[] },
    { nome:"Richet Zapata", pais:"ar", rep:48, nomes:[] },
    { nome:"Ciudad de Buenos Aires", pais:"ar", rep:48, cidade:"Buenos Aires", nomes:[] },
    { nome:"Recreativo Bochas Club", pais:"ar", rep:46, nomes:[] },
    { nome:"Unión de Villa Krause", pais:"ar", rep:46, cidade:"Villa Krause", nomes:[] },
    // Chile
    { nome:"HC San Jorge", pais:"cl", rep:60, nomes:[] },
    { nome:"New Red Star", pais:"cl", rep:54, nomes:[] },
    { nome:"Estudiantil San Miguel", pais:"cl", rep:50, nomes:[G("Rodrigo Aravena"),"Benjamin Valdivieso","Cristobal Aguilar","Vicente Reyes","Lucas Alvarado","Martín Molina"] },
    { nome:"Thomas Bata", pais:"cl", rep:48, nomes:[] },
    { nome:"Miguel León Prado", pais:"cl", rep:46, nomes:[] },
    // Colômbia
    { nome:"Corazonista Bogotá", pais:"co", rep:48, cidade:"Bogotá", nomes:[] },
    { nome:"Súper Patín", pais:"co", rep:46, nomes:[] },
    // Austrália (Ásia/Oceânia)
    { nome:"Melbourne Roller Hockey Club", pais:"au", rep:42, cidade:"Melbourne", nomes:[] },
    { nome:"Mordialloc RHC", pais:"au", rep:42, cidade:"Mordialloc", nomes:[] },
  ];
}

function nuvemMundoTeamId(def){ return `nuvem-${def.pais}-${europaSlug(def.nome)}`; }
function nuvemMundoClubes(){ return Object.values(state.teams).filter(t => t && t.nuvemMundo); }
function nuvemMundoClubIds(pais){ return nuvemMundoClubes().filter(t => !pais || t.pais === pais).map(t => t.id).sort(); }

function nuvemMundoFixPlayer(p, pais, inventado, nomeReal){
  const info = nuvemMundoPaisInfo(pais);
  p.nacionalidade = info.nac;
  p.paisOrigem = pais;
  if(inventado) p.nuvemInventado = true;
  if(nomeReal) p.nuvemNomeReal = true;
  p.intransferivel = true;   // rede de segurança: nunca contratável nem emprestável
  if(typeof computePlayerReputation === "function"){ try{ p.reputacaoJogador = computePlayerReputation(p); }catch(e){} }
  return p;
}

// Camisola livre (a mesma lógica de findFreeNumber, mas sobre um conjunto de números usados).
function nuvemMundoNumero(used, pos){
  const pref = pos === "GR" ? [1,12,13,30] : [4,5,6,7,8,9,10,11,14,17,20,23,15,16,18,19,21,22,24,25];
  for(const n of pref) if(!used.has(n)){ used.add(n); return n; }
  for(let n=2; n<=99; n++) if(!used.has(n)){ used.add(n); return n; }
  return 99;
}

// Nome inventado único no plantel (semente por clube+chave: estável entre execuções).
function nuvemMundoNomeNovo(team, usedNames, chave){
  const nomes = nuvemMundoPaisInfo(team.pais).nomes;
  for(let k=0; k<40; k++){
    const nm = randomNameForCountry(nomes, makeSeededRng(team.id+"|"+chave+"|"+k));
    if(!usedNames.has(nm)){ usedNames.add(nm); return nm; }
  }
  const nm = randomNameForCountry(nomes, makeSeededRng(team.id+"|"+chave+"|x"+Math.random())); usedNames.add(nm); return nm;
}

function nuvemMundoBuildRoster(team, def){
  const base = nuvemPlaceholderBase(team.reputacao);
  const used = new Set(), usedNames = new Set();
  const players = [];
  const reais = (def.nomes || []).map(n => Array.isArray(n) ? { nome:n[0], gr:true } : { nome:n, gr:false });
  reais.forEach(r => usedNames.add(r.nome));
  let k = 0;
  const add = (pos, nome, real) => {
    k++;
    const id = `${team.id}-p${k}`, num = nuvemMundoNumero(used, pos);
    const p = pos === "GR"
      ? makeGoalkeeper(id, num, nome, k===2 ? base-3 : base, "europa-nuvem", team.pais)
      : makeOutfieldPlayer(id, num, nome, base, "europa-nuvem", team.pais);
    players.push(nuvemMundoFixPlayer(p, team.pais, !real, real));
  };
  const grs = reais.filter(r => r.gr), out = reais.filter(r => !r.gr);
  grs.forEach(r => add("GR", r.nome, true));
  while(players.filter(p => p.pos === "GR").length < 2) add("GR", nuvemMundoNomeNovo(team, usedNames, "gr"+k), false);
  out.forEach(r => add("J", r.nome, true));
  let i = 0;
  while(players.length < 12) add("J", nuvemMundoNomeNovo(team, usedNames, "j"+(i++)), false);
  return players;
}

// Reposição: mantém ≥12 jogadores e ≥2 GR (reformados saem noutro sítio — processRetirements).
// Jovens inventados (18–22 anos) ao nível do clube. Idempotente.
function nuvemMundoRepor(team){
  if(!team || !team.nuvemMundo) return 0;
  const base = nuvemPlaceholderBase(team.reputacao);
  const used = new Set((team.players||[]).map(p => p.num)), usedNames = new Set((team.players||[]).map(p => p.name));
  const idsUsed = new Set((team.players||[]).map(p => p.id));
  let add = 0;
  const novo = (pos) => {
    let n = 0, id;
    do { id = `${team.id}-n${state.season||0}-${n++}`; } while(idsUsed.has(id));
    idsUsed.add(id);
    const nome = nuvemMundoNomeNovo(team, usedNames, "r"+(state.season||0)+"-"+id);
    const num = nuvemMundoNumero(used, pos);
    const p = pos === "GR" ? makeGoalkeeper(id, num, nome, base-2, "europa-nuvem", team.pais) : makeOutfieldPlayer(id, num, nome, base, "europa-nuvem", team.pais);
    p.age = 18 + (add % 5);
    if(p.dataNascimento && typeof makeBirthDate === "function") p.dataNascimento = makeBirthDate(makeSeededRng(id+"|nasc"), p.age);
    team.players.push(nuvemMundoFixPlayer(p, team.pais, true, false));
    add++;
  };
  const ativos = () => team.players.filter(p => p.retiringSeason == null);
  while(ativos().filter(p => p.pos === "GR").length < 2) novo("GR");
  while(ativos().length < 12) novo("J");
  return add;
}

function ensureNuvemMundo(){
  nuvemMundoDefs().forEach(def => {
    const id = nuvemMundoTeamId(def);
    const info = nuvemMundoPaisInfo(def.pais);
    let team = state.teams[id], criado = false;
    if(!team){
      criado = true;
      const rep = def.rep, tier = rep >= 62 ? 2 : 3;
      team = state.teams[id] = {
        id, name: def.nome, color:"#5B6B73", tier, divisaoAtual:"europa-nuvem", zona:null, pais: def.pais,
        pavilhao: info.pav, cidadePavilhao: def.cidade || info.nome,
        nuvemEuropeia:true, nuvemMundo:true, continenteNuvem: info.cont, equipaPrincipalId:null, equipaBId:null,
        reputacao:rep, reputacaoPontos:rep, reputacaoClube:rep, desempenhoRecente:50,
        capacidadeFinanceira:rep, massaAdepta:rep, condicoesTreino:"Boas", players:[],
        sistema:"3-1", mentalidade:"equilibrado", pressao:"media", provisional:true,
        stats:{ J:0,V:0,E:0,D:0,GM:0,GS:0,Pts:0 }, academy:null,
      };
      team.players = nuvemMundoBuildRoster(team, def);
    }
    team.nuvemMundo = true; team.nuvemEuropeia = true;
    nuvemMundoRepor(team);
    // Saves em curso: o clube novo precisa da mesma identidade/finanças que o chooseClub dá aos outros.
    if(criado && state.userTeamId){
      try{
        if(typeof initClubFinance==="function") initClubFinance(team);
        if(typeof normalizeInitialWageBill==="function") normalizeInitialWageBill(team);
        if(typeof initTacticalIdentity==="function") initTacticalIdentity(team);
      }catch(e){ console.warn("[HM2027] nuvem do mundo: init de clube novo", e); }
    }
  });
}

// Defeso: reforma + reposição (depois de processRetirements).
function nuvemMundoAnual(){
  if(state.nuvemMundoAnnualSeason === state.season) return;
  nuvemMundoClubes().forEach(nuvemMundoRepor);
  state.nuvemMundoAnnualSeason = state.season;
}
