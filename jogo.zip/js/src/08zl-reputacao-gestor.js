// ============================= 08zl-reputacao-gestor.js =============================
// Reputação do treinador ao longo da época (0.4.34). Pedido do João (2026-11-15): as competições
// do Mundo também mexem na reputação do treinador, e a reputação não pode só mudar no fim da época.
//
// Antes: só no fecho (updateManagerReputationAfterSeason: objetivos da direção ±10, título +8,
// subida +5, descida −6). Continua a ser assim — este módulo ACRESCENTA ajustes durante a época:
//  - Provas (taças, supertaças, Elite Cup, Champions/WSE Cup/Trophy, Mundial de Clubes, Taça
//    Continental, playoffs, liguilhas): a cada eliminatória ganha, passagem de grupos, título ou
//    eliminação. Lê o estado do Resumo (rsCompeticoes + provas do Mundo) e compara com o último
//    estado registado, por isso apanha tudo o que acontece, em qualquer ecrã, sem tocar em cada prova.
//  - Liga: cada jogo do utilizador mexe um pouco, conforme o esperado (ganhar a um grande vale
//    mais do que ganhar a um pequeno; perder com um pequeno custa mais).
// Valores pequenos, ponderados pelo prestígio da prova e pela força do adversário; com tetos por
// época (ganho/perda das provas e da liga) para a carreira não disparar. Fica registado um
// histórico (state.gestor.repHistorico) que a Direção mostra.
// =====================================================================================
const GREP_PESOS = {
  "eu-cl": { w: 1.0 }, mundialclubes: { w: 1.0 }, continental: { w: 0.7 }, panamericano: { w: 0.4 }, "eu-cup": { w: 0.6 }, "eu-trophy": { w: 0.4 }, "eu-qualif": { w: 0.3 },
  taca: { w: 0.5 }, "copa-del-rey": { w: 0.5 }, "coppa-italia": { w: 0.5 }, "copa-princesa": { w: 0.3 }, elite: { w: 0.5 },
  supertaca: { w: 0.3 }, "supercopa-es": { w: 0.3 }, "supercoppa-it": { w: 0.3 },
  // O título nacional, a subida e a descida já contam no fecho da época: aqui só a caminhada.
  playoff: { w: 0.8, semTitulo: true }, liguilha: { w: 0.5, semTitulo: true }, final2div: { w: 0.5, semTitulo: true }, plata: { w: 0.5, semTitulo: true },
};
const GREP = { avanco: 0.6, titulo: 3.0, elim: 0.4, tetoGanho: 12, tetoPerda: 8, ligaK: 0.10, ligaTeto: 4, ligaLimiteLog: 0.5, historicoMax: 40 };

function gestorRepFmt(v) { return (Math.round(Number(v) * 10) / 10).toLocaleString("pt-PT", { minimumFractionDigits: 0, maximumFractionDigits: 1 }); }

function gestorRepRegisto() {
  const g = ensureManagerCareer();
  if (!Array.isArray(g.repHistorico)) g.repHistorico = [];
  const r = g.repProvas;
  if (!r || typeof r !== "object" || r.epoca !== state.season || r.clube !== state.userTeamId) {
    // Nova época, novo clube ou primeiro registo: parte do estado actual, sem prémios retroativos.
    g.repProvas = { epoca: state.season, clube: state.userTeamId, itens: {}, ganho: 0, perda: 0, liga: 0, ligaAcum: 0, silencioso: true };
  }
  return g;
}
function gestorRepPontosClube(t) { return t ? (t.reputacaoPontos != null ? t.reputacaoPontos : normalizeClubReputation(t.reputacao, t)) : 50; }

// Aplica um ajuste, respeitando os tetos da época. cat: "prova" | "liga".
function gestorRepAplicar(delta, texto, cat) {
  const g = gestorRepRegisto(), r = g.repProvas;
  if (!delta || !Number.isFinite(delta)) return 0;
  if (cat === "liga") {
    const nova = clamp(r.liga + delta, -GREP.ligaTeto, GREP.ligaTeto);
    delta = nova - r.liga; r.liga = nova;
  } else if (delta > 0) {
    delta = Math.min(delta, GREP.tetoGanho - r.ganho); if (delta <= 0) return 0; r.ganho += delta;
  } else {
    delta = Math.max(delta, -(GREP.tetoPerda - r.perda)); if (delta >= 0) return 0; r.perda += -delta;
  }
  const antes = g.reputacao;
  g.reputacao = clamp(Math.round((g.reputacao + delta) * 100) / 100, 15, 99);
  g.reputacaoMaxima = Math.max(g.reputacaoMaxima || 0, g.reputacao);
  const real = g.reputacao - antes;
  if (texto) {
    g.repHistorico.unshift({ data: new Date(state.currentDate).toISOString(), texto, delta: Math.round(real * 100) / 100, total: Math.round(g.reputacao * 100) / 100 });
    if (g.repHistorico.length > GREP.historicoMax) g.repHistorico.length = GREP.historicoMax;
  }
  return real;
}

// Entradas das provas do Mundo (formato do Resumo) para o clube do utilizador.
function gestorRepEntradasMundo(team) {
  const ed = state.europa && state.europa.edicao, out = [];
  if (!ed) return out;
  ["mundialclubes", "panamericano", "continental"].forEach(k => {
    const b = ed[k]; if (!b || typeof rsMundoMeu !== "function") return;
    const m = rsMundoMeu(team.id, k, b);
    if (m) out.push({ key: k, nome: b.label, estado: m.estado, fase: m.texto, prog: m.prog || 0, opp: m.opp });
  });
  return out;
}

function gestorRepVerificarProvas() {
  if (!state.userTeamId || state.gameOver) return;
  const team = typeof myTeam === "function" ? myTeam() : null;
  if (!team || team.selecaoNacional || typeof rsCompeticoes !== "function") return;
  const g = gestorRepRegisto(), r = g.repProvas;
  let entradas = [];
  try { entradas = rsCompeticoes(team).concat(gestorRepEntradasMundo(team)); } catch (e) { return; }
  const minhaRep = gestorRepPontosClube(team);
  entradas.forEach(e => {
    const cfg = GREP_PESOS[e.key]; if (!cfg) return;
    const prev = r.itens[e.key] || (r.silencioso ? { prog: e.prog || 0, estado: e.estado } : { prog: 0, estado: "ativa" });
    const prog = e.prog || 0, w = cfg.w;
    const opp = e.opp ? state.teams[e.opp] : null;
    // Força do adversário: vencer um clube mais forte vale mais (até ×1,6), perder com um mais fraco custa mais.
    const f = opp ? clamp(1 + (gestorRepPontosClube(opp) - minhaRep) / 60, 0.5, 1.6) : 1;
    const dp = prog - prev.prog;
    if (dp > 0) gestorRepAplicar(dp * GREP.avanco * w * f, `${e.nome} — avançou (${String(e.fase).replace(" — apurado", "")})`, "prova");
    if (e.estado === "campea" && prev.estado !== "campea" && !cfg.semTitulo) gestorRepAplicar(GREP.titulo * w, `${e.nome} — título conquistado`, "prova");
    if (e.estado === "concluida" && prev.estado !== "concluida" && prev.estado !== "afastada") gestorRepAplicar(GREP.avanco * w, `${e.nome} — ${String(e.fase).replace(/^Concluída — /, "")}`, "prova");
    if (e.estado === "afastada" && prev.estado !== "afastada") gestorRepAplicar(-Math.max(0.15, GREP.elim - 0.05 * prog) * w * (2 - f), `${e.nome} — ${String(e.fase).replace(/^Eliminado: ?/, "eliminado: ")}`, "prova");
    r.itens[e.key] = { prog, estado: e.estado };
  });
  r.silencioso = false;
}

// Jogos de liga do utilizador (chamado por applyStandings).
function gestorRepJogoLiga(homeId, awayId, hs, as, soWinner) {
  const uid = state.userTeamId;
  if (!uid || (homeId !== uid && awayId !== uid) || state.pendingAmigavel) return;
  const me = state.teams[uid], opp = state.teams[homeId === uid ? awayId : homeId];
  if (!me || !opp || me.selecaoNacional || opp.selecaoNacional || opp.nuvemEuropeia || opp.equipaPrincipalId) return;
  const gf = homeId === uid ? hs : as, ga = homeId === uid ? as : hs;
  let res = gf > ga ? 1 : gf < ga ? 0 : 0.5;
  if (gf === ga && soWinner) res = (soWinner === "home") === (homeId === uid) ? 1 : 0;
  const dif = gestorRepPontosClube(opp) - gestorRepPontosClube(me);
  const esperado = 1 / (1 + Math.pow(10, dif / 30));   // adversário mais forte → esperado < 0,5
  const g = gestorRepRegisto(), r = g.repProvas;
  const real = gestorRepAplicar(GREP.ligaK * (res - esperado), null, "liga");
  r.ligaAcum += real;
  if (Math.abs(r.ligaAcum) >= GREP.ligaLimiteLog) {
    g.repHistorico.unshift({ data: new Date(state.currentDate).toISOString(), texto: r.ligaAcum > 0 ? "Bons resultados na liga" : "Maus resultados na liga", delta: Math.round(r.ligaAcum * 100) / 100, total: Math.round(g.reputacao * 100) / 100 });
    if (g.repHistorico.length > GREP.historicoMax) g.repHistorico.length = GREP.historicoMax;
    r.ligaAcum = 0;
  }
}

function gestorRepHistoricoHtml(n) {
  const g = ensureManagerCareer();
  const lista = (g.repHistorico || []).slice(0, n || 6);
  if (!lista.length) return `<div class="helptext" style="margin-bottom:10px;">A reputação também muda durante a época: a cada eliminatória, título ou eliminação nas provas e com os resultados da liga.</div>`;
  return `<div class="eyebrow" style="margin-bottom:6px;">Reputação — últimas alterações</div>
    <table class="stat-list" style="margin-bottom:12px;"><tbody>${lista.map(h => `<tr><td>${fmtDateShort(h.data)}</td><td>${escapeHtml(h.texto)}</td><td style="text-align:right;font-weight:700;color:${h.delta >= 0 ? "var(--verde-ok)" : "var(--vermelho)"};">${h.delta >= 0 ? "+" : "−"}${gestorRepFmt(Math.abs(h.delta))}</td><td style="text-align:right;opacity:.7;">${gestorRepFmt(h.total)}</td></tr>`).join("")}</tbody></table>`;
}
